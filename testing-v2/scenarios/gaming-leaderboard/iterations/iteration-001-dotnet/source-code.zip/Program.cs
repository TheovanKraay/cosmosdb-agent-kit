using Microsoft.Azure.Cosmos;
using GamingLeaderboard.Models;
using GamingLeaderboard.Services;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Net;

var builder = WebApplication.CreateBuilder(args);

builder.WebHost.UseUrls("http://0.0.0.0:5000");

// Configure JSON serialization for API responses
builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
    options.SerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
});

// Cosmos DB configuration
string cosmosEndpoint = Environment.GetEnvironmentVariable("COSMOS_ENDPOINT") ?? "https://localhost:8081";
string cosmosKey = Environment.GetEnvironmentVariable("COSMOS_KEY") ?? "C2y6yDjf5/R+ob0N8A7Cgv30VRDJIWEHLM+4QDU5DE2nQ9nDuVTqobD4b8mGGyPMbIZnqyMsEcaGQy67XIw/Jw==";
const string DatabaseName = "gaming-leaderboard";

bool isEmulator = cosmosEndpoint.Contains("localhost", StringComparison.OrdinalIgnoreCase) ||
                  cosmosEndpoint.Contains("127.0.0.1", StringComparison.OrdinalIgnoreCase);

var cosmosClientOptions = new CosmosClientOptions
{
    ConnectionMode = isEmulator ? ConnectionMode.Gateway : ConnectionMode.Direct,
    HttpClientFactory = isEmulator ? () =>
    {
        var handler = new HttpClientHandler
        {
            ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
        };
        return new HttpClient(handler);
    } : null
};

var cosmosClient = new CosmosClient(cosmosEndpoint, cosmosKey, cosmosClientOptions);
builder.Services.AddSingleton(cosmosClient);
builder.Services.AddSingleton(new CosmosDbService(cosmosClient, DatabaseName));

var app = builder.Build();

// Initialize database and containers in background after the server starts listening.
// This prevents blocking startup and ensures the health endpoint is reachable immediately.
var dbInitialized = new TaskCompletionSource<bool>();
app.Lifetime.ApplicationStarted.Register(() =>
{
    _ = Task.Run(async () =>
    {
        try
        {
            Console.WriteLine("Initializing Cosmos DB database and containers...");
            await InitializeCosmosDbAsync(cosmosClient);
            Console.WriteLine("Cosmos DB initialization complete.");
            dbInitialized.TrySetResult(true);
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Cosmos DB initialization failed: {ex.Message}");
            dbInitialized.TrySetException(ex);
        }
    });
});

// Health endpoint
app.MapGet("/health", () => Results.Ok(new { status = "healthy" }));

// POST /api/players
app.MapPost("/api/players", async (HttpContext context, CosmosDbService db) =>
{
    JsonElement body;
    try
    {
        body = (await context.Request.ReadFromJsonAsync<JsonElement>())!;
    }
    catch
    {
        return Results.BadRequest(new { error = "Invalid JSON body" });
    }

    if (!body.TryGetProperty("playerId", out var playerIdProp) || string.IsNullOrEmpty(playerIdProp.GetString()))
        return Results.BadRequest(new { error = "playerId is required" });
    if (!body.TryGetProperty("displayName", out var displayNameProp) || string.IsNullOrEmpty(displayNameProp.GetString()))
        return Results.BadRequest(new { error = "displayName is required" });
    if (!body.TryGetProperty("region", out var regionProp) || string.IsNullOrEmpty(regionProp.GetString()))
        return Results.BadRequest(new { error = "region is required" });

    var player = new Player
    {
        PlayerId = playerIdProp.GetString()!,
        DisplayName = displayNameProp.GetString()!,
        Region = regionProp.GetString()!,
        TotalGames = 0,
        BestScore = 0,
        AverageScore = 0,
        TotalScore = 0
    };

    try
    {
        var created = await db.CreatePlayerAsync(player);

        return Results.Created($"/api/players/{created.PlayerId}", new
        {
            playerId = created.PlayerId,
            displayName = created.DisplayName,
            region = created.Region,
            totalGames = created.TotalGames,
            bestScore = created.BestScore,
            averageScore = created.AverageScore
        });
    }
    catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.Conflict)
    {
        return Results.Conflict(new { error = $"Player {player.PlayerId} already exists" });
    }
});

// GET /api/players/{playerId}
app.MapGet("/api/players/{playerId}", async (string playerId, CosmosDbService db) =>
{
    var player = await db.GetPlayerAsync(playerId);
    if (player == null) return Results.NotFound();

    return Results.Ok(new
    {
        playerId = player.PlayerId,
        displayName = player.DisplayName,
        region = player.Region,
        totalGames = player.TotalGames,
        bestScore = player.BestScore,
        averageScore = player.AverageScore
    });
});

// PATCH /api/players/{playerId}
app.MapPatch("/api/players/{playerId}", async (string playerId, HttpContext context, CosmosDbService db) =>
{
    var player = await db.GetPlayerAsync(playerId);
    if (player == null) return Results.NotFound();

    var body = await context.Request.ReadFromJsonAsync<JsonElement>();

    string? oldRegion = player.Region;
    bool displayNameChanged = false;
    bool regionChanged = false;

    if (body.TryGetProperty("displayName", out var displayNameProp))
    {
        var newName = displayNameProp.GetString();
        if (newName != null && newName != player.DisplayName)
        {
            player.DisplayName = newName;
            displayNameChanged = true;
        }
    }

    if (body.TryGetProperty("region", out var regionPropVal))
    {
        var newRegion = regionPropVal.GetString();
        if (newRegion != null && newRegion != player.Region)
        {
            player.Region = newRegion;
            regionChanged = true;
        }
    }

    var updated = await db.UpdatePlayerAsync(player);

    // Update leaderboard entries if display name or region changed and player has scores
    if ((displayNameChanged || regionChanged) && updated.BestScore > 0)
    {
        await db.UpdateLeaderboardEntriesAsync(updated, oldRegion!, regionChanged);
    }

    return Results.Ok(new
    {
        playerId = updated.PlayerId,
        displayName = updated.DisplayName,
        region = updated.Region,
        totalGames = updated.TotalGames,
        bestScore = updated.BestScore,
        averageScore = updated.AverageScore
    });
});

// DELETE /api/players/{playerId}
app.MapDelete("/api/players/{playerId}", async (string playerId, CosmosDbService db) =>
{
    var deleted = await db.DeletePlayerAsync(playerId);
    return deleted ? Results.NoContent() : Results.NotFound();
});

// POST /api/scores
app.MapPost("/api/scores", async (HttpContext context, CosmosDbService db) =>
{
    JsonElement body;
    try
    {
        body = (await context.Request.ReadFromJsonAsync<JsonElement>())!;
    }
    catch
    {
        return Results.BadRequest(new { error = "Invalid JSON body" });
    }

    if (!body.TryGetProperty("playerId", out var playerIdProp) || string.IsNullOrEmpty(playerIdProp.GetString()))
        return Results.BadRequest(new { error = "playerId is required" });

    if (!body.TryGetProperty("score", out var scoreProp))
        return Results.BadRequest(new { error = "score is required" });

    int scoreValue;
    try
    {
        scoreValue = scoreProp.GetInt32();
    }
    catch
    {
        return Results.BadRequest(new { error = "score must be an integer" });
    }

    if (scoreValue < 0)
        return Results.BadRequest(new { error = "score must be a positive integer" });

    string? gameMode = body.TryGetProperty("gameMode", out var gm) ? gm.GetString() : null;

    try
    {
        var score = await db.SubmitScoreAsync(playerIdProp.GetString()!, scoreValue, gameMode);
        return Results.Created($"/api/scores/{score.ScoreId}", new
        {
            scoreId = score.ScoreId,
            playerId = score.PlayerId,
            score = score.ScoreValue
        });
    }
    catch (InvalidOperationException)
    {
        return Results.NotFound(new { error = "Player not found" });
    }
});

// GET /api/players/{playerId}/scores
app.MapGet("/api/players/{playerId}/scores", async (string playerId, int? limit, CosmosDbService db) =>
{
    var player = await db.GetPlayerAsync(playerId);
    if (player == null) return Results.NotFound();

    var effectiveLimit = limit ?? 10;
    if (effectiveLimit < 1) effectiveLimit = 1;
    if (effectiveLimit > 100) effectiveLimit = 100;

    var scores = await db.GetPlayerScoresAsync(playerId, effectiveLimit);

    var result = scores.Select(s => new
    {
        scoreId = s.ScoreId,
        playerId = s.PlayerId,
        score = s.ScoreValue,
        gameMode = s.GameMode,
        timestamp = s.Timestamp
    });

    return Results.Ok(result);
});

// GET /api/leaderboards/global
app.MapGet("/api/leaderboards/global", async (int? top, CosmosDbService db) =>
{
    var effectiveTop = top ?? 100;
    if (effectiveTop > 100) effectiveTop = 100;
    if (effectiveTop < 1)
        return Results.Ok(Array.Empty<object>());

    var entries = await db.GetGlobalLeaderboardAsync(effectiveTop);

    var result = entries.Select((e, i) => new
    {
        rank = i + 1,
        playerId = e.PlayerId,
        displayName = e.DisplayName,
        score = e.Score
    });

    return Results.Ok(result);
});

// GET /api/leaderboards/regional/{region}
app.MapGet("/api/leaderboards/regional/{region}", async (string region, int? top, CosmosDbService db) =>
{
    var effectiveTop = top ?? 100;
    if (effectiveTop > 100) effectiveTop = 100;
    if (effectiveTop < 1)
        return Results.Ok(Array.Empty<object>());

    var entries = await db.GetRegionalLeaderboardAsync(region, effectiveTop);

    var result = entries.Select((e, i) => new
    {
        rank = i + 1,
        playerId = e.PlayerId,
        displayName = e.DisplayName,
        score = e.Score
    });

    return Results.Ok(result);
});

// GET /api/players/{playerId}/rank
app.MapGet("/api/players/{playerId}/rank", async (string playerId, CosmosDbService db) =>
{
    var player = await db.GetPlayerAsync(playerId);
    if (player == null) return Results.NotFound();

    var (playerEntry, allEntries) = await db.GetPlayerRankDataAsync(playerId);
    if (playerEntry == null) return Results.NotFound();

    int playerIndex = -1;
    for (int i = 0; i < allEntries.Count; i++)
    {
        if (allEntries[i].PlayerId == playerId)
        {
            playerIndex = i;
            break;
        }
    }

    if (playerIndex < 0) return Results.NotFound();

    int playerRank = playerIndex + 1;

    int startIndex = Math.Max(0, playerIndex - 10);
    int endIndex = Math.Min(allEntries.Count - 1, playerIndex + 10);

    var neighbors = new List<object>();
    for (int i = startIndex; i <= endIndex; i++)
    {
        if (i == playerIndex) continue;
        neighbors.Add(new
        {
            rank = i + 1,
            playerId = allEntries[i].PlayerId,
            displayName = allEntries[i].DisplayName,
            score = allEntries[i].Score
        });
    }

    return Results.Ok(new
    {
        playerId = playerId,
        rank = playerRank,
        score = playerEntry.Score,
        neighbors = neighbors
    });
});

app.Run();

async Task InitializeCosmosDbAsync(CosmosClient client)
{
    var databaseResponse = await client.CreateDatabaseIfNotExistsAsync(
        DatabaseName,
        ThroughputProperties.CreateAutoscaleThroughput(1000));

    var database = databaseResponse.Database;

    // Players container with partition key /playerId
    var playersContainerProperties = new ContainerProperties("players", "/playerId")
    {
        IndexingPolicy = new IndexingPolicy
        {
            Automatic = true,
            IndexingMode = IndexingMode.Consistent,
            IncludedPaths = { new IncludedPath { Path = "/*" } },
            ExcludedPaths =
            {
                new ExcludedPath { Path = "/totalScore/?" },
                new ExcludedPath { Path = "/\"_etag\"/?" }
            }
        }
    };
    await database.CreateContainerIfNotExistsAsync(playersContainerProperties);

    // Scores container with partition key /playerId
    var scoresContainerProperties = new ContainerProperties("scores", "/playerId")
    {
        IndexingPolicy = new IndexingPolicy
        {
            Automatic = true,
            IndexingMode = IndexingMode.Consistent,
            IncludedPaths = { new IncludedPath { Path = "/*" } },
            ExcludedPaths =
            {
                new ExcludedPath { Path = "/gameMode/?" },
                new ExcludedPath { Path = "/\"_etag\"/?" }
            }
        }
    };
    await database.CreateContainerIfNotExistsAsync(scoresContainerProperties);

    // Leaderboards container with partition key /leaderboardKey
    var leaderboardsIndexingPolicy = new IndexingPolicy
    {
        Automatic = true,
        IndexingMode = IndexingMode.Consistent,
        IncludedPaths = { new IncludedPath { Path = "/*" } },
        ExcludedPaths =
        {
            new ExcludedPath { Path = "/region/?" },
            new ExcludedPath { Path = "/\"_etag\"/?" }
        }
    };

    // Composite index for tiebreaking: score DESC, displayName ASC
    leaderboardsIndexingPolicy.CompositeIndexes.Add(new System.Collections.ObjectModel.Collection<CompositePath>
    {
        new CompositePath { Path = "/score", Order = CompositePathSortOrder.Descending },
        new CompositePath { Path = "/displayName", Order = CompositePathSortOrder.Ascending }
    });

    var leaderboardsContainerProperties = new ContainerProperties("leaderboards", "/leaderboardKey")
    {
        IndexingPolicy = leaderboardsIndexingPolicy
    };
    await database.CreateContainerIfNotExistsAsync(leaderboardsContainerProperties);
}
