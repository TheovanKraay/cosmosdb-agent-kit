using Microsoft.Azure.Cosmos;
using IoTTelemetry.Api.Services;
using System.Net.Http;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Best Practice 4.13: Reuse CosmosClient as Singleton
// Best Practice 4.6: Configure for Cosmos DB Emulator with Gateway mode
builder.Services.AddSingleton<CosmosClient>(sp =>
{
    var configuration = sp.GetRequiredService<IConfiguration>();
    var endpoint = configuration["CosmosDb:Endpoint"]!;
    var key = configuration["CosmosDb:Key"]!;

    var isEmulator = endpoint.Contains("localhost") || endpoint.Contains("127.0.0.1");

    var options = new CosmosClientOptions
    {
        ApplicationName = "IoTTelemetryApi",

        // Best Practice 4.6: Gateway mode for emulator (required)
        // Best Practice 4.4: Direct mode for production
        ConnectionMode = isEmulator ? ConnectionMode.Gateway : ConnectionMode.Direct,

        // Best Practice 4.11: Handle 429 errors with Retry-After
        MaxRetryAttemptsOnRateLimitedRequests = 9,
        MaxRetryWaitTimeOnRateLimitedRequests = TimeSpan.FromSeconds(30),

        // Serialization settings
        SerializerOptions = new CosmosSerializationOptions
        {
            PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase,
            IgnoreNullValues = false
        }
    };

    // Configure Direct mode settings only for production (not emulator)
    if (!isEmulator)
    {
        // Best Practice 4.4: Connection management for production
        options.MaxRequestsPerTcpConnection = 30;
        options.MaxTcpConnectionsPerEndpoint = 65535;
        options.IdleTcpConnectionTimeout = TimeSpan.FromMinutes(10);
        options.EnableTcpConnectionEndpointRediscovery = true;
    }

    // Best Practice 4.6: SSL configuration for Cosmos DB Emulator
    if (isEmulator)
    {
        options.HttpClientFactory = () => new HttpClient(
            new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback =
                    HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
            });

        Console.WriteLine("⚠️ WARNING: Connected to Cosmos DB Emulator (localhost)");
        Console.WriteLine($"Endpoint: {endpoint}");
    }
    else
    {
        Console.WriteLine($"✓ Connected to Cosmos DB at: {endpoint}");
    }

    return new CosmosClient(endpoint, key, options);
});

// Register CosmosDbService
builder.Services.AddSingleton<CosmosDbService>();

var app = builder.Build();

// Initialize Cosmos DB on startup
using (var scope = app.Services.CreateScope())
{
    var cosmosDbService = scope.ServiceProvider.GetRequiredService<CosmosDbService>();
    await cosmosDbService.InitializeDatabaseAsync();
}

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();
