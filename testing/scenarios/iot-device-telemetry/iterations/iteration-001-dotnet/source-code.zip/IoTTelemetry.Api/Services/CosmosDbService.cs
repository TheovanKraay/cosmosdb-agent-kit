using Microsoft.Azure.Cosmos;
using IoTTelemetry.Api.Models;
using System.Collections.ObjectModel;

namespace IoTTelemetry.Api.Services;

/// <summary>
/// Cosmos DB service implementing ALL best practices from AGENTS.md
/// </summary>
public class CosmosDbService
{
    private readonly CosmosClient _client;
    private readonly Database _database;
    private readonly Container _devicesContainer;
    private readonly Container _telemetryContainer;
    private readonly ILogger<CosmosDbService> _logger;

    public CosmosDbService(CosmosClient client, IConfiguration configuration, ILogger<CosmosDbService> logger)
    {
        _client = client;
        _logger = logger;

        var databaseName = configuration["CosmosDb:DatabaseName"] ?? "IoTTelemetryDb";
        var devicesContainerName = configuration["CosmosDb:DevicesContainerName"] ?? "Devices";
        var telemetryContainerName = configuration["CosmosDb:TelemetryContainerName"] ?? "Telemetry";

        _database = _client.GetDatabase(databaseName);
        _devicesContainer = _database.GetContainer(devicesContainerName);
        _telemetryContainer = _database.GetContainer(telemetryContainerName);
    }

    #region Database Initialization

    /// <summary>
    /// Initializes database and containers with best practice configurations
    /// </summary>
    public async Task InitializeDatabaseAsync()
    {
        _logger.LogInformation("Initializing Cosmos DB database and containers...");

        // Create database with autoscale (Best Practice 6.1)
        // Autoscale for variable IoT workload (burst writes, periodic queries)
        var databaseResponse = await _client.CreateDatabaseIfNotExistsAsync(
            _database.Id,
            ThroughputProperties.CreateAutoscaleThroughput(4000)  // Max 4000 RU/s, scales 400-4000
        );

        _logger.LogInformation($"Database '{_database.Id}' ready. RU: {databaseResponse.Resource.Id}");

        // Create Devices container
        await CreateDevicesContainerAsync();

        // Create Telemetry container with TTL
        await CreateTelemetryContainerAsync();
    }

    private async Task CreateDevicesContainerAsync()
    {
        // Best Practice 5.2: Exclude unused paths to reduce write RU
        // Best Practice 5.1: Composite indexes for ORDER BY queries
        var containerProperties = new ContainerProperties
        {
            Id = _devicesContainer.Id,
            PartitionKeyPath = "/location",  // Best Practice 2.5: Align with query pattern

            IndexingPolicy = new IndexingPolicy
            {
                IndexingMode = IndexingMode.Consistent,  // Best Practice 5.3
                Automatic = true,

                // Include all paths by default for devices (simplify for devices container)
                IncludedPaths =
                {
                    new IncludedPath { Path = "/*" }
                },

                // Exclude large nested objects (Best Practice 5.2)
                ExcludedPaths =
                {
                    new ExcludedPath { Path = "/latestReading/*" }
                },

                // Composite index for location + registeredAt queries (Best Practice 5.1)
                CompositeIndexes =
                {
                    new Collection<CompositePath>
                    {
                        new CompositePath { Path = "/location", Order = CompositePathSortOrder.Ascending },
                        new CompositePath { Path = "/registeredAt", Order = CompositePathSortOrder.Descending }
                    }
                }
            }
        };

        await _database.CreateContainerIfNotExistsAsync(containerProperties);
        _logger.LogInformation($"Container '{_devicesContainer.Id}' ready with partition key: /location");
    }

    private async Task CreateTelemetryContainerAsync()
    {
        // Best Practice 2.6: Synthetic partition key (deviceId + yearMonth)
        // Best Practice TTL: Enable automatic data expiration
        var containerProperties = new ContainerProperties
        {
            Id = _telemetryContainer.Id,

            // Hierarchical partition key (Best Practice 2.3)
            // Level 1: deviceId, Level 2: yearMonth
            // This prevents 20GB limit per device (Best Practice 2.1)
            PartitionKeyPaths = new Collection<string> { "/deviceId", "/yearMonth" },

            // Enable TTL for 30-day retention (Requirement)
            DefaultTimeToLive = -1,  // -1 = per-document TTL enabled

            IndexingPolicy = new IndexingPolicy
            {
                IndexingMode = IndexingMode.Consistent,
                Automatic = true,

                // Include all paths
                IncludedPaths =
                {
                    new IncludedPath { Path = "/*" }
                },

                // Exclude telemetry values to reduce write RU (Best Practice 5.2)
                ExcludedPaths =
                {
                    new ExcludedPath { Path = "/temperature/?" },
                    new ExcludedPath { Path = "/humidity/?" },
                    new ExcludedPath { Path = "/batteryLevel/?" }
                },

                // Composite indexes for time-range queries (Best Practice 5.1)
                CompositeIndexes =
                {
                    new Collection<CompositePath>
                    {
                        new CompositePath { Path = "/deviceId", Order = CompositePathSortOrder.Ascending },
                        new CompositePath { Path = "/timestamp", Order = CompositePathSortOrder.Descending }
                    },
                    new Collection<CompositePath>
                    {
                        new CompositePath { Path = "/location", Order = CompositePathSortOrder.Ascending },
                        new CompositePath { Path = "/timestamp", Order = CompositePathSortOrder.Descending }
                    }
                }
            }
        };

        await _database.CreateContainerIfNotExistsAsync(containerProperties);
        _logger.LogInformation($"Container '{_telemetryContainer.Id}' ready with hierarchical partition key and TTL enabled");
    }

    #endregion

    #region Device Operations

    /// <summary>
    /// Create or update device (Best Practice 4.1: Async API)
    /// </summary>
    public async Task<Device> UpsertDeviceAsync(Device device)
    {
        try
        {
            var response = await _devicesContainer.UpsertItemAsync(
                device,
                new PartitionKey(device.Location)
            );

            // Best Practice 4.5: Log diagnostics for monitoring
            LogOperationDiagnostics("UpsertDevice", response);

            return response.Resource;
        }
        catch (CosmosException ex)
        {
            LogCosmosException("UpsertDevice", ex);
            throw;
        }
    }

    /// <summary>
    /// Get device by deviceId and location (single partition read - efficient)
    /// Best Practice 3.1: Minimize cross-partition queries
    /// </summary>
    public async Task<Device?> GetDeviceAsync(string deviceId, string location)
    {
        try
        {
            // Best Practice 3.5: Use parameterized queries
            var query = new QueryDefinition(
                "SELECT * FROM c WHERE c.deviceId = @deviceId AND c.type = 'device'"
            ).WithParameter("@deviceId", deviceId);

            // Best Practice 3.1: Single-partition query with partition key
            var iterator = _devicesContainer.GetItemQueryIterator<Device>(
                query,
                requestOptions: new QueryRequestOptions
                {
                    PartitionKey = new PartitionKey(location)  // Single partition!
                }
            );

            var response = await iterator.ReadNextAsync();

            LogQueryDiagnostics("GetDevice", response);

            return response.FirstOrDefault();
        }
        catch (CosmosException ex)
        {
            LogCosmosException("GetDevice", ex);
            throw;
        }
    }

    /// <summary>
    /// Get all devices in a specific location (single partition query)
    /// Best Practice 2.5: Partition key aligned with query pattern
    /// </summary>
    public async Task<List<Device>> GetDevicesByLocationAsync(string location)
    {
        try
        {
            // Best Practice 3.5: Parameterized query
            var query = new QueryDefinition(
                "SELECT * FROM c WHERE c.type = 'device' ORDER BY c.registeredAt DESC"
            );

            // Single-partition query (Best Practice 3.1)
            var iterator = _devicesContainer.GetItemQueryIterator<Device>(
                query,
                requestOptions: new QueryRequestOptions
                {
                    PartitionKey = new PartitionKey(location),
                    MaxItemCount = 100  // Best Practice 3.4: Pagination
                }
            );

            var devices = new List<Device>();
            double totalRU = 0;

            while (iterator.HasMoreResults)
            {
                var response = await iterator.ReadNextAsync();
                devices.AddRange(response);
                totalRU += response.RequestCharge;
            }

            _logger.LogInformation($"GetDevicesByLocation: {devices.Count} devices, {totalRU:F2} RU");

            return devices;
        }
        catch (CosmosException ex)
        {
            LogCosmosException("GetDevicesByLocation", ex);
            throw;
        }
    }

    #endregion

    #region Telemetry Operations

    /// <summary>
    /// Ingest single telemetry reading
    /// Best Practice 4.1: Async API
    /// </summary>
    public async Task<TelemetryReading> CreateTelemetryReadingAsync(TelemetryReading reading)
    {
        try
        {
            // Use hierarchical partition key (Best Practice 2.3)
            var partitionKey = new PartitionKeyBuilder()
                .Add(reading.DeviceId)
                .Add(reading.YearMonth)
                .Build();

            var response = await _telemetryContainer.CreateItemAsync(
                reading,
                partitionKey
            );

            LogOperationDiagnostics("CreateTelemetry", response);

            // Update device's latest reading (denormalization - Best Practice 1.2)
            await UpdateDeviceLatestReadingAsync(reading);

            return response.Resource;
        }
        catch (CosmosException ex)
        {
            LogCosmosException("CreateTelemetry", ex);
            throw;
        }
    }

    /// <summary>
    /// Bulk ingestion using batch operations (Best Practice for high throughput)
    /// </summary>
    public async Task<int> BulkCreateTelemetryReadingsAsync(List<TelemetryReading> readings)
    {
        try
        {
            _logger.LogInformation($"Bulk ingesting {readings.Count} telemetry readings...");

            // Group by partition key for efficient batch operations
            var groupedByPartition = readings.GroupBy(r => r.PartitionKey);

            var tasks = new List<Task>();
            var successCount = 0;

            foreach (var group in groupedByPartition)
            {
                // Process each partition group concurrently (Best Practice 4.1: Async)
                // Limit concurrency to avoid overwhelming the client
                foreach (var reading in group)
                {
                    var partitionKey = new PartitionKeyBuilder()
                        .Add(reading.DeviceId)
                        .Add(reading.YearMonth)
                        .Build();

                    tasks.Add(_telemetryContainer.CreateItemAsync(reading, partitionKey));

                    // Best Practice: Batch in groups to control concurrency
                    if (tasks.Count >= 100)
                    {
                        await Task.WhenAll(tasks);
                        successCount += tasks.Count;
                        tasks.Clear();
                    }
                }
            }

            // Complete remaining
            if (tasks.Any())
            {
                await Task.WhenAll(tasks);
                successCount += tasks.Count;
            }

            _logger.LogInformation($"Bulk ingestion complete: {successCount} readings created");

            return successCount;
        }
        catch (CosmosException ex)
        {
            LogCosmosException("BulkCreateTelemetry", ex);
            throw;
        }
    }

    /// <summary>
    /// Get latest reading for a device
    /// Best Practice 3.1: Single partition query
    /// </summary>
    public async Task<TelemetryReading?> GetLatestReadingAsync(string deviceId)
    {
        try
        {
            // Query current month's partition first
            var currentYearMonth = DateTime.UtcNow.ToString("yyyy-MM");

            // Best Practice 3.6: Project only needed fields for efficiency
            var query = new QueryDefinition(
                "SELECT TOP 1 * FROM c WHERE c.deviceId = @deviceId AND c.type = 'telemetry' ORDER BY c.timestamp DESC"
            ).WithParameter("@deviceId", deviceId);

            var partitionKey = new PartitionKeyBuilder()
                .Add(deviceId)
                .Add(currentYearMonth)
                .Build();

            var iterator = _telemetryContainer.GetItemQueryIterator<TelemetryReading>(
                query,
                requestOptions: new QueryRequestOptions
                {
                    PartitionKey = partitionKey,
                    MaxItemCount = 1
                }
            );

            var response = await iterator.ReadNextAsync();
            LogQueryDiagnostics("GetLatestReading", response);

            return response.FirstOrDefault();
        }
        catch (CosmosException ex)
        {
            LogCosmosException("GetLatestReading", ex);
            throw;
        }
    }

    /// <summary>
    /// Get readings for device within time range
    /// Best Practice 3.1: Single partition query for current month
    /// Best Practice 3.3: Order filters by selectivity
    /// </summary>
    public async Task<List<TelemetryReading>> GetReadingsByTimeRangeAsync(
        string deviceId,
        DateTime startTime,
        DateTime endTime)
    {
        try
        {
            var readings = new List<TelemetryReading>();
            double totalRU = 0;

            // Calculate which month partitions to query
            var monthsToQuery = GetMonthsInRange(startTime, endTime);

            foreach (var yearMonth in monthsToQuery)
            {
                // Best Practice 3.5: Parameterized query
                // Best Practice 3.3: Most selective filter first (deviceId + timestamp)
                var query = new QueryDefinition(@"
                    SELECT * FROM c 
                    WHERE c.deviceId = @deviceId 
                    AND c.type = 'telemetry'
                    AND c.timestamp >= @startTime 
                    AND c.timestamp <= @endTime
                    ORDER BY c.timestamp DESC
                ")
                .WithParameter("@deviceId", deviceId)
                .WithParameter("@startTime", startTime)
                .WithParameter("@endTime", endTime);

                var partitionKey = new PartitionKeyBuilder()
                    .Add(deviceId)
                    .Add(yearMonth)
                    .Build();

                var iterator = _telemetryContainer.GetItemQueryIterator<TelemetryReading>(
                    query,
                    requestOptions: new QueryRequestOptions
                    {
                        PartitionKey = partitionKey,  // Single partition per iteration
                        MaxItemCount = 100  // Best Practice 3.4: Pagination
                    }
                );

                while (iterator.HasMoreResults)
                {
                    var response = await iterator.ReadNextAsync();
                    readings.AddRange(response);
                    totalRU += response.RequestCharge;
                }
            }

            _logger.LogInformation($"GetReadingsByTimeRange: {readings.Count} readings, {totalRU:F2} RU");

            return readings;
        }
        catch (CosmosException ex)
        {
            LogCosmosException("GetReadingsByTimeRange", ex);
            throw;
        }
    }

    /// <summary>
    /// Update device's latest reading (denormalization pattern - Best Practice 1.2)
    /// </summary>
    private async Task UpdateDeviceLatestReadingAsync(TelemetryReading reading)
    {
        try
        {
            // Get device to update
            var device = await GetDeviceAsync(reading.DeviceId, reading.Location);
            if (device != null)
            {
                // Update denormalized latest reading (Best Practice 1.2)
                device.LatestReading = new TelemetrySummary
                {
                    Timestamp = reading.Timestamp,
                    Temperature = reading.Temperature,
                    Humidity = reading.Humidity,
                    BatteryLevel = reading.BatteryLevel
                };

                await _devicesContainer.UpsertItemAsync(
                    device,
                    new PartitionKey(device.Location)
                );
            }
        }
        catch (Exception ex)
        {
            // Don't fail the telemetry write if denormalization fails
            _logger.LogWarning(ex, $"Failed to update device latest reading for device {reading.DeviceId}");
        }
    }

    #endregion

    #region Helper Methods

    private static List<string> GetMonthsInRange(DateTime startTime, DateTime endTime)
    {
        var months = new List<string>();
        var current = new DateTime(startTime.Year, startTime.Month, 1);
        var end = new DateTime(endTime.Year, endTime.Month, 1);

        while (current <= end)
        {
            months.Add(current.ToString("yyyy-MM"));
            current = current.AddMonths(1);
        }

        return months;
    }

    /// <summary>
    /// Best Practice 4.5: Log diagnostics for troubleshooting
    /// </summary>
    private void LogOperationDiagnostics<T>(string operationName, ItemResponse<T> response)
    {
        var latencyMs = response.Diagnostics.GetClientElapsedTime().TotalMilliseconds;
        var ru = response.RequestCharge;

        _logger.LogDebug(
            "{Operation}: {LatencyMs}ms, {RU:F2} RU",
            operationName,
            latencyMs,
            ru
        );

        // Best Practice 4.5: Log full diagnostics for slow operations
        if (latencyMs > 100)
        {
            _logger.LogWarning(
                "{Operation} slow: {LatencyMs}ms, Diagnostics: {Diagnostics}",
                operationName,
                latencyMs,
                response.Diagnostics.ToString()
            );
        }
    }

    private void LogQueryDiagnostics<T>(string operationName, FeedResponse<T> response)
    {
        var latencyMs = response.Diagnostics.GetClientElapsedTime().TotalMilliseconds;
        var ru = response.RequestCharge;

        _logger.LogDebug(
            "{Operation}: {Count} items, {LatencyMs}ms, {RU:F2} RU",
            operationName,
            response.Count,
            latencyMs,
            ru
        );
    }

    /// <summary>
    /// Best Practice 4.5: Log diagnostics on errors
    /// Best Practice 4.11: Handle 429 errors with Retry-After
    /// </summary>
    private void LogCosmosException(string operationName, CosmosException ex)
    {
        _logger.LogError(ex,
            "{Operation} failed: Status={StatusCode}, SubStatus={SubStatus}, " +
            "RU={RU}, RetryAfter={RetryAfter}, ActivityId={ActivityId}, Diagnostics={Diagnostics}",
            operationName,
            ex.StatusCode,
            ex.SubStatusCode,
            ex.RequestCharge,
            ex.RetryAfter,
            ex.ActivityId,
            ex.Diagnostics?.ToString()
        );
    }

    #endregion
}
