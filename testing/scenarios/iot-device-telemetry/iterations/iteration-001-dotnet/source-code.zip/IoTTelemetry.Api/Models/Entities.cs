using System.Text.Json.Serialization;

namespace IoTTelemetry.Api.Models;

/// <summary>
/// Base entity implementing type discriminator pattern (Best Practice 1.6)
/// </summary>
public abstract class BaseEntity
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = Guid.NewGuid().ToString();

    /// <summary>
    /// Type discriminator for polymorphic data (Best Practice 1.6)
    /// </summary>
    [JsonPropertyName("type")]
    public abstract string Type { get; }

    [JsonPropertyName("partitionKey")]
    public abstract string PartitionKey { get; }
}

/// <summary>
/// Device metadata model
/// Partition Key: /location - enables efficient queries by facility (Requirement #5)
/// Best Practice 2.4: High cardinality partition key (many locations)
/// Best Practice 2.5: Aligned with "devices by location" query pattern
/// </summary>
public class Device : BaseEntity
{
    public override string Type => "device";

    [JsonPropertyName("deviceId")]
    public string DeviceId { get; set; } = string.Empty;

    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;

    [JsonPropertyName("location")]
    public string Location { get; set; } = string.Empty;

    [JsonPropertyName("deviceType")]
    public string DeviceType { get; set; } = string.Empty;

    [JsonPropertyName("registeredAt")]
    public DateTime RegisteredAt { get; set; } = DateTime.UtcNow;

    [JsonPropertyName("isActive")]
    public bool IsActive { get; set; } = true;

    /// <summary>
    /// Partition key is location for efficient location-based queries
    /// </summary>
    public override string PartitionKey => Location;

    /// <summary>
    /// Denormalized latest reading summary (Best Practice 1.2)
    /// Avoids join for quick device status display
    /// </summary>
    [JsonPropertyName("latestReading")]
    public TelemetrySummary? LatestReading { get; set; }
}

/// <summary>
/// Embedded summary of latest telemetry (Best Practice 1.3)
/// Embedded data retrieved together with device
/// </summary>
public class TelemetrySummary
{
    [JsonPropertyName("timestamp")]
    public DateTime Timestamp { get; set; }

    [JsonPropertyName("temperature")]
    public double Temperature { get; set; }

    [JsonPropertyName("humidity")]
    public double Humidity { get; set; }

    [JsonPropertyName("batteryLevel")]
    public double BatteryLevel { get; set; }
}

/// <summary>
/// Telemetry reading model - Time-series data
/// Partition Key: Synthetic key combining deviceId + yearMonth (Best Practice 2.6)
/// This prevents:
/// - Hot partition on current time (Best Practice 2.2)
/// - 20GB partition limit per device (Best Practice 2.1)
/// Enables:
/// - Efficient time-range queries per device (Best Practice 2.5)
/// - Automatic data distribution across time buckets
/// </summary>
public class TelemetryReading : BaseEntity
{
    public override string Type => "telemetry";

    [JsonPropertyName("deviceId")]
    public string DeviceId { get; set; } = string.Empty;

    [JsonPropertyName("timestamp")]
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;

    [JsonPropertyName("temperature")]
    public double Temperature { get; set; }

    [JsonPropertyName("humidity")]
    public double Humidity { get; set; }

    [JsonPropertyName("batteryLevel")]
    public double BatteryLevel { get; set; }

    /// <summary>
    /// Year-month bucket for partition key (Best Practice 2.1, 2.6)
    /// Prevents unbounded partition growth
    /// </summary>
    [JsonPropertyName("yearMonth")]
    public string YearMonth => Timestamp.ToString("yyyy-MM");

    /// <summary>
    /// Synthetic partition key: deviceId + yearMonth (Best Practice 2.6)
    /// This pattern:
    /// 1. Groups readings by device AND time period
    /// 2. Prevents any single partition from exceeding 20GB
    /// 3. Enables efficient time-range queries within partition
    /// 4. Distributes writes across many partitions (avoids hot partition)
    /// </summary>
    public override string PartitionKey => $"{DeviceId}_{YearMonth}";

    /// <summary>
    /// TTL in seconds (30 days = 2,592,000 seconds)
    /// Best Practice: Use TTL for automatic data expiration
    /// Requirement: 30-day retention policy
    /// </summary>
    [JsonPropertyName("ttl")]
    public int Ttl { get; set; } = 2592000;  // 30 days in seconds

    /// <summary>
    /// Denormalized device location (Best Practice 1.2)
    /// Enables queries by location without joining to Device
    /// </summary>
    [JsonPropertyName("location")]
    public string Location { get; set; } = string.Empty;
}

/// <summary>
/// Bulk ingestion request model
/// </summary>
public class BulkTelemetryRequest
{
    public List<TelemetryReading> Readings { get; set; } = new();
}
