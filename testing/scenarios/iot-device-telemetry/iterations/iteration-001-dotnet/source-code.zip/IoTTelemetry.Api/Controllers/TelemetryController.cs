using Microsoft.AspNetCore.Mvc;
using IoTTelemetry.Api.Models;
using IoTTelemetry.Api.Services;

namespace IoTTelemetry.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TelemetryController : ControllerBase
{
    private readonly CosmosDbService _cosmosDbService;
    private readonly ILogger<TelemetryController> _logger;

    public TelemetryController(CosmosDbService cosmosDbService, ILogger<TelemetryController> logger)
    {
        _cosmosDbService = cosmosDbService;
        _logger = logger;
    }

    /// <summary>
    /// Ingest a single telemetry reading
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<TelemetryReading>> CreateReading([FromBody] TelemetryReading reading)
    {
        try
        {
            var result = await _cosmosDbService.CreateTelemetryReadingAsync(reading);
            return CreatedAtAction(nameof(GetLatestReading), new { deviceId = result.DeviceId }, result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating telemetry reading");
            return StatusCode(500, new { error = "Failed to create telemetry reading", details = ex.Message });
        }
    }

    /// <summary>
    /// Bulk ingestion of telemetry readings
    /// </summary>
    [HttpPost("bulk")]
    public async Task<ActionResult> BulkCreateReadings([FromBody] BulkTelemetryRequest request)
    {
        try
        {
            var successCount = await _cosmosDbService.BulkCreateTelemetryReadingsAsync(request.Readings);
            return Ok(new
            {
                totalRequested = request.Readings.Count,
                successCount = successCount,
                message = $"Successfully ingested {successCount} readings"
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in bulk telemetry ingestion");
            return StatusCode(500, new { error = "Failed to bulk ingest readings", details = ex.Message });
        }
    }

    /// <summary>
    /// Get latest reading for a specific device
    /// </summary>
    [HttpGet("device/{deviceId}/latest")]
    public async Task<ActionResult<TelemetryReading>> GetLatestReading(string deviceId)
    {
        try
        {
            var reading = await _cosmosDbService.GetLatestReadingAsync(deviceId);
            if (reading == null)
            {
                return NotFound(new { error = $"No readings found for device {deviceId}" });
            }

            return Ok(reading);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving latest reading");
            return StatusCode(500, new { error = "Failed to retrieve latest reading", details = ex.Message });
        }
    }

    /// <summary>
    /// Get readings for a device within a time range
    /// </summary>
    [HttpGet("device/{deviceId}/range")]
    public async Task<ActionResult<List<TelemetryReading>>> GetReadingsByTimeRange(
        string deviceId,
        [FromQuery] DateTime startTime,
        [FromQuery] DateTime endTime)
    {
        if (startTime >= endTime)
        {
            return BadRequest(new { error = "startTime must be before endTime" });
        }

        try
        {
            var readings = await _cosmosDbService.GetReadingsByTimeRangeAsync(deviceId, startTime, endTime);
            return Ok(new
            {
                deviceId = deviceId,
                startTime = startTime,
                endTime = endTime,
                count = readings.Count,
                readings = readings
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving readings by time range");
            return StatusCode(500, new { error = "Failed to retrieve readings", details = ex.Message });
        }
    }
}
