using Microsoft.AspNetCore.Mvc;
using IoTTelemetry.Api.Models;
using IoTTelemetry.Api.Services;

namespace IoTTelemetry.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DevicesController : ControllerBase
{
    private readonly CosmosDbService _cosmosDbService;
    private readonly ILogger<DevicesController> _logger;

    public DevicesController(CosmosDbService cosmosDbService, ILogger<DevicesController> logger)
    {
        _cosmosDbService = cosmosDbService;
        _logger = logger;
    }

    /// <summary>
    /// Create or update a device
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<Device>> UpsertDevice([FromBody] Device device)
    {
        try
        {
            var result = await _cosmosDbService.UpsertDeviceAsync(device);
            return Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating/updating device");
            return StatusCode(500, new { error = "Failed to create/update device", details = ex.Message });
        }
    }

    /// <summary>
    /// Get device by deviceId and location
    /// </summary>
    [HttpGet("{deviceId}")]
    public async Task<ActionResult<Device>> GetDevice(string deviceId, [FromQuery] string location)
    {
        if (string.IsNullOrEmpty(location))
        {
            return BadRequest(new { error = "Location parameter is required" });
        }

        try
        {
            var device = await _cosmosDbService.GetDeviceAsync(deviceId, location);
            if (device == null)
            {
                return NotFound(new { error = $"Device {deviceId} not found in location {location}" });
            }

            return Ok(device);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving device");
            return StatusCode(500, new { error = "Failed to retrieve device", details = ex.Message });
        }
    }

    /// <summary>
    /// Get all devices in a specific facility/location
    /// </summary>
    [HttpGet("location/{location}")]
    public async Task<ActionResult<List<Device>>> GetDevicesByLocation(string location)
    {
        try
        {
            var devices = await _cosmosDbService.GetDevicesByLocationAsync(location);
            return Ok(new
            {
                location = location,
                count = devices.Count,
                devices = devices
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving devices by location");
            return StatusCode(500, new { error = "Failed to retrieve devices", details = ex.Message });
        }
    }
}
