package com.cosmosdb.iot.repository;

import com.azure.cosmos.CosmosAsyncContainer;
import com.azure.cosmos.CosmosAsyncDatabase;
import com.azure.cosmos.models.*;
import com.cosmosdb.iot.model.Device;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Arrays;

/**
 * Repository for Device operations.
 * 
 * Best Practices Applied:
 * - 4.1: Use async APIs
 * - 3.1: Single-partition queries
 * - 3.5: Parameterized queries
 * - 4.5: Log diagnostics
 */
@Slf4j
@Repository
public class DeviceRepository {
    
    private final CosmosAsyncContainer container;
    
    public DeviceRepository(CosmosAsyncDatabase database) {
        this.container = database.getContainer("devices");
    }
    
    /**
     * Create a new device.
     * Rule 4.8: contentResponseOnWriteEnabled returns created device
     */
    public Mono<Device> createDevice(Device device) {
        // Ensure ID is set to deviceId
        if (device.getId() == null) {
            device.setId(device.getDeviceId());
        }
        
        PartitionKey partitionKey = new PartitionKey(device.getDeviceId());
        
        return container.createItem(device, partitionKey, new CosmosItemRequestOptions())
            .doOnSuccess(response -> {
                log.debug("Created device: deviceId={}, RU={}", 
                    device.getDeviceId(), response.getRequestCharge());
            })
            .doOnError(error -> {
                log.error("Error creating device: {}", device.getDeviceId(), error);
            })
            .map(CosmosItemResponse::getItem);
    }
    
    /**
     * Get device by ID.
     * Rule 3.1: Point read - most efficient operation (1 RU for <1KB item)
     */
    public Mono<Device> getDevice(String deviceId) {
        PartitionKey partitionKey = new PartitionKey(deviceId);
        
        return container.readItem(deviceId, partitionKey, Device.class)
            .doOnSuccess(response -> {
                log.debug("Read device: deviceId={}, RU={}", deviceId, response.getRequestCharge());
            })
            .map(CosmosItemResponse::getItem);
    }
    
    /**
     * Update an existing device.
     */
    public Mono<Device> updateDevice(Device device) {
        PartitionKey partitionKey = new PartitionKey(device.getDeviceId());
        
        return container.upsertItem(device, partitionKey, new CosmosItemRequestOptions())
            .doOnSuccess(response -> {
                log.debug("Updated device: deviceId={}, RU={}", 
                    device.getDeviceId(), response.getRequestCharge());
            })
            .map(CosmosItemResponse::getItem);
    }
    
    /**
     * Query devices by location.
     * Rule 3.1: Cross-partition query (no partition key filter)
     * Rule 3.5: Parameterized query
     */
    public Flux<Device> getDevicesByLocation(String location) {
        String query = "SELECT * FROM c WHERE c.location = @location AND c.type = 'device'";
        
        SqlQuerySpec querySpec = new SqlQuerySpec(query)
            .setParameters(Arrays.asList(
                new SqlParameter("@location", location)
            ));
        
        CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();
        
        log.info("Querying devices by location (cross-partition): {}", location);
        
        return container.queryItems(querySpec, options, Device.class)
            .byPage()
            .flatMap(page -> {
                log.debug("Location query page: location={}, count={}, RU={}",
                    location, page.getResults().size(), page.getRequestCharge());
                return Flux.fromIterable(page.getResults());
            });
    }
    
    /**
     * Delete a device.
     */
    public Mono<Void> deleteDevice(String deviceId) {
        PartitionKey partitionKey = new PartitionKey(deviceId);
        
        return container.deleteItem(deviceId, partitionKey, new CosmosItemRequestOptions())
            .doOnSuccess(response -> {
                log.debug("Deleted device: deviceId={}, RU={}", deviceId, response.getRequestCharge());
            })
            .then();
    }
    
    /**
     * Get all devices (for testing/admin).
     * Warning: Cross-partition query - use sparingly!
     */
    public Flux<Device> getAllDevices() {
        String query = "SELECT * FROM c WHERE c.type = 'device'";
        
        SqlQuerySpec querySpec = new SqlQuerySpec(query);
        
        CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();
        
        log.warn("Executing cross-partition query for all devices");
        
        return container.queryItems(querySpec, options, Device.class)
            .byPage()
            .flatMap(page -> {
                log.debug("All devices query page: count={}, RU={}",
                    page.getResults().size(), page.getRequestCharge());
                return Flux.fromIterable(page.getResults());
            });
    }
}
