package com.cosmosdb.iot.controller;

import com.cosmosdb.iot.model.Device;
import com.cosmosdb.iot.repository.DeviceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;

/**
 * REST Controller for Device operations.
 */
@Slf4j
@RestController
@RequestMapping("/api/devices")
@RequiredArgsConstructor
public class DeviceController {
    
    private final DeviceRepository deviceRepository;
    
    /**
     * Create a new device.
     */
    @PostMapping
    public Mono<ResponseEntity<Device>> createDevice(@Valid @RequestBody Device device) {
        log.info("Creating device: {}", device.getDeviceId());
        
        return deviceRepository.createDevice(device)
            .map(created -> ResponseEntity.status(HttpStatus.CREATED).body(created))
            .onErrorResume(error -> {
                log.error("Error creating device", error);
                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build());
            });
    }
    
    /**
     * Get device by ID.
     */
    @GetMapping("/{deviceId}")
    public Mono<ResponseEntity<Device>> getDevice(@PathVariable String deviceId) {
        log.info("Getting device: {}", deviceId);
        
        return deviceRepository.getDevice(deviceId)
            .map(ResponseEntity::ok)
            .defaultIfEmpty(ResponseEntity.notFound().build())
            .onErrorResume(error -> {
                log.error("Error getting device: {}", deviceId, error);
                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build());
            });
    }
    
    /**
     * Update an existing device.
     */
    @PutMapping("/{deviceId}")
    public Mono<ResponseEntity<Device>> updateDevice(
        @PathVariable String deviceId, 
        @Valid @RequestBody Device device
    ) {
        log.info("Updating device: {}", deviceId);
        
        device.setDeviceId(deviceId);  // Ensure deviceId matches path parameter
        device.setId(deviceId);
        
        return deviceRepository.updateDevice(device)
            .map(ResponseEntity::ok)
            .onErrorResume(error -> {
                log.error("Error updating device: {}", deviceId, error);
                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build());
            });
    }
    
    /**
     * Get all devices in a specific location.
     * Note: This is a cross-partition query - expensive at scale!
     */
    @GetMapping("/by-location/{location}")
    public Flux<Device> getDevicesByLocation(@PathVariable String location) {
        log.info("Getting devices by location: {}", location);
        
        return deviceRepository.getDevicesByLocation(location)
            .onErrorResume(error -> {
                log.error("Error querying devices by location: {}", location, error);
                return Flux.empty();
            });
    }
    
    /**
     * Get all devices (admin endpoint - use sparingly!).
     * Warning: Cross-partition query!
     */
    @GetMapping
    public Flux<Device> getAllDevices() {
        log.warn("Getting all devices (cross-partition query)");
        
        return deviceRepository.getAllDevices()
            .onErrorResume(error -> {
                log.error("Error getting all devices", error);
                return Flux.empty();
            });
    }
    
    /**
     * Delete a device.
     */
    @DeleteMapping("/{deviceId}")
    public Mono<ResponseEntity<Void>> deleteDevice(@PathVariable String deviceId) {
        log.info("Deleting device: {}", deviceId);
        
        return deviceRepository.deleteDevice(deviceId)
            .then(Mono.just(ResponseEntity.noContent().<Void>build()))
            .onErrorResume(error -> {
                log.error("Error deleting device: {}", deviceId, error);
                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build());
            });
    }
}
