package com.cosmosdb.iot.repository;

import com.azure.cosmos.CosmosAsyncContainer;
import com.azure.cosmos.CosmosAsyncDatabase;
import com.azure.cosmos.models.*;
import com.azure.cosmos.util.CosmosPagedFlux;
import com.cosmosdb.iot.model.TelemetryReading;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Repository for TelemetryReading operations.
 * 
 * Best Practices Applied:
 * - 4.1: Use async APIs for better throughput
 * - 3.1: Minimize cross-partition queries (all queries include partition key)
 * - 3.4: Use continuation tokens for pagination
 * - 3.5: Use parameterized queries
 * - 3.6: Project only needed fields when appropriate
 * - 4.5: Log diagnostics for troubleshooting
 */
@Slf4j
@Repository
public class TelemetryRepository {
    
    private final CosmosAsyncContainer container;
    
    public TelemetryRepository(CosmosAsyncDatabase database) {
        this.container = database.getContainer("telemetry");
    }
    
    /**
     * Create a single telemetry reading.
     * Rule 4.1: Async API
     * Rule 4.8: contentResponseOnWriteEnabled returns created item
     */
    public Mono<TelemetryReading> createReading(TelemetryReading reading) {
        // Ensure yearMonth is set
        if (reading.getYearMonth() == null) {
            reading.setYearMonth(TelemetryReading.generateYearMonth(reading.getTimestamp()));
        }
        
        // Ensure ID is set
        if (reading.getId() == null) {
            reading.setId(TelemetryReading.generateId(reading.getDeviceId(), reading.getTimestamp()));
        }
        
        // Create hierarchical partition key
        PartitionKey partitionKey = new PartitionKeyBuilder()
            .add(reading.getDeviceId())
            .add(reading.getYearMonth())
            .build();
        
        return container.createItem(reading, partitionKey, new CosmosItemRequestOptions())
            .doOnSuccess(response -> {
                log.debug("Created telemetry reading: deviceId={}, timestamp={}, RU={}",
                    reading.getDeviceId(), reading.getTimestamp(), response.getRequestCharge());
            })
            .doOnError(error -> {
                log.error("Error creating telemetry reading for device: {}", reading.getDeviceId(), error);
            })
            .map(CosmosItemResponse::getItem);
    }
    
    /**
     * Bulk insert telemetry readings for high-throughput ingestion.
     * Rule 4.1: Async bulk operations
     */
    public Flux<TelemetryReading> createReadingsBulk(List<TelemetryReading> readings) {
        log.info("Bulk creating {} telemetry readings", readings.size());
        
        return Flux.fromIterable(readings)
            .flatMap(reading -> {
                // Ensure yearMonth is set
                if (reading.getYearMonth() == null) {
                    reading.setYearMonth(TelemetryReading.generateYearMonth(reading.getTimestamp()));
                }
                
                // Ensure ID is set
                if (reading.getId() == null) {
                    reading.setId(TelemetryReading.generateId(reading.getDeviceId(), reading.getTimestamp()));
                }
                
                // Create hierarchical partition key
                PartitionKey partitionKey = new PartitionKeyBuilder()
                    .add(reading.getDeviceId())
                    .add(reading.getYearMonth())
                    .build();
                
                return container.createItem(reading, partitionKey, new CosmosItemRequestOptions())
                    .map(CosmosItemResponse::getItem);
            }, 10);  // Concurrency of 10 for bulk operations
    }
    
    /**
     * Get the latest reading for a specific device.
     * Rule 3.1: Single-partition query (includes deviceId)
     * Rule 3.5: Parameterized query
     * Rule 5.1: Uses composite index on deviceId + timestamp DESC
     */
    public Mono<TelemetryReading> getLatestReading(String deviceId, String yearMonth) {
        // Rule 3.5: Parameterized query
        String query = "SELECT TOP 1 * FROM c WHERE c.deviceId = @deviceId AND c.yearMonth = @yearMonth ORDER BY c.timestamp DESC";
        
        SqlQuerySpec querySpec = new SqlQuerySpec(query)
            .setParameters(Arrays.asList(
                new SqlParameter("@deviceId", deviceId),
                new SqlParameter("@yearMonth", yearMonth)
            ));
        
        // Rule 3.1: Single-partition query with hierarchical partition key
        PartitionKey partitionKey = new PartitionKeyBuilder()
            .add(deviceId)
            .add(yearMonth)
            .build();
        
        CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();
        options.setPartitionKey(partitionKey);
        
        return container.queryItems(querySpec, options, TelemetryReading.class)
            .byPage()
            .next()
            .flatMap(response -> {
                log.debug("Latest reading query: deviceId={}, RU={}", 
                    deviceId, response.getRequestCharge());
                
                List<TelemetryReading> results = response.getResults();
                if (results != null && !results.isEmpty()) {
                    return Mono.just(results.get(0));
                }
                return Mono.empty();
            });
    }
    
    /**
     * Query readings for a device within a time range.
     * Rule 3.1: Single-partition query (deviceId + yearMonth)
     * Rule 3.4: Pagination with continuation tokens
     * Rule 3.5: Parameterized query
     */
    public Flux<TelemetryReading> getReadingsByTimeRange(
        String deviceId, 
        String yearMonth,
        long startTimestamp, 
        long endTimestamp
    ) {
        // Rule 3.5: Parameterized query
        String query = "SELECT * FROM c WHERE c.deviceId = @deviceId AND c.yearMonth = @yearMonth " +
                      "AND c.timestamp >= @start AND c.timestamp < @end ORDER BY c.timestamp DESC";
        
        SqlQuerySpec querySpec = new SqlQuerySpec(query)
            .setParameters(Arrays.asList(
                new SqlParameter("@deviceId", deviceId),
                new SqlParameter("@yearMonth", yearMonth),
                new SqlParameter("@start", startTimestamp),
                new SqlParameter("@end", endTimestamp)
            ));
        
        // Rule 3.1: Single-partition query
        PartitionKey partitionKey = new PartitionKeyBuilder()
            .add(deviceId)
            .add(yearMonth)
            .build();
        
        CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();
        options.setPartitionKey(partitionKey);
        
        // Rule 3.4: Automatic continuation token handling via Flux
        return container.queryItems(querySpec, options, TelemetryReading.class)
            .byPage()
            .flatMap(page -> {
                log.debug("Time range query page: deviceId={}, count={}, RU={}",
                    deviceId, page.getResults().size(), page.getRequestCharge());
                return Flux.fromIterable(page.getResults());
            });
    }
    
    /**
     * Query all devices in a specific location (cross-partition query).
     * Rule 3.1: Note - this is intentionally cross-partition for location-based queries
     * Rule 3.5: Parameterized query
     * Rule 5.1: Uses composite index on location + timestamp
     */
    public Flux<TelemetryReading> getReadingsByLocation(String location, int limit) {
        // Rule 3.5: Parameterized query
        String query = String.format(
            "SELECT TOP %d * FROM c WHERE c.location = @location ORDER BY c.timestamp DESC", 
            limit
        );
        
        SqlQuerySpec querySpec = new SqlQuerySpec(query)
            .setParameters(Arrays.asList(
                new SqlParameter("@location", location)
            ));
        
        CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();
        
        log.warn("Executing cross-partition query for location: {}", location);
        
        return container.queryItems(querySpec, options, TelemetryReading.class)
            .byPage()
            .flatMap(page -> {
                log.debug("Location query page: location={}, count={}, RU={}",
                    location, page.getResults().size(), page.getRequestCharge());
                return Flux.fromIterable(page.getResults());
            });
    }
    
    /**
     * Delete a telemetry reading by ID.
     */
    public Mono<Void> deleteReading(String id, String deviceId, String yearMonth) {
        PartitionKey partitionKey = new PartitionKeyBuilder()
            .add(deviceId)
            .add(yearMonth)
            .build();
        
        return container.deleteItem(id, partitionKey, new CosmosItemRequestOptions())
            .doOnSuccess(response -> {
                log.debug("Deleted telemetry reading: id={}, RU={}", id, response.getRequestCharge());
            })
            .then();
    }
}
