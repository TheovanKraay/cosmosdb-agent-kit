package com.cosmosdb.iot.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Telemetry reading from an IoT device.
 * 
 * Best Practices Applied:
 * - 2.1: Hierarchical partition key prevents 20GB limit (deviceId + yearMonth)
 * - 2.2: Synthetic partition key distributes writes (deviceId + time bucket)
 * - 2.3: Hierarchical partition key for time-series data
 * - 2.5: Partition key aligned with query pattern (device + time range queries)
 * - 1.3: Embedded device summary for denormalization
 * - 1.5: Schema version for future evolution
 * - 1.6: Type discriminator
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TelemetryReading {
    
    @JsonProperty("id")
    private String id;  // Unique reading ID (timestamp + deviceId)
    
    @JsonProperty("type")
    private String type = "telemetry";  // Type discriminator (rule 1.6)
    
    @JsonProperty("schemaVersion")
    private int schemaVersion = 1;  // Schema versioning (rule 1.5)
    
    // Hierarchical partition key components (rule 2.3)
    @JsonProperty("deviceId")
    private String deviceId;  // First level: device identifier
    
    @JsonProperty("yearMonth")
    private String yearMonth;  // Second level: time bucket (e.g., "2026-01")
    
    // Sensor readings
    @JsonProperty("temperature")
    private Double temperature;  // Celsius
    
    @JsonProperty("humidity")
    private Double humidity;  // Percentage (0-100)
    
    @JsonProperty("batteryLevel")
    private Double batteryLevel;  // Percentage (0-100)
    
    @JsonProperty("timestamp")
    private long timestamp = System.currentTimeMillis();
    
    // Denormalized device info for read efficiency (rule 1.2, 1.3)
    @JsonProperty("deviceName")
    private String deviceName;
    
    @JsonProperty("location")
    private String location;
    
    // TTL - documents expire after 30 days (2,592,000 seconds)
    @JsonProperty("ttl")
    private Integer ttl = 2592000;  // 30 days in seconds
    
    @JsonProperty("_etag")
    private String etag;
    
    /**
     * Helper to generate year-month partition key component.
     */
    public static String generateYearMonth(long timestampMs) {
        java.time.Instant instant = java.time.Instant.ofEpochMilli(timestampMs);
        java.time.ZonedDateTime zdt = instant.atZone(java.time.ZoneId.of("UTC"));
        return String.format("%04d-%02d", zdt.getYear(), zdt.getMonthValue());
    }
    
    /**
     * Helper to create document ID from timestamp and deviceId.
     */
    public static String generateId(String deviceId, long timestamp) {
        return String.format("%s_%d", deviceId, timestamp);
    }
}
