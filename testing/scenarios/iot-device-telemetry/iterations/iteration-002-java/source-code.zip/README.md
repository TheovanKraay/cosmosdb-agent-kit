# IoT Telemetry API - Java Spring Boot

Spring Boot 3 REST API for ingesting and querying IoT device telemetry data using Azure Cosmos DB.

## Architecture

- **Framework**: Spring Boot 3.2.1 with WebFlux (reactive)
- **Database**: Azure Cosmos DB (NoSQL API)
- **Java Version**: 17
- **Build Tool**: Maven

## Cosmos DB Best Practices Implemented

### Data Modeling
- ✅ **1.3**: Embedded device summary in telemetry readings for denormalization
- ✅ **1.5**: Schema versioning for future evolution
- ✅ **1.6**: Type discriminators for polymorphic data

### Partition Key Design
- ✅ **2.1**: Hierarchical partition key prevents 20GB limit
- ✅ **2.2**: Time-bucketed partition avoids hot partitions
- ✅ **2.3**: Hierarchical partition keys (deviceId + yearMonth)
- ✅ **2.4**: High-cardinality partition key (thousands of devices)
- ✅ **2.5**: Partition key aligned with query patterns

### Query Optimization
- ✅ **3.1**: Minimize cross-partition queries (all device+time queries are single-partition)
- ✅ **3.4**: Continuation token pagination
- ✅ **3.5**: Parameterized queries throughout
- ✅ **3.6**: Project only needed fields

### SDK Best Practices
- ✅ **4.1**: Async APIs for better throughput (Mono/Flux)
- ✅ **4.4**: Direct mode for production, Gateway for emulator
- ✅ **4.5**: Diagnostics logging
- ✅ **4.6**: SSL and connection mode configured for emulator
- ✅ **4.8**: contentResponseOnWriteEnabled returns created items
- ✅ **4.10**: Preferred regions (commented for emulator)
- ✅ **4.11**: Retry configuration for 429 handling
- ✅ **4.13**: CosmosClient as singleton

### Indexing
- ✅ **5.1**: Composite indexes for ORDER BY queries
- ✅ **5.2**: Exclude unused paths (_etag)

### Throughput
- ✅ **6.1**: Autoscale throughput for variable IoT workload

## Data Model

### Device
```json
{
  "id": "device-001",
  "deviceId": "device-001",
  "type": "device",
  "name": "Temperature Sensor 1",
  "location": "Building-A",
  "deviceType": "sensor",
  "status": "active"
}
```

**Partition Key**: `/deviceId`

### TelemetryReading
```json
{
  "id": "device-001_1704067200000",
  "type": "telemetry",
  "schemaVersion": 1,
  "deviceId": "device-001",
  "yearMonth": "2026-01",
  "temperature": 22.5,
  "humidity": 65.0,
  "batteryLevel": 85.0,
  "timestamp": 1704067200000,
  "deviceName": "Temperature Sensor 1",
  "location": "Building-A",
  "ttl": 2592000
}
```

**Hierarchical Partition Key**: `/deviceId` + `/yearMonth`
**TTL**: 30 days (2,592,000 seconds)

## Prerequisites

1. **Java 17** or higher
2. **Maven 3.8+**
3. **Azure Cosmos DB Emulator**
   - Download: https://learn.microsoft.com/azure/cosmos-db/emulator
   - Default endpoint: https://localhost:8081

## Build and Run

### Import Emulator Certificate (Required for Java)

Before running the application, you must import the Cosmos DB Emulator's SSL certificate into the JDK truststore:

```powershell
# Export emulator certificate
$certPath = "$env:LOCALAPPDATA\CosmosDBEmulator\emulator-cert.cer"

# Find your JDK path
java -XshowSettings:properties -version 2>&1 | Select-String "java.home"

# Import certificate (replace JDK path with your actual path)
keytool -importcert `
    -alias cosmosemulator `
    -file $certPath `
    -keystore "C:\Program Files\Eclipse Adoptium\jdk-17.0.10.7-hotspot\lib\security\cacerts" `
    -storepass changeit `
    -noprompt
```

### Build the Project

```bash
mvn clean install
```

### Run the Application

```bash
mvn spring-boot:run
```

The API will start on http://localhost:8080

## API Endpoints

### Devices

- **POST** `/api/devices` - Create a device
- **GET** `/api/devices/{deviceId}` - Get device by ID
- **PUT** `/api/devices/{deviceId}` - Update device
- **GET** `/api/devices/by-location/{location}` - Get devices by location
- **GET** `/api/devices` - Get all devices
- **DELETE** `/api/devices/{deviceId}` - Delete device

### Telemetry

- **POST** `/api/telemetry` - Ingest single reading
- **POST** `/api/telemetry/bulk` - Bulk ingest readings
- **GET** `/api/telemetry/latest/{deviceId}?yearMonth=2026-01` - Get latest reading
- **GET** `/api/telemetry/device/{deviceId}?yearMonth=2026-01&startTimestamp=...&endTimestamp=...` - Query by time range
- **GET** `/api/telemetry/by-location/{location}?limit=100` - Query by location

## Example Usage

### 1. Create a Device

```bash
curl -X POST http://localhost:8080/api/devices \
  -H "Content-Type: application/json" \
  -d '{
    "deviceId": "sensor-001",
    "name": "Temperature Sensor 1",
    "location": "Building-A",
    "deviceType": "sensor",
    "status": "active"
  }'
```

### 2. Ingest Telemetry Reading

```bash
curl -X POST http://localhost:8080/api/telemetry \
  -H "Content-Type: application/json" \
  -d '{
    "deviceId": "sensor-001",
    "temperature": 22.5,
    "humidity": 65.0,
    "batteryLevel": 85.0,
    "timestamp": 1704067200000,
    "deviceName": "Temperature Sensor 1",
    "location": "Building-A"
  }'
```

### 3. Query Latest Reading

```bash
curl "http://localhost:8080/api/telemetry/latest/sensor-001?yearMonth=2026-01"
```

### 4. Query Time Range

```bash
curl "http://localhost:8080/api/telemetry/device/sensor-001?yearMonth=2026-01&startTimestamp=1704067200000&endTimestamp=1704153600000"
```

## Performance Characteristics

- **Point reads**: ~1 RU (device by ID)
- **Single-partition time range query**: ~3-10 RU depending on result count
- **Cross-partition location query**: Variable (scales with partition count)
- **Bulk insert**: 10 concurrent operations for high throughput

## TTL Configuration

Telemetry readings automatically expire after 30 days:
- TTL property: `ttl = 2592000` (30 days in seconds)
- Container TTL: Enabled (`-1` = enabled but no default)
- Documents with `ttl` property expire automatically

## Logging

Application logs include:
- RU consumption per operation
- Query diagnostics
- Partition key information
- Cross-partition query warnings

## Production Considerations

For production deployment:

1. **Update application.properties**:
   ```properties
   cosmos.endpoint=https://your-account.documents.azure.com:443/
   cosmos.key=your-production-key
   ```

2. **Enable Direct mode** (automatic when not localhost)

3. **Configure preferred regions** (uncommented in CosmosDbConfig)

4. **Monitor metrics**:
   - RU consumption
   - Query latency
   - Throttling (429s)
   - Hot partitions

5. **Scale throughput** based on load
