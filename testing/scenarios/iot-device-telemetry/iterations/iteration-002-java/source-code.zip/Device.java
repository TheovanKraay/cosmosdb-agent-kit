package com.cosmosdb.iot.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Device entity representing IoT device metadata.
 * 
 * Best Practices Applied:
 * - 1.6: Type discriminator for polymorphic data (type field)
 * - 2.4: High-cardinality partition key (deviceId - thousands of unique devices)
 * - 2.5: Partition key aligned with query patterns (most queries by deviceId)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Device {
    
    @JsonProperty("id")
    private String id;  // Same as deviceId for simplicity
    
    @JsonProperty("deviceId")
    private String deviceId;  // Partition key
    
    @JsonProperty("type")
    private String type = "device";  // Type discriminator (rule 1.6)
    
    @JsonProperty("name")
    private String name;
    
    @JsonProperty("location")
    private String location;  // Facility/building location
    
    @JsonProperty("deviceType")
    private String deviceType;  // Sensor, Gateway, Controller, etc.
    
    @JsonProperty("status")
    private String status = "active";  // active, inactive, maintenance
    
    @JsonProperty("createdAt")
    private long createdAt = System.currentTimeMillis();
    
    @JsonProperty("_etag")
    private String etag;  // For optimistic concurrency
}
