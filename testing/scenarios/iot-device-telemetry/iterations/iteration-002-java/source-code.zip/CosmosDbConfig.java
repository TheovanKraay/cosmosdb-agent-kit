package com.cosmosdb.iot.config;

import com.azure.cosmos.*;
import com.azure.cosmos.models.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Cosmos DB configuration with all best practices applied.
 * 
 * Best Practices Applied:
 * - 4.13: CosmosClient as singleton (Spring @Bean is singleton by default)
 * - 4.6: Gateway mode for emulator (Direct mode has SSL issues)
 * - 4.8: contentResponseOnWriteEnabled for getting created documents
 * - 4.10: Preferred regions for multi-region (commented for emulator)
 * - 4.11: Retry configuration for 429 handling
 * - 4.1: Using async client for better throughput
 */
@Slf4j
@Configuration
public class CosmosDbConfig {
    
    @Value("${cosmos.endpoint}")
    private String endpoint;
    
    @Value("${cosmos.key}")
    private String key;
    
    @Value("${cosmos.database}")
    private String databaseName;
    
    /**
     * Create singleton CosmosClient with best practices.
     * Rule 4.13: Reuse CosmosClient as singleton
     * Rule 4.6: Use Gateway mode for emulator
     */
    @Bean
    public CosmosAsyncClient cosmosAsyncClient() {
        log.info("Creating CosmosAsyncClient for endpoint: {}", endpoint);
        
        boolean isEmulator = endpoint.contains("localhost") || endpoint.contains("127.0.0.1");
        
        CosmosClientBuilder builder = new CosmosClientBuilder()
            .endpoint(endpoint)
            .key(key)
            // Rule 4.8: Enable content response to get created items back
            .contentResponseOnWriteEnabled(true)
            // Rule 4.11: Configure retry for 429 handling
            .throttlingRetryOptions(new ThrottlingRetryOptions()
                .setMaxRetryAttemptsOnThrottledRequests(9)
                .setMaxRetryWaitTime(java.time.Duration.ofSeconds(30)));
        
        if (isEmulator) {
            // Rule 4.6: Use Gateway mode for emulator (Direct mode has SSL issues)
            log.info("Configuring for Cosmos DB Emulator (Gateway mode)");
            builder.gatewayMode();
        } else {
            // Rule 4.4: Use Direct mode for production
            log.info("Configuring for production (Direct mode)");
            builder.directMode();
            
            // Rule 4.10: Configure preferred regions for multi-region accounts
            // builder.preferredRegions(Arrays.asList("West US 2", "East US 2"));
        }
        
        return builder.buildAsyncClient();
    }
    
    /**
     * Initialize database and containers with best practices.
     */
    @Bean
    public CosmosAsyncDatabase cosmosAsyncDatabase(CosmosAsyncClient client) {
        log.info("Initializing database: {}", databaseName);
        
        // Create database if it doesn't exist
        client.createDatabaseIfNotExists(databaseName).block();
        
        CosmosAsyncDatabase database = client.getDatabase(databaseName);
        
        // Initialize containers
        initializeContainers(database);
        
        return database;
    }
    
    /**
     * Initialize containers with proper partition keys, indexing, and TTL.
     */
    private void initializeContainers(CosmosAsyncDatabase database) {
        // Container: telemetry (time-series data)
        createTelemetryContainer(database);
        
        // Container: devices (metadata)
        createDevicesContainer(database);
    }
    
    /**
     * Create telemetry container with hierarchical partition key and TTL.
     * 
     * Best Practices Applied:
     * - 2.3: Hierarchical partition keys (deviceId + yearMonth)
     * - 5.2: Exclude unused paths from indexing
     * - 5.1: Composite indexes for ORDER BY queries
     * - 6.1: Autoscale for variable workload
     */
    private void createTelemetryContainer(CosmosAsyncDatabase database) {
        String containerName = "telemetry";
        
        // Rule 2.3: Hierarchical partition key paths
        List<String> partitionKeyPaths = Arrays.asList("/deviceId", "/yearMonth");
        
        // Create partition key definition for hierarchical keys
        PartitionKeyDefinition partitionKeyDef = new PartitionKeyDefinition();
        partitionKeyDef.setPaths(partitionKeyPaths);
        partitionKeyDef.setKind(PartitionKind.MULTI_HASH);
        partitionKeyDef.setVersion(PartitionKeyDefinitionVersion.V2);
        
        CosmosContainerProperties containerProperties = new CosmosContainerProperties(
            containerName,
            partitionKeyDef  // Use PartitionKeyDefinition for hierarchical keys
        );
        
        // Enable TTL at container level
        containerProperties.setDefaultTimeToLiveInSeconds(-1);  // -1 = enabled but no default
        
        // Rule 5.2: Optimize indexing - exclude large/unused paths
        IndexingPolicy indexingPolicy = new IndexingPolicy();
        indexingPolicy.setIndexingMode(IndexingMode.CONSISTENT);
        indexingPolicy.setAutomatic(true);
        
        // Include specific paths only
        indexingPolicy.setIncludedPaths(Arrays.asList(
            new IncludedPath("/*")  // Index all by default for this scenario
        ));
        
        // Exclude _etag from indexing
        indexingPolicy.setExcludedPaths(Arrays.asList(
            new ExcludedPath("/_etag/?")
        ));
        
        // Rule 5.1: Composite indexes for efficient ORDER BY queries
        List<List<CompositePath>> compositePaths = new ArrayList<>();
        
        // Index for: WHERE deviceId = X ORDER BY timestamp DESC
        List<CompositePath> compositeIndex1 = new ArrayList<>();
        compositeIndex1.add(new CompositePath().setPath("/deviceId").setOrder(CompositePathSortOrder.ASCENDING));
        compositeIndex1.add(new CompositePath().setPath("/timestamp").setOrder(CompositePathSortOrder.DESCENDING));
        compositePaths.add(compositeIndex1);
        
        // Index for: WHERE location = X ORDER BY timestamp DESC
        List<CompositePath> compositeIndex2 = new ArrayList<>();
        compositeIndex2.add(new CompositePath().setPath("/location").setOrder(CompositePathSortOrder.ASCENDING));
        compositeIndex2.add(new CompositePath().setPath("/timestamp").setOrder(CompositePathSortOrder.DESCENDING));
        compositePaths.add(compositeIndex2);
        
        indexingPolicy.setCompositeIndexes(compositePaths);
        containerProperties.setIndexingPolicy(indexingPolicy);
        
        // Rule 6.1: Create with autoscale throughput for variable IoT workload
        ThroughputProperties throughput = ThroughputProperties.createAutoscaledThroughput(4000);
        
        database.createContainerIfNotExists(containerProperties, throughput)
            .doOnSuccess(response -> log.info("Telemetry container created/verified: {}", containerName))
            .doOnError(error -> log.error("Error creating telemetry container", error))
            .block();
    }
    
    /**
     * Create devices container with standard partition key.
     * 
     * Best Practices Applied:
     * - 2.4: High-cardinality partition key (deviceId)
     * - 6.1: Autoscale throughput
     */
    private void createDevicesContainer(CosmosAsyncDatabase database) {
        String containerName = "devices";
        
        CosmosContainerProperties containerProperties = new CosmosContainerProperties(
            containerName,
            "/deviceId"  // Simple partition key for device metadata
        );
        
        // Autoscale throughput (lower than telemetry - less traffic)
        ThroughputProperties throughput = ThroughputProperties.createAutoscaledThroughput(1000);
        
        database.createContainerIfNotExists(containerProperties, throughput)
            .doOnSuccess(response -> log.info("Devices container created/verified: {}", containerName))
            .doOnError(error -> log.error("Error creating devices container", error))
            .block();
    }
}
