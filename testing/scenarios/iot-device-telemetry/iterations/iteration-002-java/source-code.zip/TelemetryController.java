package com.cosmosdb.iot.controller;

import com.cosmosdb.iot.model.TelemetryReading;
import com.cosmosdb.iot.repository.TelemetryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;
import java.util.List;

/**
 * REST Controller for Telemetry operations.
 */
@Slf4j
@RestController
@RequestMapping("/api/telemetry")
@RequiredArgsConstructor
public class TelemetryController {
    
    private final TelemetryRepository telemetryRepository;
    
    /**
     * Ingest a single telemetry reading.
     */
    @PostMapping
    public Mono<ResponseEntity<TelemetryReading>> createReading(@Valid @RequestBody TelemetryReading reading) {
        log.info("Creating telemetry reading for device: {}", reading.getDeviceId());
        
        return telemetryRepository.createReading(reading)
            .map(created -> ResponseEntity.status(HttpStatus.CREATED).body(created))
            .onErrorResume(error -> {
                log.error("Error creating telemetry reading", error);
                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build());
            });
    }
    
    /**
     * Bulk ingest telemetry readings (high throughput).
     */
    @PostMapping("/bulk")
    public Flux<TelemetryReading> createReadingsBulk(@Valid @RequestBody List<TelemetryReading> readings) {
        log.info("Bulk creating {} telemetry readings", readings.size());
        
        return telemetryRepository.createReadingsBulk(readings)
            .onErrorResume(error -> {
                log.error("Error in bulk telemetry ingestion", error);
                return Flux.empty();
            });
    }
    
    /**
     * Get the latest reading for a specific device.
     * Requires yearMonth parameter to optimize query.
     */
    @GetMapping("/latest/{deviceId}")
    public Mono<ResponseEntity<TelemetryReading>> getLatestReading(
        @PathVariable String deviceId,
        @RequestParam String yearMonth
    ) {
        log.info("Getting latest reading for device: {}, yearMonth: {}", deviceId, yearMonth);
        
        return telemetryRepository.getLatestReading(deviceId, yearMonth)
            .map(ResponseEntity::ok)
            .defaultIfEmpty(ResponseEntity.notFound().build())
            .onErrorResume(error -> {
                log.error("Error getting latest reading for device: {}", deviceId, error);
                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build());
            });
    }
    
    /**
     * Query readings for a device within a time range.
     * This is a single-partition query thanks to hierarchical partition key.
     */
    @GetMapping("/device/{deviceId}")
    public Flux<TelemetryReading> getReadingsByTimeRange(
        @PathVariable String deviceId,
        @RequestParam String yearMonth,
        @RequestParam long startTimestamp,
        @RequestParam long endTimestamp
    ) {
        log.info("Querying readings for device: {}, yearMonth: {}, range: {}-{}", 
            deviceId, yearMonth, startTimestamp, endTimestamp);
        
        return telemetryRepository.getReadingsByTimeRange(deviceId, yearMonth, startTimestamp, endTimestamp)
            .onErrorResume(error -> {
                log.error("Error querying readings for device: {}", deviceId, error);
                return Flux.empty();
            });
    }
    
    /**
     * Query recent readings for all devices in a location.
     * Note: This is a cross-partition query - expensive!
     */
    @GetMapping("/by-location/{location}")
    public Flux<TelemetryReading> getReadingsByLocation(
        @PathVariable String location,
        @RequestParam(defaultValue = "100") int limit
    ) {
        log.info("Querying telemetry by location: {}, limit: {}", location, limit);
        
        return telemetryRepository.getReadingsByLocation(location, limit)
            .onErrorResume(error -> {
                log.error("Error querying telemetry by location: {}", location, error);
                return Flux.empty();
            });
    }
}
