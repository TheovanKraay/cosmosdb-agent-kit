package com.cosmosdb.iot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main Spring Boot application for IoT Telemetry API.
 * 
 * Best Practices Applied Throughout:
 * - 4.13: CosmosClient as singleton (configured in CosmosDbConfig)
 * - 4.6: Gateway mode for emulator, Direct for production
 * - 4.1: Async APIs throughout for better throughput
 * - 2.3: Hierarchical partition keys for time-series data
 * - 6.1: Autoscale throughput for variable IoT workload
 * - TTL configured for automatic 30-day data retention
 * - 3.1: All queries optimized to be single-partition where possible
 * - 3.5: All queries parameterized for security and performance
 * - 4.5: Comprehensive diagnostics logging
 */
@SpringBootApplication
public class IoTTelemetryApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(IoTTelemetryApplication.class, args);
    }
}
