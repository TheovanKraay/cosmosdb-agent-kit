"""
Data models for IoT Telemetry system.

Best Practices Applied:
- Rule 1.2 (model-denormalize-reads): Denormalized device info in telemetry readings
- Rule 1.3 (model-embed-related): Embedded location and deviceName for read efficiency
- Rule 1.5 (model-schema-versioning): Added schemaVersion field
- Rule 1.6 (model-type-discriminator): Type discriminators for polymorphic queries
- Rule 2.3 (partition-hierarchical): Hierarchical partition key (deviceId + yearMonth)
- Rule 2.5 (partition-query-patterns): Partition key aligns with query patterns
"""
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class Device(BaseModel):
    """
    Device metadata.
    
    Partition Key: /id (device ID)
    Type: Single partition key (devices are small, not time-series)
    """
    id: str = Field(..., description="Unique device identifier")
    deviceName: str = Field(..., description="Human-readable device name")
    location: str = Field(..., description="Physical location/facility")
    deviceType: str = Field(..., description="Type of IoT device (sensor, gateway, etc.)")
    manufacturer: Optional[str] = Field(None, description="Device manufacturer")
    model: Optional[str] = Field(None, description="Device model")
    firmwareVersion: Optional[str] = Field(None, description="Current firmware version")
    registeredAt: datetime = Field(default_factory=datetime.utcnow, description="Registration timestamp")
    lastSeenAt: Optional[datetime] = Field(None, description="Last communication timestamp")
    
    # Rule 1.6: Type discriminator for polymorphic queries
    type: str = Field(default="device", description="Document type discriminator")
    
    # Rule 1.5: Schema versioning
    schemaVersion: str = Field(default="1.0", description="Schema version for evolution")
    
    # Rule 1.2: Denormalized latest reading summary
    latestReading: Optional[dict] = Field(None, description="Cached latest telemetry reading")


class TelemetryReading(BaseModel):
    """
    Telemetry reading from an IoT device.
    
    Partition Key: Hierarchical - [/deviceId, /yearMonth]
    - deviceId: Distributes data by device (prevents hot partitions)
    - yearMonth: Time bucketing for efficient range queries and data expiration
    
    Best Practices:
    - Rule 2.3: Hierarchical partition key for time-series data
    - Rule 2.6: Synthetic yearMonth key for time bucketing
    - TTL: Automatic expiration after 30 days
    """
    id: str = Field(..., description="Unique reading ID (deviceId_timestamp)")
    deviceId: str = Field(..., description="Device that generated the reading")
    yearMonth: str = Field(..., description="Year-month bucket (YYYY-MM) for partition key")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Reading timestamp")
    
    # Sensor readings
    temperature: float = Field(..., description="Temperature in Celsius")
    humidity: float = Field(..., description="Humidity percentage")
    batteryLevel: float = Field(..., description="Battery percentage (0-100)")
    
    # Rule 1.3: Embedded device context (denormalized for read efficiency)
    deviceName: str = Field(..., description="Device name (denormalized)")
    location: str = Field(..., description="Device location (denormalized)")
    
    # Rule 1.6: Type discriminator
    type: str = Field(default="telemetry", description="Document type discriminator")
    
    # Rule 1.5: Schema versioning
    schemaVersion: str = Field(default="1.0", description="Schema version")
    
    # TTL configuration (30 days = 2,592,000 seconds)
    ttl: int = Field(default=2592000, description="Time to live in seconds (30 days)")


class TelemetryBulkRequest(BaseModel):
    """Bulk ingestion request for multiple telemetry readings."""
    readings: list[TelemetryReading] = Field(..., description="List of readings to ingest")


class DeviceStats(BaseModel):
    """Aggregated statistics for a device over a time period."""
    deviceId: str
    deviceName: str
    location: str
    startTime: datetime
    endTime: datetime
    readingCount: int
    temperature: dict = Field(..., description="Min/max/avg temperature")
    humidity: dict = Field(..., description="Min/max/avg humidity")
    batteryLevel: dict = Field(..., description="Min/max/avg battery")
