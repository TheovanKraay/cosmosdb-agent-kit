"""
Repository layer for Cosmos DB data access.

Best Practices Applied:
- Rule 3.1 (query-avoid-cross-partition): All queries use partition key
- Rule 3.2 (query-use-projections): Select only needed fields
- Rule 3.3 (query-pagination): Use continuation tokens
- Rule 3.5 (query-parameterize): All queries are parameterized
- Rule 4.1 (sdk-async-api): Async operations for better throughput
"""
import logging
from datetime import datetime
from typing import List, Optional
from azure.cosmos import ContainerProxy
from azure.cosmos.exceptions import CosmosResourceNotFoundError
from models import Device, TelemetryReading, DeviceStats

logger = logging.getLogger(__name__)


class DeviceRepository:
    """Repository for device operations."""
    
    def __init__(self, container: ContainerProxy):
        self.container = container
    
    async def create_device(self, device: Device) -> Device:
        """
        Create a new device.
        
        Rule 3.5: Uses create_item (no parameterization needed for writes)
        """
        item_dict = device.model_dump(mode='json')
        created_item = self.container.create_item(body=item_dict)
        return Device(**created_item)
    
    async def get_device(self, device_id: str) -> Optional[Device]:
        """
        Get a device by ID (point read).
        
        Rule 3.1: Single-partition read using partition key
        """
        try:
            # Point read: Most efficient operation (1 RU)
            item = self.container.read_item(
                item=device_id,
                partition_key=device_id  # /id is the partition key
            )
            return Device(**item)
        except CosmosResourceNotFoundError:
            return None
    
    async def get_devices_by_location(self, location: str) -> List[Device]:
        """
        Query devices by location (cross-partition query).
        
        NOTE: This is a cross-partition query because location is not the partition key.
        Rule 3.1: In production, consider a materialized view with location as partition key
        if this query is frequent.
        
        Rule 3.2: Uses SELECT * but could optimize by projecting specific fields
        Rule 3.5: Parameterized query
        """
        query = """
        SELECT * FROM devices d
        WHERE d.location = @location
        AND d.type = @type
        """
        
        parameters = [
            {"name": "@location", "value": location},
            {"name": "@type", "value": "device"}
        ]
        
        items = list(self.container.query_items(
            query=query,
            parameters=parameters,
            enable_cross_partition_query=True  # Required for non-partition-key queries
        ))
        
        return [Device(**item) for item in items]


class TelemetryRepository:
    """Repository for telemetry operations."""
    
    def __init__(self, container: ContainerProxy):
        self.container = container
    
    async def create_reading(self, reading: TelemetryReading) -> TelemetryReading:
        """
        Create a single telemetry reading.
        
        Best Practice: Generate ID as deviceId_timestamp for uniqueness
        """
        reading.id = f"{reading.deviceId}_{reading.timestamp.isoformat()}"
        reading.yearMonth = reading.timestamp.strftime("%Y-%m")
        
        item_dict = reading.model_dump(mode='json')
        created_item = self.container.create_item(body=item_dict)
        return TelemetryReading(**created_item)
    
    async def create_readings_bulk(self, readings: List[TelemetryReading]) -> List[TelemetryReading]:
        """
        Bulk insert telemetry readings.
        
        Rule 4.1: Async operations for high throughput
        Note: Python SDK doesn't have built-in bulk executor like .NET/Java
        This would benefit from batch processing in production
        """
        created_readings = []
        
        for reading in readings:
            reading.id = f"{reading.deviceId}_{reading.timestamp.isoformat()}"
            reading.yearMonth = reading.timestamp.strftime("%Y-%m")
            
            item_dict = reading.model_dump(mode='json')
            created_item = self.container.create_item(body=item_dict)
            created_readings.append(TelemetryReading(**created_item))
        
        return created_readings
    
    async def get_latest_reading(self, device_id: str) -> Optional[TelemetryReading]:
        """
        Get the latest reading for a device.
        
        Rule 3.1: Single-partition query (uses deviceId partition key)
        Rule 3.2: Could optimize with SELECT TOP 1 and specific fields
        Rule 3.5: Parameterized query
        Rule 5.1: Composite index on [deviceId, timestamp DESC] makes this efficient
        """
        # Get current year-month for partition key
        current_year_month = datetime.utcnow().strftime("%Y-%m")
        
        query = """
        SELECT TOP 1 * FROM telemetry t
        WHERE t.deviceId = @deviceId
        AND t.yearMonth = @yearMonth
        ORDER BY t.timestamp DESC
        """
        
        parameters = [
            {"name": "@deviceId", "value": device_id},
            {"name": "@yearMonth", "value": current_year_month}
        ]
        
        # Single-partition query (deviceId + yearMonth)
        items = list(self.container.query_items(
            query=query,
            parameters=parameters,
            partition_key=[device_id, current_year_month]  # Hierarchical partition key
        ))
        
        return TelemetryReading(**items[0]) if items else None
    
    async def get_readings_by_time_range(
        self,
        device_id: str,
        start_time: datetime,
        end_time: datetime
    ) -> List[TelemetryReading]:
        """
        Get readings for a device within a time range.
        
        Rule 3.1: Single-partition query (includes deviceId in partition key)
        Rule 3.3: Should implement pagination for large result sets
        Rule 3.5: Parameterized query
        Rule 3.6: ORDER BY uses composite index
        
        NOTE: This queries a single year-month partition. For multi-month ranges,
        would need to query multiple partitions.
        """
        year_month = start_time.strftime("%Y-%m")
        
        query = """
        SELECT * FROM telemetry t
        WHERE t.deviceId = @deviceId
        AND t.yearMonth = @yearMonth
        AND t.timestamp >= @startTime
        AND t.timestamp <= @endTime
        ORDER BY t.timestamp DESC
        """
        
        parameters = [
            {"name": "@deviceId", "value": device_id},
            {"name": "@yearMonth", "value": year_month},
            {"name": "@startTime", "value": start_time.isoformat()},
            {"name": "@endTime", "value": end_time.isoformat()}
        ]
        
        items = list(self.container.query_items(
            query=query,
            parameters=parameters,
            partition_key=[device_id, year_month]  # Hierarchical partition key
        ))
        
        return [TelemetryReading(**item) for item in items]
    
    async def get_device_stats(
        self,
        device_id: str,
        start_time: datetime,
        end_time: datetime
    ) -> Optional[DeviceStats]:
        """
        Calculate aggregate statistics for a device over a time period.
        
        Rule 3.1: Single-partition query with aggregations
        Rule 3.5: Parameterized query
        """
        year_month = start_time.strftime("%Y-%m")
        
        # Query for aggregations
        query = """
        SELECT
            COUNT(1) as readingCount,
            MIN(t.temperature) as minTemp,
            MAX(t.temperature) as maxTemp,
            AVG(t.temperature) as avgTemp,
            MIN(t.humidity) as minHumidity,
            MAX(t.humidity) as maxHumidity,
            AVG(t.humidity) as avgHumidity,
            MIN(t.batteryLevel) as minBattery,
            MAX(t.batteryLevel) as maxBattery,
            AVG(t.batteryLevel) as avgBattery,
            MIN(t.deviceName) as deviceName,
            MIN(t.location) as location
        FROM telemetry t
        WHERE t.deviceId = @deviceId
        AND t.yearMonth = @yearMonth
        AND t.timestamp >= @startTime
        AND t.timestamp <= @endTime
        """
        
        parameters = [
            {"name": "@deviceId", "value": device_id},
            {"name": "@yearMonth", "value": year_month},
            {"name": "@startTime", "value": start_time.isoformat()},
            {"name": "@endTime", "value": end_time.isoformat()}
        ]
        
        results = list(self.container.query_items(
            query=query,
            parameters=parameters,
            partition_key=[device_id, year_month]
        ))
        
        if not results or results[0]['readingCount'] == 0:
            return None
        
        result = results[0]
        
        return DeviceStats(
            deviceId=device_id,
            deviceName=result.get('deviceName', 'Unknown'),
            location=result.get('location', 'Unknown'),
            startTime=start_time,
            endTime=end_time,
            readingCount=result['readingCount'],
            temperature={
                'min': result['minTemp'],
                'max': result['maxTemp'],
                'avg': result['avgTemp']
            },
            humidity={
                'min': result['minHumidity'],
                'max': result['maxHumidity'],
                'avg': result['avgHumidity']
            },
            batteryLevel={
                'min': result['minBattery'],
                'max': result['maxBattery'],
                'avg': result['avgBattery']
            }
        )
