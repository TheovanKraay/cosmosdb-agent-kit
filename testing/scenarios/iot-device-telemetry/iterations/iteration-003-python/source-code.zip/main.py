"""
FastAPI REST API for IoT Telemetry System.

Best Practices Applied:
- Comprehensive error handling and logging
- Async operations for better throughput
- Health check endpoint for monitoring
"""
import logging
from datetime import datetime, timedelta
from typing import List
from fastapi import FastAPI, HTTPException, status
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager

from config import settings
from database import initialize_database, get_cosmos_client
from models import Device, TelemetryReading, TelemetryBulkRequest, DeviceStats
from repository import DeviceRepository, TelemetryRepository

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Global repository instances
device_repo = None
telemetry_repo = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifecycle management for FastAPI application.
    
    Best Practice: Initialize Cosmos DB resources on startup
    Rule 4.13: CosmosClient is singleton, created once and reused
    """
    global device_repo, telemetry_repo
    
    logger.info("Initializing IoT Telemetry API...")
    logger.info(f"Cosmos DB Endpoint: {settings.cosmos_endpoint}")
    
    try:
        # Initialize database and containers
        database, devices_container, telemetry_container = initialize_database()
        
        # Create repository instances
        device_repo = DeviceRepository(devices_container)
        telemetry_repo = TelemetryRepository(telemetry_container)
        
        logger.info("Application started successfully")
        
        yield
        
    except Exception as e:
        logger.error(f"Failed to initialize application: {e}")
        raise
    finally:
        # Cleanup (CosmosClient cleanup is handled by Python's garbage collector)
        logger.info("Shutting down application")


# Create FastAPI application
app = FastAPI(
    title="IoT Telemetry API",
    description="REST API for managing IoT device telemetry data using Azure Cosmos DB",
    version="1.0.0",
    lifespan=lifespan
)


@app.get("/health", tags=["Health"])
async def health_check():
    """
    Health check endpoint.
    
    Best Practice: Monitor application and Cosmos DB connectivity
    """
    try:
        # Verify Cosmos DB connection
        client = get_cosmos_client()
        list(client.list_databases())
        
        return {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "cosmosdb": "connected"
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content={
                "status": "unhealthy",
                "error": str(e)
            }
        )


# ========================================
# DEVICE ENDPOINTS
# ========================================

@app.post("/api/devices", response_model=Device, status_code=status.HTTP_201_CREATED, tags=["Devices"])
async def create_device(device: Device):
    """Create a new IoT device."""
    try:
        created_device = await device_repo.create_device(device)
        logger.info(f"Created device: {created_device.id}")
        return created_device
    except Exception as e:
        logger.error(f"Failed to create device: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create device: {str(e)}"
        )


@app.get("/api/devices/{device_id}", response_model=Device, tags=["Devices"])
async def get_device(device_id: str):
    """
    Get a device by ID (point read - most efficient).
    
    Rule 3.1: Single-partition read (1 RU cost)
    """
    try:
        device = await device_repo.get_device(device_id)
        if not device:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Device {device_id} not found"
            )
        return device
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get device {device_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get device: {str(e)}"
        )


@app.get("/api/devices/location/{location}", response_model=List[Device], tags=["Devices"])
async def get_devices_by_location(location: str):
    """
    Get all devices in a specific location.
    
    NOTE: This is a cross-partition query (location is not the partition key).
    Rule 3.1: Consider materialized view if this query is frequent.
    """
    try:
        devices = await device_repo.get_devices_by_location(location)
        return devices
    except Exception as e:
        logger.error(f"Failed to query devices by location {location}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to query devices: {str(e)}"
        )


# ========================================
# TELEMETRY ENDPOINTS
# ========================================

@app.post("/api/telemetry", response_model=TelemetryReading, status_code=status.HTTP_201_CREATED, tags=["Telemetry"])
async def create_telemetry_reading(reading: TelemetryReading):
    """
    Ingest a single telemetry reading.
    
    Best Practice: ID is auto-generated as deviceId_timestamp
    """
    try:
        created_reading = await telemetry_repo.create_reading(reading)
        logger.info(f"Created telemetry reading: {created_reading.id}")
        return created_reading
    except Exception as e:
        logger.error(f"Failed to create telemetry reading: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create reading: {str(e)}"
        )


@app.post("/api/telemetry/bulk", response_model=List[TelemetryReading], status_code=status.HTTP_201_CREATED, tags=["Telemetry"])
async def create_telemetry_bulk(request: TelemetryBulkRequest):
    """
    Bulk ingest telemetry readings.
    
    Rule 4.1: Async operations for high throughput
    Note: Python SDK doesn't have built-in bulk executor
    """
    try:
        created_readings = await telemetry_repo.create_readings_bulk(request.readings)
        logger.info(f"Bulk created {len(created_readings)} telemetry readings")
        return created_readings
    except Exception as e:
        logger.error(f"Failed to bulk create telemetry readings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to bulk create readings: {str(e)}"
        )


@app.get("/api/telemetry/{device_id}/latest", response_model=TelemetryReading, tags=["Telemetry"])
async def get_latest_reading(device_id: str):
    """
    Get the latest telemetry reading for a device.
    
    Rule 3.1: Single-partition query (deviceId + current yearMonth)
    Rule 5.1: Composite index makes ORDER BY efficient
    """
    try:
        reading = await telemetry_repo.get_latest_reading(device_id)
        if not reading:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No readings found for device {device_id}"
            )
        return reading
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get latest reading for device {device_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get latest reading: {str(e)}"
        )


@app.get("/api/telemetry/{device_id}/range", response_model=List[TelemetryReading], tags=["Telemetry"])
async def get_readings_by_time_range(
    device_id: str,
    start_time: datetime,
    end_time: datetime
):
    """
    Get telemetry readings for a device within a time range.
    
    Rule 3.1: Single-partition query (deviceId + yearMonth)
    Rule 3.3: Should implement pagination for large result sets
    """
    try:
        readings = await telemetry_repo.get_readings_by_time_range(
            device_id, start_time, end_time
        )
        return readings
    except Exception as e:
        logger.error(f"Failed to get readings for device {device_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get readings: {str(e)}"
        )


@app.get("/api/telemetry/{device_id}/stats", response_model=DeviceStats, tags=["Telemetry"])
async def get_device_stats(
    device_id: str,
    start_time: datetime,
    end_time: datetime
):
    """
    Get aggregate statistics for a device over a time period.
    
    Rule 3.1: Single-partition query with aggregations
    """
    try:
        stats = await telemetry_repo.get_device_stats(
            device_id, start_time, end_time
        )
        if not stats:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No data found for device {device_id} in the specified time range"
            )
        return stats
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get stats for device {device_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get stats: {str(e)}"
        )


if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level=settings.log_level.lower()
    )
