# IoT Telemetry API - Python / FastAPI

FastAPI REST API for managing IoT device telemetry data using Azure Cosmos DB.

## Features

- Device management (registration, metadata)
- High-volume telemetry ingestion (single + bulk)
- Time-range queries for analytics
- Aggregate statistics (min/max/avg)
- Automatic data expiration (30-day TTL)
- Health check endpoint

## Cosmos DB Best Practices Applied

This implementation follows 30+ best practices from the Cosmos DB Agent Kit:

### Data Modeling
- **Denormalization**: Device info embedded in telemetry readings
- **Schema versioning**: `schemaVersion` field for evolution
- **Type discriminators**: `type` field for polymorphic queries

### Partition Strategy
- **Hierarchical partition key**: `[deviceId, yearMonth]` for time-series data
- **Time bucketing**: Month-level partitions prevent 20GB limit
- **Query alignment**: Partition key matches query patterns

### Query Optimization
- **Single-partition queries**: All queries use partition key
- **Parameterized queries**: SQL injection prevention
- **Composite indexes**: Efficient ORDER BY on timestamp

### SDK Configuration
- **Singleton CosmosClient**: Reused for application lifetime
- **Gateway mode**: Required for Cosmos DB Emulator
- **Automatic retry**: Built-in 429 throttling handling

### Throughput & Scaling
- **Autoscale**: Variable RU/s for IoT burst patterns
- **TTL**: Automatic 30-day data expiration

## Setup

1. **Install dependencies**:
   ```bash
   python -m venv venv
   venv\Scripts\activate  # Windows
   pip install -r requirements.txt
   ```

2. **Configure environment** (`.env`):
   ```
   COSMOS_ENDPOINT=https://localhost:8081
   COSMOS_KEY=<emulator-key>
   COSMOS_DATABASE=iot-telemetry-db
   ```

3. **Start Cosmos DB Emulator**

4. **Run the application**:
   ```bash
   python main.py
   ```

   Or with uvicorn:
   ```bash
   uvicorn main:app --reload
   ```

5. **Access API documentation**: http://localhost:8000/docs

## API Endpoints

### Devices
- `POST /api/devices` - Register new device
- `GET /api/devices/{device_id}` - Get device (point read)
- `GET /api/devices/location/{location}` - Query devices by location

### Telemetry
- `POST /api/telemetry` - Ingest single reading
- `POST /api/telemetry/bulk` - Bulk ingest readings
- `GET /api/telemetry/{device_id}/latest` - Get latest reading
- `GET /api/telemetry/{device_id}/range` - Get readings in time range
- `GET /api/telemetry/{device_id}/stats` - Get aggregate statistics

### Health
- `GET /health` - Health check

## Data Model

### Device
```json
{
  "id": "device-001",
  "deviceName": "Temperature Sensor 1",
  "location": "Building-A",
  "deviceType": "sensor",
  "type": "device",
  "schemaVersion": "1.0"
}
```

### Telemetry Reading
```json
{
  "id": "device-001_2026-01-29T10:00:00",
  "deviceId": "device-001",
  "yearMonth": "2026-01",
  "timestamp": "2026-01-29T10:00:00Z",
  "temperature": 22.5,
  "humidity": 45.0,
  "batteryLevel": 85.0,
  "deviceName": "Temperature Sensor 1",
  "location": "Building-A",
  "type": "telemetry",
  "schemaVersion": "1.0",
  "ttl": 2592000
}
```

## Architecture

```
main.py           # FastAPI application and endpoints
├── config.py     # Settings and environment configuration
├── database.py   # Cosmos DB client and container initialization
├── models.py     # Pydantic data models
└── repository.py # Data access layer
```

## Key Design Decisions

1. **Hierarchical Partition Key**: `[deviceId, yearMonth]`
   - Distributes writes across devices
   - Time bucketing prevents 20GB partition limit
   - Enables efficient time-range queries

2. **TTL Configuration**:
   - Container-level TTL enabled (`-1`)
   - Document-level TTL set to 30 days
   - Automatic cleanup without manual jobs

3. **Denormalized Data**:
   - Device name and location in telemetry readings
   - Avoids joins for analytics queries
   - Trade-off: slight redundancy for read performance

4. **Autoscale Throughput**:
   - Telemetry: 400-4000 RU/s
   - Devices: 100-1000 RU/s
   - Accommodates IoT burst patterns

## Testing

Example requests using curl:

```bash
# Create device
curl -X POST http://localhost:8000/api/devices \
  -H "Content-Type: application/json" \
  -d '{
    "id": "device-001",
    "deviceName": "Temp Sensor 1",
    "location": "Building-A",
    "deviceType": "sensor"
  }'

# Ingest telemetry
curl -X POST http://localhost:8000/api/telemetry \
  -H "Content-Type: application/json" \
  -d '{
    "deviceId": "device-001",
    "timestamp": "2026-01-29T10:00:00Z",
    "temperature": 22.5,
    "humidity": 45.0,
    "batteryLevel": 85.0,
    "deviceName": "Temp Sensor 1",
    "location": "Building-A"
  }'

# Get latest reading
curl http://localhost:8000/api/telemetry/device-001/latest
```

## Performance Characteristics

- **Point reads**: ~1 RU per device lookup
- **Single-partition queries**: 2-5 RU depending on result size
- **Bulk ingestion**: Scales with autoscale throughput
- **Time-range queries**: Optimized by composite index

## Limitations

- Bulk insert doesn't use optimized bulk executor (Python SDK limitation)
- Cross-partition queries required for location lookups
- Time-range queries spanning multiple months require multiple partition queries
