"""
Configuration settings for the IoT Telemetry API.

Best Practices Applied:
- Rule 4.9 (sdk-local-dev-config): Load .env with override=True to prevent system env vars
  from overriding local development configuration
- Validates endpoint at startup to ensure correct Cosmos DB connection
"""
import logging
import os
from dotenv import load_dotenv
from pydantic_settings import BaseSettings
from pydantic import Field

# Rule 4.9: Load .env file FIRST with override=True to prevent system env vars from taking precedence
load_dotenv(override=True)

logger = logging.getLogger(__name__)


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    # Cosmos DB Configuration
    cosmos_endpoint: str = Field(..., description="Cosmos DB endpoint URL")
    cosmos_key: str = Field(..., description="Cosmos DB master key")
    cosmos_database: str = Field(default="iot-telemetry-db", description="Database name")
    
    # Application Settings
    log_level: str = Field(default="INFO", description="Logging level")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


def get_settings() -> Settings:
    """
    Load and validate settings.
    
    Best Practice: Log the Cosmos DB endpoint at startup to verify configuration.
    This helps catch issues where system env vars override .env file.
    """
    settings = Settings()
    
    # Validate endpoint to catch configuration issues early
    logger.info(f"Cosmos DB Endpoint: {settings.cosmos_endpoint}")
    
    if "localhost" in settings.cosmos_endpoint or "127.0.0.1" in settings.cosmos_endpoint:
        logger.info("✅ Using Cosmos DB Emulator for local development")
    else:
        logger.warning(f"⚠️ Using Azure Cosmos DB cloud instance: {settings.cosmos_endpoint}")
        logger.warning("⚠️ If this is unexpected, check that .env file is not being overridden by system environment variables!")
    
    return settings


# Singleton settings instance
settings = get_settings()
