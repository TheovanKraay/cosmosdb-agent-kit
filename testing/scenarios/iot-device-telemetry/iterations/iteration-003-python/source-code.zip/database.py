"""
Cosmos DB client initialization and container management.

Best Practices Applied:
- Rule 4.13 (sdk-singleton-client): CosmosClient as singleton (reused across requests)
- Rule 4.4 (sdk-connection-mode): Gateway mode for emulator, configurable for production
- Rule 4.11 (sdk-retry-429): Default retry policy handles 429s automatically
- Rule 5.1 (index-composite): Composite indexes for time-range queries
- Rule 5.2 (index-exclude-unused): Exclude unused paths from indexing
- Rule 6.1 (throughput-autoscale): Autoscale throughput for variable workload
"""
import logging
from azure.cosmos import CosmosClient, PartitionKey, exceptions
from azure.cosmos import ThroughputProperties
from azure.cosmos.partition_key import PartitionKey as PK
from config import settings

logger = logging.getLogger(__name__)

# Rule 4.13: Singleton CosmosClient (created once, reused for lifetime of application)
_cosmos_client = None


def get_cosmos_client() -> CosmosClient:
    """
    Get or create the singleton CosmosClient instance.
    
    Best Practices:
    - Rule 4.13: Singleton pattern - client is expensive to create, should be reused
    - Rule 4.4: Gateway mode for emulator (Direct mode doesn't work with localhost SSL)
    - Rule 4.11: Default retry policy automatically handles 429 throttling
    """
    global _cosmos_client
    
    if _cosmos_client is None:
        # Rule 4.4: Use Gateway mode for emulator (localhost)
        # For production, would use connection_mode='Direct' for better performance
        connection_mode = 'Gateway'  # Required for Cosmos DB Emulator
        
        logger.info(f"Initializing CosmosClient with {connection_mode} mode")
        logger.info(f"Endpoint: {settings.cosmos_endpoint}")
        
        _cosmos_client = CosmosClient(
            url=settings.cosmos_endpoint,
            credential=settings.cosmos_key,
            # Rule 4.4: Gateway mode for emulator SSL compatibility
            connection_mode=connection_mode,
            # Rule 4.11: Enable automatic retry on throttling (429)
            connection_retry_policy={
                'max_retry_attempt_count': 9,
                'max_wait_time_in_seconds': 30
            }
        )
        
        logger.info("CosmosClient initialized successfully")
    
    return _cosmos_client


def initialize_database():
    """
    Initialize database and containers with optimal configuration.
    
    Container Design:
    1. Devices Container:
       - Partition key: /id (device ID)
       - Autoscale: 100-1000 RU/s (low volume, metadata only)
       
    2. Telemetry Container:
       - Partition key: Hierarchical [/deviceId, /yearMonth]
       - Autoscale: 400-4000 RU/s (high volume, time-series writes)
       - TTL: Enabled (30-day automatic expiration)
       - Composite indexes: For time-range queries
    """
    client = get_cosmos_client()
    
    try:
        # Create database if it doesn't exist
        database = client.create_database_if_not_exists(id=settings.cosmos_database)
        logger.info(f"Database '{settings.cosmos_database}' ready")
        
        # ========================================
        # DEVICES CONTAINER
        # ========================================
        # Rule 2.1: Simple partition key for device metadata
        try:
            devices_container = database.create_container_if_not_exists(
                id="devices",
                partition_key=PartitionKey(path="/id"),
                # Rule 6.1: Autoscale throughput for variable load (devices are queried less frequently)
                offer_throughput=ThroughputProperties(auto_scale_max_throughput=1000),
                # Rule 5.2: Exclude unused paths from indexing
                indexing_policy={
                    'automatic': True,
                    'indexingMode': 'consistent',
                    'includedPaths': [
                        {'path': '/*'}  # Index all by default
                    ],
                    'excludedPaths': [
                        {'path': '/"_etag"/?'}  # Exclude system property
                    ]
                }
            )
            logger.info("Devices container ready (single partition key: /id)")
        except exceptions.CosmosResourceExistsError:
            devices_container = database.get_container_client("devices")
            logger.info("Devices container already exists")
        
        # ========================================
        # TELEMETRY CONTAINER
        # ========================================
        # Rule 2.3: Hierarchical partition key for time-series data
        # NOTE: For local emulator, use single partition key instead
        try:
            telemetry_container = database.create_container_if_not_exists(
                id="telemetry",
                # Rule 2.3: For cloud, use hierarchical key [deviceId, yearMonth]
                # For emulator: use single key /deviceId (emulator doesn't support MultiHash)
                partition_key=PartitionKey(path="/deviceId"),
                # Rule 6.1: Autoscale for high-volume time-series writes
                offer_throughput=ThroughputProperties(auto_scale_max_throughput=4000),
                # Rule 5.1: Composite indexes for time-range queries
                # Rule 5.2: Exclude sensor values not used in queries
                indexing_policy={
                    'automatic': True,
                    'indexingMode': 'consistent',
                    'includedPaths': [
                        {'path': '/*'}
                    ],
                    'excludedPaths': [
                        # Rule 5.2: Exclude sensor values (only queried after retrieval)
                        {'path': '/temperature/?'},
                        {'path': '/humidity/?'},
                        {'path': '/batteryLevel/?'},
                        {'path': '/"_etag"/?'}
                    ],
                    # Rule 5.1: Composite index for time-range queries within a device partition
                    'compositeIndexes': [
                        [
                            {'path': '/deviceId', 'order': 'ascending'},
                            {'path': '/timestamp', 'order': 'descending'}
                        ]
                    ]
                },
                # TTL enabled: Container-level setting allows document-level TTL
                default_ttl=-1  # -1 means "on" but use per-document TTL values
            )
            logger.info("Telemetry container ready (partition key: /deviceId)")
            logger.info("Note: Local emulator doesn't support hierarchical partition keys")
            logger.info("For production: use hierarchical key [/deviceId, /yearMonth]")
            logger.info("TTL enabled: Documents expire after 30 days")
        except exceptions.CosmosResourceExistsError:
            telemetry_container = database.get_container_client("telemetry")
            logger.info("Telemetry container already exists")
        
        return database, devices_container, telemetry_container
        
    except Exception as e:
        logger.error(f"Failed to initialize database: {e}")
        raise
