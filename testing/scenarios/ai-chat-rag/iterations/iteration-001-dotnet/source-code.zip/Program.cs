using AIChatRAG.Api.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Rule 4.13: Register CosmosDbService as singleton (contains singleton CosmosClient)
builder.Services.AddSingleton<CosmosDbService>();

// Register repositories as scoped (per-request)
builder.Services.AddScoped<ChatRepository>();
builder.Services.AddScoped<DocumentRepository>();

var app = builder.Build();

// Initialize database on startup
try
{
    using (var scope = app.Services.CreateScope())
    {
        var cosmosDbService = scope.ServiceProvider.GetRequiredService<CosmosDbService>();
        await cosmosDbService.InitializeDatabaseAsync();
    }
}
catch (Exception ex)
{
    Console.WriteLine($"FATAL ERROR during database initialization: {ex.Message}");
    Console.WriteLine($"Exception type: {ex.GetType().Name}");
    Console.WriteLine($"Stack trace: {ex.StackTrace}");
    if (ex.InnerException != null)
    {
        Console.WriteLine($"Inner exception: {ex.InnerException.Message}");
    }
    throw;
}

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();
app.MapControllers();

app.Run();
