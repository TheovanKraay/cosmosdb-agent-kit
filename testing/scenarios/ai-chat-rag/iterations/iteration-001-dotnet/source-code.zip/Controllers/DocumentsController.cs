using Microsoft.AspNetCore.Mvc;
using AIChatRAG.Api.Models;
using AIChatRAG.Api.Services;

namespace AIChatRAG.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DocumentsController : ControllerBase
{
    private readonly DocumentRepository _documentRepository;
    private readonly ILogger<DocumentsController> _logger;

    public DocumentsController(DocumentRepository documentRepository, ILogger<DocumentsController> logger)
    {
        _documentRepository = documentRepository;
        _logger = logger;
    }

    [HttpPost]
    public async Task<ActionResult<DocumentChunk>> StoreDocument([FromBody] StoreDocumentRequest request)
    {
        try
        {
            var document = await _documentRepository.StoreDocumentChunkAsync(request);
            return CreatedAtAction(nameof(GetDocumentChunks), 
                new { documentId = document.documentId, category = document.category }, 
                document);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error storing document");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpPost("bulk")]
    public async Task<ActionResult<object>> BulkStoreDocuments([FromBody] List<StoreDocumentRequest> requests)
    {
        try
        {
            var count = await _documentRepository.BulkStoreDocumentsAsync(requests);
            return Ok(new { stored = count });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error bulk storing documents");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpGet("{documentId}")]
    public async Task<ActionResult<List<DocumentChunk>>> GetDocumentChunks(
        string documentId, 
        [FromQuery] string category)
    {
        try
        {
            var chunks = await _documentRepository.GetDocumentChunksAsync(documentId, category);
            return Ok(chunks);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting document chunks for {DocumentId}", documentId);
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpPost("search")]
    public async Task<ActionResult<List<DocumentChunk>>> VectorSearch([FromBody] VectorSearchRequest request)
    {
        try
        {
            var results = await _documentRepository.VectorSearchAsync(
                request.queryEmbedding,
                request.topK,
                request.category
            );
            return Ok(results);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error performing vector search");
            return StatusCode(500, "Internal server error");
        }
    }
}
