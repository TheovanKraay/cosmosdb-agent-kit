using Microsoft.AspNetCore.Mvc;
using AIChatRAG.Api.Models;
using AIChatRAG.Api.Services;

namespace AIChatRAG.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ChatController : ControllerBase
{
    private readonly ChatRepository _chatRepository;
    private readonly ILogger<ChatController> _logger;

    public ChatController(ChatRepository chatRepository, ILogger<ChatController> logger)
    {
        _chatRepository = chatRepository;
        _logger = logger;
    }

    [HttpPost("sessions")]
    public async Task<ActionResult<ChatSession>> CreateSession([FromBody] CreateSessionRequest request)
    {
        try
        {
            var session = await _chatRepository.CreateSessionAsync(request.userId, request.title);
            return CreatedAtAction(nameof(GetSession), new { sessionId = session.id, userId = session.userId }, session);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating session");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpGet("sessions/{sessionId}")]
    public async Task<ActionResult<ChatSession>> GetSession(string sessionId, [FromQuery] string userId)
    {
        try
        {
            var session = await _chatRepository.GetSessionAsync(sessionId, userId);
            if (session == null)
            {
                return NotFound();
            }
            return Ok(session);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting session {SessionId}", sessionId);
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpPost("messages")]
    public async Task<ActionResult<ChatSession>> AddMessage([FromBody] AddMessageRequest request)
    {
        try
        {
            var session = await _chatRepository.AddMessageAsync(
                request.sessionId, 
                request.userId, 
                request.role, 
                request.content
            );
            return Ok(session);
        }
        catch (ArgumentException ex)
        {
            return NotFound(ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error adding message to session {SessionId}", request.sessionId);
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpGet("sessions")]
    public async Task<ActionResult<object>> GetUserSessions(
        [FromQuery] string userId, 
        [FromQuery] int maxItems = 20,
        [FromQuery] string? continuationToken = null)
    {
        try
        {
            var (sessions, nextToken) = await _chatRepository.GetUserSessionsAsync(userId, maxItems, continuationToken);
            
            return Ok(new
            {
                sessions,
                continuationToken = nextToken,
                hasMore = nextToken != null
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting sessions for user {UserId}", userId);
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpGet("sessions/{sessionId}/history")]
    public async Task<ActionResult<List<ChatMessage>>> GetSessionHistory(
        string sessionId, 
        [FromQuery] string userId,
        [FromQuery] int maxMessages = 50)
    {
        try
        {
            var messages = await _chatRepository.GetSessionHistoryAsync(sessionId, userId, maxMessages);
            return Ok(messages);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting history for session {SessionId}", sessionId);
            return StatusCode(500, "Internal server error");
        }
    }
}
