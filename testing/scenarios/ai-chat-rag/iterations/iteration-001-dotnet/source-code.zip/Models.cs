namespace AIChatRAG.Api.Models;

/// <summary>
/// Rule 1.5: Schema versioning for evolving AI models
/// Rule 1.6: Type discriminator for polymorphic documents
/// </summary>
public class ChatSession
{
    public string id { get; set; } = Guid.NewGuid().ToString();
    
    // Rule 1.6: Type discriminator
    public string type { get; set; } = "session";
    
    // Rule 2.5: Partition key aligned with access pattern (userId)
    public string userId { get; set; } = string.Empty;
    
    public string title { get; set; } = string.Empty;
    
    // Rule 1.2: Denormalize frequently accessed data
    public int messageCount { get; set; } = 0;
    
    public DateTime createdAt { get; set; } = DateTime.UtcNow;
    public DateTime lastMessageAt { get; set; } = DateTime.UtcNow;
    
    // Rule 1.5: Schema version for future evolution
    public int schemaVersion { get; set; } = 1;
    
    // Rule 1.3: Embed messages for read efficiency
    public List<ChatMessage> messages { get; set; } = new();
}

public class ChatMessage
{
    public string id { get; set; } = Guid.NewGuid().ToString();
    public string role { get; set; } = string.Empty; // "user" or "assistant"
    public string content { get; set; } = string.Empty;
    public DateTime timestamp { get; set; } = DateTime.UtcNow;
    
    // Optional: Token count for limiting context window
    public int? tokenCount { get; set; }
}

/// <summary>
/// Document chunk with vector embedding for RAG
/// Rule 2.3: Consider hierarchical partition key for large scale [documentId, category]
/// </summary>
public class DocumentChunk
{
    public string id { get; set; } = Guid.NewGuid().ToString();
    
    // Rule 1.6: Type discriminator
    public string type { get; set; } = "document";
    
    // Rule 2.5: Partition key for even distribution
    public string category { get; set; } = string.Empty;
    
    public string documentId { get; set; } = string.Empty;
    public string title { get; set; } = string.Empty;
    public string content { get; set; } = string.Empty;
    public int chunkIndex { get; set; }
    
    // Vector embedding for similarity search (1536 dimensions for text-embedding-ada-002)
    public float[] embedding { get; set; } = Array.Empty<float>();
    
    // Metadata for hybrid search
    public Dictionary<string, string> metadata { get; set; } = new();
    
    public DateTime createdAt { get; set; } = DateTime.UtcNow;
    
    // Rule 1.5: Schema version
    public int schemaVersion { get; set; } = 1;
}

// DTOs for API
public class CreateSessionRequest
{
    public string userId { get; set; } = string.Empty;
    public string title { get; set; } = string.Empty;
}

public class AddMessageRequest
{
    public string sessionId { get; set; } = string.Empty;
    public string userId { get; set; } = string.Empty;
    public string role { get; set; } = string.Empty;
    public string content { get; set; } = string.Empty;
}

public class StoreDocumentRequest
{
    public string documentId { get; set; } = string.Empty;
    public string category { get; set; } = string.Empty;
    public string title { get; set; } = string.Empty;
    public string content { get; set; } = string.Empty;
    public int chunkIndex { get; set; }
    public float[] embedding { get; set; } = Array.Empty<float>();
    public Dictionary<string, string>? metadata { get; set; }
}

public class VectorSearchRequest
{
    public float[] queryEmbedding { get; set; } = Array.Empty<float>();
    public int topK { get; set; } = 5;
    public string? category { get; set; } // For hybrid search
}
