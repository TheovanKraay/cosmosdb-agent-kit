using Microsoft.Azure.Cosmos;
using AIChatRAG.Api.Models;

namespace AIChatRAG.Api.Services;

/// <summary>
/// Repository for chat session operations
/// </summary>
public class ChatRepository
{
    private readonly Container _container;
    private readonly ILogger<ChatRepository> _logger;

    public ChatRepository(CosmosDbService cosmosDbService, ILogger<ChatRepository> logger)
    {
        _container = cosmosDbService.SessionsContainer;
        _logger = logger;
    }

    /// <summary>
    /// Rule 3.1: Single-partition query (userId)
    /// Rule 4.1: Async operations throughout
    /// </summary>
    public async Task<ChatSession> CreateSessionAsync(string userId, string title)
    {
        var session = new ChatSession
        {
            userId = userId,
            title = title,
            createdAt = DateTime.UtcNow,
            lastMessageAt = DateTime.UtcNow
        };

        // Rule 3.1: Specify partition key for write
        var response = await _container.CreateItemAsync(
            session,
            new PartitionKey(userId)
        );

        _logger.LogInformation("Created session {SessionId} for user {UserId}", session.id, userId);
        return response.Resource;
    }

    /// <summary>
    /// Rule 3.1: Point read (most efficient operation)
    /// </summary>
    public async Task<ChatSession?> GetSessionAsync(string sessionId, string userId)
    {
        try
        {
            // Rule 3.1: Point read with partition key
            var response = await _container.ReadItemAsync<ChatSession>(
                sessionId,
                new PartitionKey(userId)
            );
            return response.Resource;
        }
        catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return null;
        }
    }

    /// <summary>
    /// Add message to session
    /// Rule 1.3: Embedded messages for read efficiency
    /// Rule 1.2: Denormalized message count
    /// </summary>
    public async Task<ChatSession> AddMessageAsync(string sessionId, string userId, string role, string content, int? tokenCount = null)
    {
        var session = await GetSessionAsync(sessionId, userId);
        if (session == null)
        {
            throw new ArgumentException($"Session {sessionId} not found");
        }

        var message = new ChatMessage
        {
            role = role,
            content = content,
            timestamp = DateTime.UtcNow,
            tokenCount = tokenCount
        };

        session.messages.Add(message);
        session.messageCount = session.messages.Count; // Rule 1.2: Denormalized count
        session.lastMessageAt = DateTime.UtcNow;

        // Replace entire session document
        var response = await _container.ReplaceItemAsync(
            session,
            session.id,
            new PartitionKey(userId)
        );

        _logger.LogInformation("Added {Role} message to session {SessionId}", role, sessionId);
        return response.Resource;
    }

    /// <summary>
    /// Rule 3.1: Single-partition query with ORDER BY
    /// Rule 3.4: Pagination with continuation token
    /// Rule 3.6: ORDER BY uses composite index
    /// </summary>
    public async Task<(List<ChatSession> sessions, string? continuationToken)> GetUserSessionsAsync(
        string userId, 
        int maxItems = 20, 
        string? continuationToken = null)
    {
        // Rule 3.5: Parameterized query
        var queryText = "SELECT * FROM c WHERE c.userId = @userId AND c.type = @type ORDER BY c.lastMessageAt DESC";
        
        var queryDefinition = new QueryDefinition(queryText)
            .WithParameter("@userId", userId)
            .WithParameter("@type", "session");

        var queryRequestOptions = new QueryRequestOptions
        {
            PartitionKey = new PartitionKey(userId), // Rule 3.1: Single-partition
            MaxItemCount = maxItems
        };

        var sessions = new List<ChatSession>();
        var iterator = _container.GetItemQueryIterator<ChatSession>(
            queryDefinition,
            continuationToken,
            queryRequestOptions
        );

        // Rule 3.4: Pagination - get one page
        if (iterator.HasMoreResults)
        {
            var response = await iterator.ReadNextAsync();
            sessions.AddRange(response);
            continuationToken = response.ContinuationToken;
        }

        return (sessions, continuationToken);
    }

    /// <summary>
    /// Get session history with configurable message limit
    /// Rule 3.2: Use projections to limit data transfer
    /// </summary>
    public async Task<List<ChatMessage>> GetSessionHistoryAsync(string sessionId, string userId, int maxMessages = 50)
    {
        var session = await GetSessionAsync(sessionId, userId);
        if (session == null)
        {
            return new List<ChatMessage>();
        }

        // Return most recent N messages
        // Rule: Limit embedded array size - consider separate container for very long conversations
        return session.messages
            .OrderByDescending(m => m.timestamp)
            .Take(maxMessages)
            .Reverse() // Return in chronological order
            .ToList();
    }
}
