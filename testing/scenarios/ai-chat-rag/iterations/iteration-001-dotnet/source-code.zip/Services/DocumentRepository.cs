using Microsoft.Azure.Cosmos;
using AIChatRAG.Api.Models;

namespace AIChatRAG.Api.Services;

/// <summary>
/// Repository for document and vector search operations
/// </summary>
public class DocumentRepository
{
    private readonly Container _container;
    private readonly ILogger<DocumentRepository> _logger;

    public DocumentRepository(CosmosDbService cosmosDbService, ILogger<DocumentRepository> logger)
    {
        _container = cosmosDbService.DocumentsContainer;
        _logger = logger;
    }

    /// <summary>
    /// Store document chunk with embedding
    /// Rule 1.1: Avoid 2MB limit - split large documents into chunks
    /// </summary>
    public async Task<DocumentChunk> StoreDocumentChunkAsync(StoreDocumentRequest request)
    {
        var document = new DocumentChunk
        {
            documentId = request.documentId,
            category = request.category,
            title = request.title,
            content = request.content,
            chunkIndex = request.chunkIndex,
            embedding = request.embedding,
            metadata = request.metadata ?? new Dictionary<string, string>(),
            createdAt = DateTime.UtcNow
        };

        // Rule 3.1: Specify partition key
        var response = await _container.CreateItemAsync(
            document,
            new PartitionKey(request.category)
        );

        _logger.LogInformation("Stored document chunk {ChunkId} for document {DocumentId}", 
            document.id, document.documentId);
        
        return response.Resource;
    }

    /// <summary>
    /// Vector similarity search using Cosmos DB vector search
    /// CRITICAL: This is the core RAG operation
    /// </summary>
    public async Task<List<DocumentChunk>> VectorSearchAsync(
        float[] queryEmbedding, 
        int topK = 5, 
        string? category = null)
    {
        // VECTOR SEARCH QUERY
        // Uses VectorDistance function for similarity search
        string queryText;
        QueryDefinition queryDefinition;

        if (string.IsNullOrEmpty(category))
        {
            // Pure vector search across all categories
            queryText = @"
                SELECT TOP @topK c.id, c.documentId, c.title, c.content, c.category, c.chunkIndex, c.metadata,
                       VectorDistance(c.embedding, @embedding) AS similarityScore
                FROM c
                WHERE c.type = @type
                ORDER BY VectorDistance(c.embedding, @embedding)";
            
            queryDefinition = new QueryDefinition(queryText)
                .WithParameter("@topK", topK)
                .WithParameter("@embedding", queryEmbedding)
                .WithParameter("@type", "document");
        }
        else
        {
            // HYBRID SEARCH: Vector similarity + metadata filter
            // Rule 3.1: Single-partition query when filtering by category
            queryText = @"
                SELECT TOP @topK c.id, c.documentId, c.title, c.content, c.category, c.chunkIndex, c.metadata,
                       VectorDistance(c.embedding, @embedding) AS similarityScore
                FROM c
                WHERE c.category = @category AND c.type = @type
                ORDER BY VectorDistance(c.embedding, @embedding)";
            
            queryDefinition = new QueryDefinition(queryText)
                .WithParameter("@topK", topK)
                .WithParameter("@embedding", queryEmbedding)
                .WithParameter("@category", category)
                .WithParameter("@type", "document");
        }

        var queryRequestOptions = new QueryRequestOptions
        {
            // If category specified, use single-partition query
            PartitionKey = category != null ? new PartitionKey(category) : null
        };

        var results = new List<DocumentChunk>();
        var iterator = _container.GetItemQueryIterator<DocumentChunk>(
            queryDefinition,
            requestOptions: queryRequestOptions
        );

        while (iterator.HasMoreResults)
        {
            var response = await iterator.ReadNextAsync();
            results.AddRange(response);
        }

        _logger.LogInformation("Vector search returned {Count} results (topK={TopK}, category={Category})", 
            results.Count, topK, category ?? "all");
        
        return results;
    }

    /// <summary>
    /// Get all chunks for a specific document
    /// Rule 3.1: Single-partition query
    /// </summary>
    public async Task<List<DocumentChunk>> GetDocumentChunksAsync(string documentId, string category)
    {
        // Rule 3.5: Parameterized query
        var queryText = "SELECT * FROM c WHERE c.documentId = @documentId AND c.category = @category ORDER BY c.chunkIndex";
        
        var queryDefinition = new QueryDefinition(queryText)
            .WithParameter("@documentId", documentId)
            .WithParameter("@category", category);

        var queryRequestOptions = new QueryRequestOptions
        {
            PartitionKey = new PartitionKey(category) // Rule 3.1: Single-partition
        };

        var results = new List<DocumentChunk>();
        var iterator = _container.GetItemQueryIterator<DocumentChunk>(
            queryDefinition,
            requestOptions: queryRequestOptions
        );

        while (iterator.HasMoreResults)
        {
            var response = await iterator.ReadNextAsync();
            results.AddRange(response);
        }

        return results;
    }

    /// <summary>
    /// Bulk document ingestion
    /// Rule 4.8: Use bulk operations for high throughput
    /// </summary>
    public async Task<int> BulkStoreDocumentsAsync(List<StoreDocumentRequest> requests)
    {
        // Convert requests to DocumentChunks
        var documents = requests.Select(r => new DocumentChunk
        {
            documentId = r.documentId,
            category = r.category,
            title = r.title,
            content = r.content,
            chunkIndex = r.chunkIndex,
            embedding = r.embedding,
            metadata = r.metadata ?? new Dictionary<string, string>(),
            createdAt = DateTime.UtcNow
        }).ToList();

        // Enable bulk execution
        var bulkOperations = documents.Select(doc => 
            _container.CreateItemAsync(doc, new PartitionKey(doc.category))
        );

        var results = await Task.WhenAll(bulkOperations);
        
        _logger.LogInformation("Bulk stored {Count} document chunks", results.Length);
        return results.Length;
    }
}
