using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Fluent;
using System.Collections.ObjectModel;
using Azure.Identity;

namespace AIChatRAG.Api.Services;

/// <summary>
/// Cosmos DB service with vector search support
/// </summary>
public class CosmosDbService
{
    private readonly CosmosClient _cosmosClient;
    private readonly Database _database;
    private readonly Container _sessionsContainer;
    private readonly Container _documentsContainer;
    private readonly ILogger<CosmosDbService> _logger;

    public CosmosDbService(IConfiguration configuration, ILogger<CosmosDbService> logger)
    {
        _logger = logger;
        
        var endpoint = configuration["CosmosDb:Endpoint"] 
            ?? throw new ArgumentException("CosmosDb:Endpoint not configured");
        var useKey = configuration.GetValue<bool>("CosmosDb:UseKey", false);
        var databaseName = configuration["CosmosDb:DatabaseName"] ?? "ai-chat-rag-db";

        _logger.LogInformation("Configuration: UseKey={UseKey}, Endpoint={Endpoint}", useKey, endpoint);

        // Rule 4.13: Singleton client instance
        // Rule 4.3: Direct mode for better performance (default in SDK v3+)
        if (useKey)
        {
            var key = configuration["CosmosDb:Key"] 
                ?? throw new ArgumentException("CosmosDb:Key not configured");
            _cosmosClient = new CosmosClientBuilder(endpoint, key)
                .WithConnectionModeDirect()
                .WithApplicationName("ai-chat-rag-api")
                .Build();
            _logger.LogInformation("CosmosClient initialized with key authentication");
        }
        else
        {
            // Use DefaultAzureCredential for Azure AD authentication
            _cosmosClient = new CosmosClientBuilder(endpoint, new DefaultAzureCredential())
                .WithConnectionModeDirect()
                .WithApplicationName("ai-chat-rag-api")
                .Build();
            _logger.LogInformation("CosmosClient initialized with DefaultAzureCredential (Azure AD)");
        }

        _database = _cosmosClient.GetDatabase(databaseName);
        _sessionsContainer = _database.GetContainer("sessions");
        _documentsContainer = _database.GetContainer("documents");
        
        _logger.LogInformation("CosmosDbService initialized with database: {DatabaseName}", databaseName);
    }

    /// <summary>
    /// Initialize database and containers with vector search configuration
    /// </summary>
    public async Task InitializeDatabaseAsync()
    {
        _logger.LogInformation("Initializing Cosmos DB database and containers...");

        try
        {
            // Rule 6.4: Container-level throughput for shared RU/s (more cost-effective for dev/test)
            var databaseResponse = await _cosmosClient.CreateDatabaseIfNotExistsAsync(
                _database.Id,
                ThroughputProperties.CreateAutoscaleThroughput(4000) // Rule 6.1: Autoscale
            );
            _logger.LogInformation("Database ready: {DatabaseId}", databaseResponse.Database.Id);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to create/access database. Error: {Message}", ex.Message);
            throw;
        }

        // ========================================
        // SESSIONS CONTAINER
        // ========================================
        var sessionsContainerProperties = new ContainerProperties
        {
            Id = "sessions",
            // Rule 2.5: Partition by userId for efficient user queries
            PartitionKeyPath = "/userId",
            
            // Rule 5.1: Composite index for time-range queries
            // Rule 5.2: Exclude large arrays (messages, embedding) from indexing
            IndexingPolicy = new IndexingPolicy
            {
                Automatic = true,
                IndexingMode = IndexingMode.Consistent,
                IncludedPaths =
                {
                    new IncludedPath { Path = "/*" }
                },
                ExcludedPaths =
                {
                    new ExcludedPath { Path = "/messages/*" }, // Rule 5.2: Exclude embedded messages array
                    new ExcludedPath { Path = "/\"_etag\"/?" }
                },
                // Rule 5.1: Composite index for sorting by lastMessageAt
                CompositeIndexes =
                {
                    new Collection<CompositePath>
                    {
                        new() { Path = "/userId", Order = CompositePathSortOrder.Ascending },
                        new() { Path = "/lastMessageAt", Order = CompositePathSortOrder.Descending }
                    }
                }
            }
        };

        await _database.CreateContainerIfNotExistsAsync(sessionsContainerProperties);
        _logger.LogInformation("Sessions container ready");

        // ========================================
        // DOCUMENTS CONTAINER WITH VECTOR SEARCH
        // ========================================
        var documentsContainerProperties = new ContainerProperties
        {
            Id = "documents",
            // Rule 2.5: Partition by category for balanced distribution
            PartitionKeyPath = "/category",
            
            // VECTOR EMBEDDING POLICY
            // Define vector embeddings per official documentation
            VectorEmbeddingPolicy = new VectorEmbeddingPolicy(
                new Collection<Embedding>
                {
                    new Embedding
                    {
                        Path = "/embedding",
                        DataType = VectorDataType.Float32,
                        Dimensions = 1536, // text-embedding-ada-002
                        DistanceFunction = DistanceFunction.Cosine
                    }
                }
            ),
            
            // VECTOR INDEX POLICY
            // Configure vector indexes per official documentation
            IndexingPolicy = new IndexingPolicy
            {
                Automatic = true,
                IndexingMode = IndexingMode.Consistent,
                IncludedPaths =
                {
                    new IncludedPath { Path = "/*" }
                },
                ExcludedPaths =
                {
                    new ExcludedPath { Path = "/content/?" }, // Rule 5.2: Exclude large text
                    new ExcludedPath { Path = "/embedding/*" }, // Rule 5.2: CRITICAL - Exclude vector array
                    new ExcludedPath { Path = "/\"_etag\"/?" }
                },
                // Rule 5.1: Composite index for category + date sorting
                CompositeIndexes =
                {
                    new Collection<CompositePath>
                    {
                        new() { Path = "/category", Order = CompositePathSortOrder.Ascending },
                        new() { Path = "/createdAt", Order = CompositePathSortOrder.Descending }
                    }
                },
                // VECTOR INDEXES - Supported in SDK 3.45.0+
                VectorIndexes = new Collection<VectorIndexPath>
                {
                    new VectorIndexPath
                    {
                        Path = "/embedding",
                        Type = VectorIndexType.QuantizedFlat // Recommended for balanced performance
                    }
                }
            }
        };

        await _database.CreateContainerIfNotExistsAsync(documentsContainerProperties);
        _logger.LogInformation("Documents container created with vector search configuration (QuantizedFlat index)");
    }

    public Container SessionsContainer => _sessionsContainer;
    public Container DocumentsContainer => _documentsContainer;
}
