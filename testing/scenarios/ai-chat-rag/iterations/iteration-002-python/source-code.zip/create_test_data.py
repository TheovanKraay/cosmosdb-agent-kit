"""
Test Data Generator for AI Chat RAG application.
Creates sample documents with mock embeddings and chat sessions.
"""
import asyncio
import random
from datetime import datetime
from azure.cosmos import CosmosClient
from azure.identity import DefaultAzureCredential
import numpy as np
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Cosmos DB configuration
COSMOS_ENDPOINT = os.getenv("COSMOS_ENDPOINT")
DATABASE_NAME = "ai-chat-rag-db"
SESSIONS_CONTAINER = "sessions"
DOCUMENTS_CONTAINER = "documents"

# Sample data
SAMPLE_DOCUMENTS = [
    {
        "title": "Introduction to Azure Cosmos DB",
        "content": "Azure Cosmos DB is a globally distributed, multi-model database service designed for high availability and low latency.",
        "category": "azure"
    },
    {
        "title": "Vector Search Overview",
        "content": "Vector search enables semantic similarity matching by comparing vector embeddings using distance functions like cosine similarity.",
        "category": "ai"
    },
    {
        "title": "RAG Pattern Explained",
        "content": "Retrieval Augmented Generation (RAG) combines vector search with language models to generate responses grounded in custom data.",
        "category": "ai"
    },
    {
        "title": "Partition Key Best Practices",
        "content": "Choose partition keys with high cardinality that align with query patterns to ensure even data distribution and optimal performance.",
        "category": "azure"
    },
    {
        "title": "Indexing Policies for Vector Search",
        "content": "Exclude vector embeddings from default indexing to reduce RU costs. Use specialized vector indexes like QuantizedFlat or DiskANN.",
        "category": "azure"
    },
    {
        "title": "Python SDK for Cosmos DB",
        "content": "The Azure Cosmos DB Python SDK provides async support, bulk operations, and vector search capabilities for efficient data access.",
        "category": "development"
    },
    {
        "title": "Embedding Generation Techniques",
        "content": "Generate high-quality embeddings using models like Ada-002 or text-embedding-3-large for effective semantic search applications.",
        "category": "ai"
    },
    {
        "title": "Multi-Region Replication",
        "content": "Enable multi-region writes and reads to achieve global distribution, high availability, and low-latency access for users worldwide.",
        "category": "azure"
    },
    {
        "title": "Change Feed Processing",
        "content": "Use change feed to process real-time data changes, build event-driven architectures, and maintain materialized views.",
        "category": "azure"
    },
    {
        "title": "Cost Optimization Strategies",
        "content": "Optimize costs by right-sizing throughput, using serverless for unpredictable workloads, and implementing efficient indexing policies.",
        "category": "azure"
    }
]

SAMPLE_CHAT_SESSIONS = [
    {
        "userId": "user123",
        "title": "Getting started with vector search",
        "messages": [
            {"role": "user", "content": "What is vector search?"},
            {"role": "assistant", "content": "Vector search is a technique for finding similar items by comparing their vector embeddings using distance metrics like cosine similarity."},
            {"role": "user", "content": "How do I implement it in Cosmos DB?"},
            {"role": "assistant", "content": "You can enable vector search by creating containers with vector embedding policies and vector indexes. Use VectorDistance() in queries."}
        ]
    },
    {
        "userId": "user123",
        "title": "Understanding RAG patterns",
        "messages": [
            {"role": "user", "content": "Explain the RAG pattern"},
            {"role": "assistant", "content": "RAG (Retrieval Augmented Generation) combines vector search to find relevant documents with LLMs to generate informed responses."}
        ]
    },
    {
        "userId": "user456",
        "title": "Partition key selection",
        "messages": [
            {"role": "user", "content": "How do I choose a good partition key?"},
            {"role": "assistant", "content": "Choose a partition key with high cardinality that matches your query patterns. Avoid hotspots by ensuring even distribution."},
            {"role": "user", "content": "What about hierarchical partition keys?"},
            {"role": "assistant", "content": "Hierarchical partition keys allow you to partition by multiple fields like [tenantId, userId, sessionId] for better distribution."}
        ]
    }
]


def generate_mock_embedding(text: str, dimensions: int = 1536) -> list:
    """
    Generate a mock embedding vector for testing.
    In production, use Azure OpenAI embeddings.
    
    Creates a deterministic embedding based on text hash for reproducibility.
    """
    # Use text hash as seed for reproducible embeddings
    seed = hash(text) % (2**32)
    np.random.seed(seed)
    
    # Generate random vector
    vector = np.random.randn(dimensions).astype(np.float32)
    
    # Normalize to unit length (important for cosine similarity)
    vector = vector / np.linalg.norm(vector)
    
    return vector.tolist()


def main():
    """Main function to insert test data"""
    print("=" * 60)
    print("AI Chat RAG - Test Data Generator")
    print("=" * 60)
    
    # Initialize Cosmos client
    print(f"\n[1/4] Connecting to Cosmos DB...")
    print(f"  Endpoint: {COSMOS_ENDPOINT}")
    
    client = CosmosClient(COSMOS_ENDPOINT, credential=DefaultAzureCredential())
    database = client.get_database_client(DATABASE_NAME)
    sessions_container = database.get_container_client(SESSIONS_CONTAINER)
    documents_container = database.get_container_client(DOCUMENTS_CONTAINER)
    print("  [OK] Connected successfully")
    
    # Insert documents with embeddings
    print(f"\n[2/4] Inserting {len(SAMPLE_DOCUMENTS)} documents...")
    docs_inserted = 0
    for doc_data in SAMPLE_DOCUMENTS:
        try:
            # Generate embedding from content
            embedding = generate_mock_embedding(doc_data["content"])
            
            # Create document
            document = {
                "id": f"doc_{docs_inserted + 1}",
                "category": doc_data["category"],
                "title": doc_data["title"],
                "content": doc_data["content"],
                "embedding": embedding,
                "metadata": {
                    "source": "test_data_generator",
                    "created_at": datetime.utcnow().isoformat()
                }
            }
            
            # Upsert document
            documents_container.upsert_item(document)
            docs_inserted += 1
            print(f"  [OK] Inserted: {doc_data['title'][:50]}...")
            
        except Exception as e:
            print(f"  [ERROR] Failed to insert {doc_data['title']}: {str(e)}")
    
    print(f"  [OK] Inserted {docs_inserted} documents successfully")
    
    # Insert chat sessions
    print(f"\n[3/4] Inserting {len(SAMPLE_CHAT_SESSIONS)} chat sessions...")
    sessions_inserted = 0
    for session_data in SAMPLE_CHAT_SESSIONS:
        try:
            # Create session document
            session = {
                "id": f"session_{sessions_inserted + 1}",
                "userId": session_data["userId"],
                "title": session_data["title"],
                "messages": [
                    {
                        "id": f"msg_{idx + 1}",
                        "role": msg["role"],
                        "content": msg["content"],
                        "timestamp": datetime.utcnow().isoformat()
                    }
                    for idx, msg in enumerate(session_data["messages"])
                ],
                "createdAt": datetime.utcnow().isoformat(),
                "updatedAt": datetime.utcnow().isoformat()
            }
            
            # Create session (partition key is userId)
            sessions_container.create_item(session)
            sessions_inserted += 1
            print(f"  [OK] Inserted: {session_data['title'][:50]}...")
            
        except Exception as e:
            print(f"  [ERROR] Failed to insert session {session_data['title']}: {str(e)}")
    
    print(f"  [OK] Inserted {sessions_inserted} sessions successfully")
    
    # Summary
    print(f"\n[4/4] Summary:")
    print(f"  Documents inserted: {docs_inserted}/{len(SAMPLE_DOCUMENTS)}")
    print(f"  Sessions inserted: {sessions_inserted}/{len(SAMPLE_CHAT_SESSIONS)}")
    print(f"\n  You can now view this data in:")
    print(f"  - Azure Portal: {COSMOS_ENDPOINT}")
    print(f"  - Database: {DATABASE_NAME}")
    print(f"  - Containers: {SESSIONS_CONTAINER}, {DOCUMENTS_CONTAINER}")
    print("\n" + "=" * 60)
    print("Test data insertion complete!")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    main()
