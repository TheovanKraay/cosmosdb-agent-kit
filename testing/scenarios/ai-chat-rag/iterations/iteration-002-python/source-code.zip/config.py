"""
Configuration management for AI Chat RAG application.
Rule 4.10: Load environment variables explicitly to avoid conflicts.
"""
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

# Rule 4.10: Load .env explicitly with override=True to prevent system env conflicts
load_dotenv(override=True)


class Settings(BaseSettings):
    """Application settings with Azure Cosmos DB configuration."""
    
    # Cosmos DB settings
    cosmos_endpoint: str
    cosmos_database: str = "ai-chat-rag-db"
    
    class Config:
        env_file = ".env"
        case_sensitive = False


# Create global settings instance
settings = Settings()

# Rule 4.10: Log endpoint at startup to verify correct configuration
print(f"[OK] Configuration loaded - Endpoint: {settings.cosmos_endpoint}")
print(f"[OK] Database: {settings.cosmos_database}")
print(f"[OK] Authentication: DefaultAzureCredential (Azure AD)")
