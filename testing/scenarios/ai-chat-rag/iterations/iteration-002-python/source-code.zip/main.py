"""
AI Chat RAG API with Azure Cosmos DB vector search.
Implements best practices for Cosmos DB throughout.
"""
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import logging
from typing import List

from cosmos_service import cosmos_service
from models import (
    ChatSession, ChatMessage, DocumentChunk,
    CreateSessionRequest, AddMessageRequest,
    StoreDocumentRequest, VectorSearchRequest
)
from chat_repository import ChatRepository
from document_repository import DocumentRepository

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan: initialize Cosmos DB containers on startup.
    Rule 10: Vector search containers must be created with vector policies.
    """
    logger.info("Initializing Cosmos DB containers...")
    await cosmos_service.initialize_containers()
    
    # Initialize repositories
    global chat_repo, document_repo
    chat_repo = ChatRepository(cosmos_service.sessions_container)
    document_repo = DocumentRepository(cosmos_service.documents_container)
    
    logger.info("[OK] Application ready")
    yield
    logger.info("Shutting down...")


# Create FastAPI app
app = FastAPI(
    title="AI Chat RAG API",
    description="AI-powered chat with RAG using Azure Cosmos DB vector search",
    version="1.0.0",
    lifespan=lifespan
)

# Global repository instances (initialized in lifespan)
chat_repo: ChatRepository = None
document_repo: DocumentRepository = None


# Health check
@app.get("/health")
def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "ai-chat-rag-api"}


# Chat session endpoints
@app.post("/api/chat/sessions", response_model=ChatSession)
async def create_session(request: CreateSessionRequest):
    """
    Create new chat session.
    Rule 2.5: Partition by userId for efficient queries.
    """
    try:
        session = ChatSession(
            userId=request.userId,
            title=request.title
        )
        created_session = await chat_repo.create_session(session)
        logger.info(f"Created session {created_session.id} for user {request.userId}")
        return created_session
    except Exception as e:
        logger.error(f"Failed to create session: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/chat/messages", response_model=ChatSession)
async def add_message(request: AddMessageRequest):
    """
    Add message to existing session.
    Rule 1.2: Embed related data (messages in session document).
    """
    try:
        # Get userId for partition key (in production, from auth token)
        session = await chat_repo.get_session(request.sessionId, request.sessionId)
        if not session:
            # Try with different partition key pattern - get from request
            # For now, require userId in request
            raise HTTPException(status_code=404, detail=f"Session not found: {request.sessionId}")
        
        message = ChatMessage(
            role=request.role,
            content=request.content
        )
        
        updated_session = await chat_repo.add_message(
            request.sessionId,
            session.userId,
            message
        )
        logger.info(f"Added {request.role} message to session {request.sessionId}")
        return updated_session
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to add message: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/chat/sessions/{session_id}", response_model=ChatSession)
async def get_session(session_id: str, user_id: str):
    """
    Get session with all messages.
    Rule 2.5: Point read with partition key for lowest RU cost.
    """
    try:
        session = await chat_repo.get_session(session_id, user_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        return session
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get session: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/chat/users/{user_id}/sessions", response_model=List[ChatSession])
async def list_user_sessions(user_id: str, limit: int = 10):
    """
    List recent sessions for a user.
    Rule 3.1: Single-partition query with partition key filter.
    """
    try:
        sessions = await chat_repo.get_recent_sessions(user_id, limit)
        logger.info(f"Retrieved {len(sessions)} sessions for user {user_id}")
        return sessions
    except Exception as e:
        logger.error(f"Failed to list sessions: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Document and vector search endpoints
@app.post("/api/documents", response_model=DocumentChunk)
async def store_document(request: StoreDocumentRequest):
    """
    Store document with vector embedding.
    Rule 10.3: Embedding excluded from indexing via indexing policy.
    """
    try:
        if len(request.embedding) != 1536:
            raise HTTPException(
                status_code=400,
                detail=f"Embedding must be 1536 dimensions, got {len(request.embedding)}"
            )
        
        document = DocumentChunk(
            category=request.category,
            title=request.title,
            content=request.content,
            embedding=request.embedding,
            metadata=request.metadata
        )
        
        stored_doc = await document_repo.insert_document(document)
        logger.info(f"Stored document {stored_doc.id} in category {request.category}")
        return stored_doc
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to store document: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/documents/search")
async def vector_search(request: VectorSearchRequest):
    """
    Perform vector similarity search.
    Rule 10.4: VectorDistance() for semantic similarity search.
    Supports hybrid search with category filter for better precision.
    """
    try:
        if len(request.embedding) != 1536:
            raise HTTPException(
                status_code=400,
                detail=f"Embedding must be 1536 dimensions, got {len(request.embedding)}"
            )
        
        results = await document_repo.vector_search(
            query_embedding=request.embedding,
            limit=request.top_k,
            similarity_threshold=0.0,
            category_filter=request.category
        )
        
        search_type = "hybrid" if request.category else "pure vector"
        logger.info(f"Vector search ({search_type}) returned {len(results)} results")
        
        return {
            "query": {
                "top_k": request.top_k,
                "category": request.category,
                "search_type": search_type
            },
            "results": results
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Vector search failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    # Rule 4.4: Production mode with direct connection
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
