"""
Test vector search functionality directly
"""
import asyncio
import numpy as np
from document_repository import DocumentRepository
from cosmos_service import cosmos_service


async def test_vector_search():
    """Test vector search with mock embedding"""
    print("=" * 60)
    print("Testing Vector Search")
    print("=" * 60)
    
    # Initialize
    print("\n[1/3] Initializing Cosmos DB...")
    await cosmos_service.initialize_containers()
    repo = DocumentRepository(cosmos_service.documents_container)
    print("  [OK] Initialized")
    
    # Generate test embedding
    print("\n[2/3] Generating test embedding...")
    embedding = np.random.randn(1536).astype(np.float32)
    embedding = embedding / np.linalg.norm(embedding)  # Normalize
    embedding_list = embedding.tolist()
    print(f"  [OK] Generated {len(embedding_list)} dimension embedding")
    
    # Perform vector search
    print("\n[3/3] Performing vector search...")
    results = await repo.vector_search(embedding_list, limit=5)
    
    print(f"\n  Found {len(results)} results:")
    print("  " + "-" * 56)
    for idx, r in enumerate(results, 1):
        score = r.metadata.get('similarityScore', 0) if r.metadata else 0
        print(f"  {idx}. {r.title[:45]:<45} | Score: {score:.4f}")
        print(f"     Category: {r.category} | Content: {r.content[:50]}...")
    
    print("=" * 60)
    print(f"Vector search test complete! Returned {len(results)} results")
    print("=" * 60)
    
    return results


if __name__ == "__main__":
    asyncio.run(test_vector_search())
