"""
Azure Cosmos DB service for AI Chat RAG application.
Implements vector search with best practices.
"""
from azure.cosmos import CosmosClient, PartitionKey, exceptions
from azure.cosmos.aio import CosmosClient as AsyncCosmosClient
from azure.identity import DefaultAzureCredential
from typing import List, Dict, Any, Optional
import logging

from config import settings
from models import ChatSession, ChatMessage, DocumentChunk

logger = logging.getLogger(__name__)


class CosmosDBService:
    """
    Cosmos DB service with vector search support.
    Rule 4.14: Singleton client for connection pooling.
    Rule 4.4: Direct connection mode for production.
    Rule 10: Vector search configuration.
    """
    
    def __init__(self):
        """Initialize Cosmos DB client with DefaultAzureCredential (Azure AD)."""
        # Rule 4.14: Create singleton client
        # Rule 4.4: Direct mode is default in Python SDK
        credential = DefaultAzureCredential()
        
        self.client = CosmosClient(
            url=settings.cosmos_endpoint,
            credential=credential
        )
        
        self.database = self.client.get_database_client(settings.cosmos_database)
        logger.info(f"CosmosDB client initialized with DefaultAzureCredential")
        logger.info(f"Database: {settings.cosmos_database}")
        
    async def initialize_containers(self):
        """
        Initialize containers with vector search configuration.
        Rule 10.1: Vector embedding policy required.
        Rule 10.2: Vector indexes with QuantizedFlat.
        Rule 10.3: Exclude vector paths from regular indexing.
        Rule 6.1: Autoscale throughput for variable workloads.
        """
        try:
            # Sessions container (embedded messages pattern)
            # Rule 1.3: Embed messages for single-document retrieval
            # Rule 2.5: Partition by userId for query optimization
            
            # Rule 6.1: Autoscale 1000-4000 RU/s
            from azure.cosmos import ThroughputProperties
            sessions_throughput = ThroughputProperties(auto_scale_max_throughput=4000)
            
            try:
                sessions_container = self.database.create_container_if_not_exists(
                    id="sessions",
                    partition_key=PartitionKey(path="/userId"),
                    offer_throughput=sessions_throughput
                )
                logger.info("[OK] Sessions container ready")
            except exceptions.CosmosResourceExistsError:
                logger.info("[OK] Sessions container already exists")
                sessions_container = self.database.get_container_client("sessions")
            
            # Documents container with vector search
            # Rule 10.1: Vector embedding policy configuration
            vector_embedding_policy = {
                "vectorEmbeddings": [
                    {
                        "path": "/embedding",
                        "dataType": "float32",
                        "distanceFunction": "cosine",  # Rule 10.1: Cosine for text embeddings
                        "dimensions": 1536  # text-embedding-ada-002
                    }
                ]
            }
            
            # Rule 10.2: Vector indexes configuration
            # Rule 10.3: CRITICAL - Exclude vector path from regular indexing
            indexing_policy = {
                "includedPaths": [{"path": "/*"}],
                "excludedPaths": [
                    {"path": "/\"_etag\"/?"},
                    {"path": "/embedding/*"}  # Rule 10.3: Exclude vector path for performance
                ],
                "vectorIndexes": [
                    {
                        "path": "/embedding",
                        "type": "quantizedFlat"  # Rule 10.2: QuantizedFlat for <50K vectors
                    }
                ]
            }
            
            # Rule 6.1: Autoscale for variable query load
            documents_throughput = ThroughputProperties(auto_scale_max_throughput=4000)
            
            try:
                documents_container = self.database.create_container_if_not_exists(
                    id="documents",
                    partition_key=PartitionKey(path="/category"),  # Rule 2.4: High cardinality
                    indexing_policy=indexing_policy,
                    vector_embedding_policy=vector_embedding_policy,
                    offer_throughput=documents_throughput
                )
                logger.info("[OK] Documents container created with vector search (QuantizedFlat index)")
            except exceptions.CosmosResourceExistsError:
                logger.info("[OK] Documents container already exists")
                documents_container = self.database.get_container_client("documents")
            
            self.sessions_container = sessions_container
            self.documents_container = documents_container
            
            logger.info("[OK] All containers initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize containers: {e}")
            raise
    
    # Session operations
    def create_session(self, session: ChatSession) -> ChatSession:
        """
        Create new chat session.
        Rule 2.5: Partition key in query for single-partition operation.
        """
        item = session.model_dump(mode='json')
        created_item = self.sessions_container.create_item(body=item)
        return ChatSession(**created_item)
    
    def add_message(self, session_id: str, user_id: str, message: ChatMessage) -> ChatSession:
        """
        Add message to existing session.
        Rule 1.3: Update embedded messages array.
        Rule 2.5: Include partition key for point read.
        """
        # Rule 2.5: Point read with partition key
        session_item = self.sessions_container.read_item(
            item=session_id,
            partition_key=user_id
        )
        
        session = ChatSession(**session_item)
        session.messages.append(message)
        session.updatedAt = message.timestamp
        
        # Update session with new message
        updated_item = self.sessions_container.replace_item(
            item=session_id,
            body=session.model_dump(mode='json')
        )
        
        return ChatSession(**updated_item)
    
    def get_session(self, session_id: str, user_id: str) -> Optional[ChatSession]:
        """
        Get session with all messages.
        Rule 2.5: Point read with partition key (low RU cost).
        """
        try:
            item = self.sessions_container.read_item(
                item=session_id,
                partition_key=user_id
            )
            return ChatSession(**item)
        except exceptions.CosmosResourceNotFoundError:
            return None
    
    def list_user_sessions(self, user_id: str) -> List[ChatSession]:
        """
        List all sessions for a user.
        Rule 3.1: Single-partition query (partition key = userId).
        Rule 3.5: Parameterized query.
        """
        # Rule 3.1: Efficient single-partition query
        # Rule 3.5: Parameterized query
        query = "SELECT * FROM c WHERE c.userId = @userId ORDER BY c.createdAt DESC"
        parameters = [{"name": "@userId", "value": user_id}]
        
        items = self.sessions_container.query_items(
            query=query,
            parameters=parameters,
            partition_key=user_id,  # Rule 3.1: Single partition
            enable_cross_partition_query=False
        )
        
        return [ChatSession(**item) for item in items]
    
    # Document operations with vector search
    def store_document(self, document: DocumentChunk) -> DocumentChunk:
        """
        Store document with vector embedding.
        Rule 10.3: Embedding path excluded from indexing for performance.
        """
        item = document.model_dump(mode='json')
        created_item = self.documents_container.create_item(body=item)
        return DocumentChunk(**created_item)
    
    def vector_search(
        self, 
        embedding: List[float], 
        top_k: int = 10,
        category: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Perform vector similarity search.
        Rule 10.4: Use VectorDistance() for similarity search.
        Rule 3.5: Parameterized queries for plan caching.
        """
        if category:
            # Hybrid search: vector + metadata filter
            # Rule 3.5: Parameterized query
            # Rule 10.4: VectorDistance() with ORDER BY
            query = f"""
                SELECT TOP {top_k} c.id, c.title, c.content, c.category, c.metadata,
                       VectorDistance(c.embedding, @embedding) AS similarityScore
                FROM c
                WHERE c.category = @category
                ORDER BY VectorDistance(c.embedding, @embedding)
            """
            parameters = [
                {"name": "@embedding", "value": embedding},
                {"name": "@category", "value": category}
            ]
            # Single partition query if category specified
            enable_cross_partition = False
            partition_key = category
        else:
            # Rule 10.4: Pure vector search across all categories
            query = f"""
                SELECT TOP {top_k} c.id, c.title, c.content, c.category, c.metadata,
                       VectorDistance(c.embedding, @embedding) AS similarityScore
                FROM c
                ORDER BY VectorDistance(c.embedding, @embedding)
            """
            parameters = [{"name": "@embedding", "value": embedding}]
            enable_cross_partition = True
            partition_key = None
        
        # Execute vector search query
        items = list(self.documents_container.query_items(
            query=query,
            parameters=parameters,
            enable_cross_partition_query=enable_cross_partition,
            partition_key=partition_key
        ))
        
        return items


# Rule 4.14: Create singleton instance
cosmos_service = CosmosDBService()
