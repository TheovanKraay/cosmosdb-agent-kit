"""
Data models for AI Chat RAG application.
Rule 1.3: Embed messages within sessions for read optimization.
Rule 1.6: Use type discriminators for polymorphic queries.
"""
from datetime import datetime
from typing import List, Literal, Optional
from pydantic import BaseModel, Field
from uuid import uuid4


# Rule 1.3: Embed related data retrieved together
class ChatMessage(BaseModel):
    """Individual message within a chat session."""
    id: str = Field(default_factory=lambda: str(uuid4()))
    role: Literal["user", "assistant", "system"]
    content: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# Rule 1.3: Chat session with embedded messages
class ChatSession(BaseModel):
    """
    Chat session containing embedded messages.
    Rule 1.3: Messages are embedded for single-document retrieval.
    Rule 2.1: Partition by userId to keep user's sessions together.
    """
    id: str = Field(default_factory=lambda: str(uuid4()))
    userId: str
    title: str
    messages: List[ChatMessage] = Field(default_factory=list)
    createdAt: datetime = Field(default_factory=datetime.utcnow)
    updatedAt: datetime = Field(default_factory=datetime.utcnow)
    
    # Rule 1.6: Type discriminator for polymorphic queries
    type: str = "session"


# Vector search: Document chunks with embeddings
class DocumentChunk(BaseModel):
    """
    Document chunk with vector embedding for RAG.
    Rule 10.1: Vector embedding policy required for vector search.
    Rule 10.2: Exclude embedding path from regular indexing.
    """
    id: str = Field(default_factory=lambda: str(uuid4()))
    category: str  # Partition key - Rule 2.4: High cardinality
    title: str
    content: str
    embedding: List[float]  # 1536 dimensions for text-embedding-ada-002
    metadata: dict = Field(default_factory=dict)
    createdAt: datetime = Field(default_factory=datetime.utcnow)
    
    # Rule 1.6: Type discriminator
    type: str = "document"


# API request/response models
class CreateSessionRequest(BaseModel):
    """Request to create new chat session."""
    userId: str
    title: str


class AddMessageRequest(BaseModel):
    """Request to add message to session."""
    sessionId: str
    role: Literal["user", "assistant", "system"]
    content: str


class StoreDocumentRequest(BaseModel):
    """Request to store document with embedding."""
    category: str
    title: str
    content: str
    embedding: List[float]
    metadata: dict = Field(default_factory=dict)


class VectorSearchRequest(BaseModel):
    """Request for vector similarity search."""
    embedding: List[float]
    top_k: int = Field(default=10, ge=1, le=100)
    category: Optional[str] = None  # Hybrid search filter
