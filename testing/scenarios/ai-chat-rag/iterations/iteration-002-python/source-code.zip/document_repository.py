"""
Document Repository - Data access layer for documents with vector search
Implements vector search operations using Cosmos DB NoSQL API.
Follows best practices for vector search performance and indexing.
"""
from typing import List, Optional
from azure.cosmos import ContainerProxy
from azure.cosmos.exceptions import CosmosHttpResponseError
from models import DocumentChunk
import logging

logger = logging.getLogger(__name__)


class DocumentRepository:
    """Repository for managing documents with vector embeddings in Cosmos DB"""
    
    def __init__(self, container: ContainerProxy):
        """Initialize repository with Cosmos DB container"""
        self.container = container
    
    async def insert_document(self, document: DocumentChunk) -> DocumentChunk:
        """
        Insert a document with vector embedding.
        
        Args:
            document: DocumentChunk object to insert
            
        Returns:
            Created DocumentChunk
            
        Best Practice: Use upsert_item for idempotent inserts
        Vector Search Rule: Embeddings must be float32 arrays with correct dimensions (1536)
        """
        try:
            doc_dict = document.dict()
            created_item = self.container.upsert_item(body=doc_dict)
            logger.info(f"[OK] Inserted document: {created_item['id']}")
            return DocumentChunk(**created_item)
        except CosmosHttpResponseError as e:
            logger.error(f"Failed to insert document: {e.message}")
            raise
    
    async def insert_documents_bulk(self, documents: List[DocumentChunk]) -> List[DocumentChunk]:
        """
        Insert multiple documents in bulk.
        
        Args:
            documents: List of DocumentChunk objects to insert
            
        Returns:
            List of created DocumentChunk objects
            
        Best Practice: Use concurrent upserts for bulk operations
        Performance: Process in batches to avoid overwhelming the service
        """
        results = []
        for doc in documents:
            try:
                result = await self.insert_document(doc)
                results.append(result)
            except Exception as e:
                logger.error(f"Failed to insert document {doc.id}: {str(e)}")
                # Continue with other documents
        
        logger.info(f"[OK] Bulk inserted {len(results)} of {len(documents)} documents")
        return results
    
    async def vector_search(
        self,
        query_embedding: List[float],
        limit: int = 5,
        similarity_threshold: float = 0.0,
        category_filter: Optional[str] = None
    ) -> List[DocumentChunk]:
        """
        Perform vector similarity search.
        
        Args:
            query_embedding: Query vector embedding (1536 dimensions)
            limit: Maximum number of results to return
            similarity_threshold: Minimum similarity score (0.0 to 1.0)
            category_filter: Optional category filter
            
        Returns:
            List of similar DocumentChunk objects with similarity scores
            
        Best Practice: Use VectorDistance() in SELECT and ORDER BY
        Vector Search Rule: QuantizedFlat index is optimal for < 50K vectors
        Performance: Exclude embedding from results projection if not needed (Rule 2.2)
        """
        try:
            # Build query with vector distance
            # Pattern from samples: VectorDistance(c.embedding, @queryVector)
            base_query = """
                SELECT TOP @limit 
                    c.id,
                    c.title,
                    c.content,
                    c.category,
                    c.metadata,
                    VectorDistance(c.embedding, @queryVector) AS similarityScore
                FROM c
                WHERE VectorDistance(c.embedding, @queryVector) > @threshold
            """
            
            # Add category filter if specified
            if category_filter:
                base_query += " AND c.category = @category"
            
            base_query += " ORDER BY VectorDistance(c.embedding, @queryVector)"
            
            # Build parameters
            parameters = [
                {"name": "@queryVector", "value": query_embedding},
                {"name": "@limit", "value": limit},
                {"name": "@threshold", "value": similarity_threshold}
            ]
            
            if category_filter:
                parameters.append({"name": "@category", "value": category_filter})
            
            # Execute query
            items = list(self.container.query_items(
                query=base_query,
                parameters=parameters,
                enable_cross_partition_query=True,
                populate_query_metrics=True
            ))
            
            # Convert to DocumentChunk objects and add similarity scores to metadata
            results = []
            for item in items:
                similarity_score = item.pop('similarityScore', 0.0)
                # Add similarity score to metadata
                if 'metadata' not in item or item['metadata'] is None:
                    item['metadata'] = {}
                item['metadata']['similarityScore'] = similarity_score
                # Add placeholder embedding (not returned in query for performance)
                item['embedding'] = []
                results.append(DocumentChunk(**item))
            
            logger.info(f"[OK] Vector search returned {len(results)} results")
            return results
            
        except CosmosHttpResponseError as e:
            logger.error(f"Vector search failed: {e.message}")
            raise
    
    async def get_document(self, document_id: str, category: str) -> Optional[DocumentChunk]:
        """
        Retrieve a document by ID.
        
        Args:
            document_id: Document ID
            category: Category (partition key)
            
        Returns:
            DocumentChunk if found, None otherwise
            
        Best Practice: Use read_item with partition key for point reads
        """
        try:
            item = self.container.read_item(
                item=document_id,
                partition_key=category
            )
            return DocumentChunk(**item)
        except CosmosHttpResponseError as e:
            if e.status_code == 404:
                logger.warning(f"Document not found: {document_id}")
                return None
            logger.error(f"Failed to get document: {e.message}")
            raise
    
    async def get_documents_by_category(self, category: str, limit: int = 10) -> List[DocumentChunk]:
        """
        Get documents by category.
        
        Args:
            category: Category filter (partition key)
            limit: Maximum number of documents to return
            
        Returns:
            List of DocumentChunk objects
            
        Best Practice: Partition key filter for single-partition queries
        Performance: Exclude embeddings from projection to reduce RU cost
        """
        try:
            query = """
                SELECT TOP @limit c.id, c.content, c.category, c.metadata
                FROM c 
                WHERE c.category = @category
            """
            parameters = [
                {"name": "@limit", "value": limit},
                {"name": "@category", "value": category}
            ]
            
            items = list(self.container.query_items(
                query=query,
                parameters=parameters,
                partition_key=category,
                enable_cross_partition_query=False
            ))
            
            # Add placeholder embeddings
            for item in items:
                item['embedding'] = []
            
            results = [DocumentChunk(**item) for item in items]
            logger.info(f"[OK] Retrieved {len(results)} documents for category: {category}")
            return results
            
        except CosmosHttpResponseError as e:
            logger.error(f"Failed to get documents by category: {e.message}")
            raise
    
    async def delete_document(self, document_id: str, category: str) -> bool:
        """
        Delete a document.
        
        Args:
            document_id: Document ID
            category: Category (partition key)
            
        Returns:
            True if deleted, False if not found
        """
        try:
            self.container.delete_item(
                item=document_id,
                partition_key=category
            )
            logger.info(f"[OK] Deleted document: {document_id}")
            return True
        except CosmosHttpResponseError as e:
            if e.status_code == 404:
                logger.warning(f"Document not found for deletion: {document_id}")
                return False
            logger.error(f"Failed to delete document: {e.message}")
            raise
