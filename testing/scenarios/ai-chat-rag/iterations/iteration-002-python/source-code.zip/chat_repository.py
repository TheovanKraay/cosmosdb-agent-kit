"""
Chat Repository - Data access layer for chat sessions and messages
Implements CRUD operations for chat sessions with embedded messages.
Follows Cosmos DB best practices for embedded document patterns.
"""
from typing import List, Optional
from azure.cosmos import ContainerProxy
from azure.cosmos.exceptions import CosmosResourceNotFoundError, CosmosHttpResponseError
from models import ChatSession, ChatMessage
import logging

logger = logging.getLogger(__name__)


class ChatRepository:
    """Repository for managing chat sessions with embedded messages in Cosmos DB"""
    
    def __init__(self, container: ContainerProxy):
        """Initialize repository with Cosmos DB container"""
        self.container = container
    
    async def create_session(self, session: ChatSession) -> ChatSession:
        """
        Create a new chat session.
        
        Args:
            session: ChatSession object to create
            
        Returns:
            Created ChatSession
            
        Best Practice: Use create_item for initial insert
        """
        try:
            session_dict = session.dict()
            created_item = self.container.create_item(body=session_dict)
            logger.info(f"[OK] Created chat session: {created_item['id']}")
            return ChatSession(**created_item)
        except CosmosHttpResponseError as e:
            logger.error(f"Failed to create session: {e.message}")
            raise
    
    async def get_session(self, session_id: str, user_id: str) -> Optional[ChatSession]:
        """
        Retrieve a chat session by ID.
        
        Args:
            session_id: Session ID
            user_id: User ID (partition key)
            
        Returns:
            ChatSession if found, None otherwise
            
        Best Practice: Use read_item with partition key for point reads (lowest RU cost)
        """
        try:
            item = self.container.read_item(
                item=session_id,
                partition_key=user_id
            )
            return ChatSession(**item)
        except CosmosResourceNotFoundError:
            logger.warning(f"Session not found: {session_id}")
            return None
        except CosmosHttpResponseError as e:
            logger.error(f"Failed to get session: {e.message}")
            raise
    
    async def add_message(self, session_id: str, user_id: str, message: ChatMessage) -> ChatSession:
        """
        Add a message to an existing session.
        
        Args:
            session_id: Session ID
            user_id: User ID (partition key)
            message: ChatMessage to add
            
        Returns:
            Updated ChatSession
            
        Best Practice: Read-modify-write pattern for embedded documents
        Rule: Embed related data that is queried together (Rule 1.2 - model-embed-related)
        """
        try:
            # Read current session
            session = await self.get_session(session_id, user_id)
            if not session:
                raise ValueError(f"Session not found: {session_id}")
            
            # Add message to embedded array
            session.messages.append(message)
            
            # Update the session document
            session_dict = session.dict()
            updated_item = self.container.replace_item(
                item=session_id,
                body=session_dict
            )
            logger.info(f"[OK] Added message to session: {session_id}")
            return ChatSession(**updated_item)
        except CosmosHttpResponseError as e:
            logger.error(f"Failed to add message: {e.message}")
            raise
    
    async def get_recent_sessions(self, user_id: str, limit: int = 10) -> List[ChatSession]:
        """
        Get recent chat sessions for a user.
        
        Args:
            user_id: User ID (partition key)
            limit: Maximum number of sessions to return
            
        Returns:
            List of recent ChatSession objects
            
        Best Practice: Partition key filter for single-partition queries (low RU cost)
        """
        try:
            query = f"SELECT TOP @limit * FROM c WHERE c.userId = @userId ORDER BY c._ts DESC"
            parameters = [
                {"name": "@limit", "value": limit},
                {"name": "@userId", "value": user_id}
            ]
            
            items = self.container.query_items(
                query=query,
                parameters=parameters,
                partition_key=user_id,
                enable_cross_partition_query=False
            )
            
            sessions = [ChatSession(**item) for item in items]
            logger.info(f"[OK] Retrieved {len(sessions)} recent sessions for user: {user_id}")
            return sessions
        except CosmosHttpResponseError as e:
            logger.error(f"Failed to get recent sessions: {e.message}")
            raise
    
    async def delete_session(self, session_id: str, user_id: str) -> bool:
        """
        Delete a chat session.
        
        Args:
            session_id: Session ID
            user_id: User ID (partition key)
            
        Returns:
            True if deleted, False if not found
            
        Best Practice: Use partition key for delete operations
        """
        try:
            self.container.delete_item(
                item=session_id,
                partition_key=user_id
            )
            logger.info(f"[OK] Deleted session: {session_id}")
            return True
        except CosmosResourceNotFoundError:
            logger.warning(f"Session not found for deletion: {session_id}")
            return False
        except CosmosHttpResponseError as e:
            logger.error(f"Failed to delete session: {e.message}")
            raise
