$baseUrl = "http://localhost:5200/api"

Write-Host "=== E-Commerce Order API Test ===" -ForegroundColor Cyan
Write-Host ""

# Test 1: Create order
Write-Host "1. Creating order..." -ForegroundColor Yellow
$createBody = @{
    customerId = "cust123"
    customerName = "John Doe"
    customerEmail = "john@example.com"
    items = @(
        @{ productId = "prod1"; productName = "Widget A"; quantity = 2; unitPrice = 29.99 },
        @{ productId = "prod2"; productName = "Widget B"; quantity = 1; unitPrice = 49.99 }
    )
} | ConvertTo-Json -Depth 3

try {
    $order = Invoke-RestMethod -Uri "$baseUrl/orders" -Method POST -Body $createBody -ContentType "application/json"
    Write-Host "   Created order: $($order.id)" -ForegroundColor Green
    Write-Host "   Status: $($order.status)" -ForegroundColor Green
    Write-Host "   Total: $($order.total)" -ForegroundColor Green
    $orderId = $order.id
    $customerId = $order.customerId
} catch {
    Write-Host "   FAILED: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Test 2: Get order by ID
Write-Host ""
Write-Host "2. Getting order by ID..." -ForegroundColor Yellow
try {
    $fetched = Invoke-RestMethod -Uri "$baseUrl/orders/$orderId`?customerId=$customerId" -Method GET
    Write-Host "   Found order: $($fetched.id)" -ForegroundColor Green
    Write-Host "   Items count: $($fetched.items.Count)" -ForegroundColor Green
} catch {
    Write-Host "   FAILED: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 3: Get orders by customer
Write-Host ""
Write-Host "3. Getting orders by customer..." -ForegroundColor Yellow
try {
    $customerOrders = Invoke-RestMethod -Uri "$baseUrl/orders/customer/$customerId" -Method GET
    Write-Host "   Found $($customerOrders.items.Count) orders" -ForegroundColor Green
} catch {
    Write-Host "   FAILED: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 4: Update status to Shipped
Write-Host ""
Write-Host "4. Updating order status to Shipped..." -ForegroundColor Yellow
$updateBody = @{ status = "Shipped" } | ConvertTo-Json
try {
    $updated = Invoke-RestMethod -Uri "$baseUrl/orders/$orderId/status?customerId=$customerId" -Method PATCH -Body $updateBody -ContentType "application/json"
    Write-Host "   Updated status: $($updated.status)" -ForegroundColor Green
} catch {
    Write-Host "   FAILED: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 5: Query by status - THE CRITICAL TEST FOR RULE 4.10!
Write-Host ""
Write-Host "5. [CRITICAL TEST] Querying orders by status 'Shipped'..." -ForegroundColor Yellow
try {
    $byStatus = Invoke-RestMethod -Uri "$baseUrl/orders/status/Shipped" -Method GET
    Write-Host "   Found $($byStatus.items.Count) orders with status 'Shipped'" -ForegroundColor Green
    if ($byStatus.items.Count -eq 0) {
        Write-Host "   WARNING: Expected to find at least 1 order!" -ForegroundColor Red
        Write-Host "   This might indicate enum serialization issue (Rule 4.10)" -ForegroundColor Red
    } else {
        Write-Host "   SUCCESS: Enum serialization working correctly!" -ForegroundColor Cyan
    }
} catch {
    Write-Host "   FAILED: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 6: Query by date range
Write-Host ""
Write-Host "6. Querying orders by date range..." -ForegroundColor Yellow
$startDate = (Get-Date).AddDays(-1).ToString("yyyy-MM-ddTHH:mm:ssZ")
$endDate = (Get-Date).AddDays(1).ToString("yyyy-MM-ddTHH:mm:ssZ")
try {
    $byDate = Invoke-RestMethod -Uri "$baseUrl/orders/daterange?startDate=$startDate&endDate=$endDate" -Method GET
    Write-Host "   Found $($byDate.items.Count) orders in date range" -ForegroundColor Green
} catch {
    Write-Host "   FAILED: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "=== Test Complete ===" -ForegroundColor Cyan
