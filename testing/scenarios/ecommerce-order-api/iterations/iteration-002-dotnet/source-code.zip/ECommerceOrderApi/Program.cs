using System.Text.Json.Serialization;
using ECommerceOrderApi.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        // Rule 4.10: Ensure API responses also use string enums
        options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        options.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
    });

// Rule 4.1: Register CosmosDbService as SINGLETON (critical for connection reuse)
builder.Services.AddSingleton<CosmosDbService>();
builder.Services.AddScoped<OrderRepository>();

var app = builder.Build();

// Initialize Cosmos DB on startup
using (var scope = app.Services.CreateScope())
{
    var cosmosService = scope.ServiceProvider.GetRequiredService<CosmosDbService>();
    var config = scope.ServiceProvider.GetRequiredService<IConfiguration>();
    
    var databaseName = config["CosmosDb:DatabaseName"] ?? "ECommerceDb";
    var containerName = config["CosmosDb:ContainerName"] ?? "Orders";
    
    await cosmosService.InitializeAsync(databaseName, containerName);
    Console.WriteLine($"✅ Cosmos DB initialized: {databaseName}/{containerName}");
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

Console.WriteLine("🚀 E-Commerce Order API starting...");
Console.WriteLine("📋 Endpoints:");
Console.WriteLine("   POST   /api/orders                    - Create order");
Console.WriteLine("   GET    /api/orders/{id}?customerId=   - Get order by ID");
Console.WriteLine("   GET    /api/orders/customer/{id}      - Get customer orders");
Console.WriteLine("   GET    /api/orders/status/{status}    - Get orders by status");
Console.WriteLine("   GET    /api/orders/daterange          - Get orders by date range");
Console.WriteLine("   PATCH  /api/orders/{id}/status        - Update order status");

app.Run();
