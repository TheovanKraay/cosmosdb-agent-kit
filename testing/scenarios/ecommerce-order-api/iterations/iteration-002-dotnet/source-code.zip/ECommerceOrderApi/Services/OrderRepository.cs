using System.Net;
using ECommerceOrderApi.Models;
using Microsoft.Azure.Cosmos;

namespace ECommerceOrderApi.Services;

/// <summary>
/// Order repository implementing Cosmos DB best practices:
/// - 3.1: Single-partition queries where possible
/// - 3.2: Project only needed fields
/// - 3.3: Continuation tokens for pagination
/// - 3.5: Parameterized queries
/// - 4.2: Async APIs throughout
/// - 4.6: Diagnostics logging for troubleshooting
/// </summary>
public class OrderRepository
{
    private readonly Container _container;
    private readonly ILogger<OrderRepository> _logger;

    public OrderRepository(CosmosDbService cosmosDbService, ILogger<OrderRepository> logger)
    {
        _container = cosmosDbService.Container;
        _logger = logger;
    }

    /// <summary>Create a new order (Rule 4.2: async)</summary>
    public async Task<Order> CreateOrderAsync(Order order)
    {
        order.CalculateTotals();
        order.CreatedAt = DateTime.UtcNow;
        order.UpdatedAt = DateTime.UtcNow;

        var response = await _container.CreateItemAsync(
            order,
            new PartitionKey(order.CustomerId));

        // Rule 4.6: Log diagnostics
        _logger.LogDebug("CreateOrder RU charge: {RequestCharge}", response.RequestCharge);

        return response.Resource;
    }

    /// <summary>
    /// Get order by ID - requires partition key (Rule 3.1)
    /// Uses point read for efficiency (1 RU)
    /// </summary>
    public async Task<Order?> GetOrderAsync(string orderId, string customerId)
    {
        try
        {
            var response = await _container.ReadItemAsync<Order>(
                orderId,
                new PartitionKey(customerId));

            // Rule 4.6: Log RU consumption
            _logger.LogDebug("GetOrder RU charge: {RequestCharge}", response.RequestCharge);

            return response.Resource;
        }
        catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
        {
            return null;
        }
    }

    /// <summary>
    /// Get orders by customer - single partition query (Rule 3.1)
    /// Uses pagination with continuation tokens (Rule 3.3)
    /// </summary>
    public async Task<PagedResult<Order>> GetOrdersByCustomerAsync(
        string customerId,
        int pageSize = 10,
        string? continuationToken = null)
    {
        // Rule 3.5: Parameterized query
        // Rule 3.1: Single partition (customerId in partition key AND filter)
        var query = new QueryDefinition(
            "SELECT * FROM c WHERE c.customerId = @customerId AND c.type = @type ORDER BY c.createdAt DESC")
            .WithParameter("@customerId", customerId)
            .WithParameter("@type", "order");

        var options = new QueryRequestOptions
        {
            PartitionKey = new PartitionKey(customerId), // Rule 3.1: Single partition
            MaxItemCount = pageSize
        };

        var iterator = _container.GetItemQueryIterator<Order>(query, continuationToken, options);
        var results = new List<Order>();
        string? newContinuationToken = null;
        double totalRu = 0;

        if (iterator.HasMoreResults)
        {
            var response = await iterator.ReadNextAsync();
            results.AddRange(response);
            newContinuationToken = response.ContinuationToken;
            totalRu = response.RequestCharge;
        }

        _logger.LogDebug("GetOrdersByCustomer RU charge: {RequestCharge}", totalRu);

        return new PagedResult<Order>(results, newContinuationToken, newContinuationToken != null);
    }

    /// <summary>
    /// Query orders by status - cross-partition but uses index (Rule 5.2)
    /// Note: This is cross-partition because status is not the partition key
    /// Uses projection to reduce RU (Rule 3.2)
    /// </summary>
    public async Task<PagedResult<OrderSummary>> GetOrdersByStatusAsync(
        OrderStatus status,
        int pageSize = 20,
        string? continuationToken = null)
    {
        // Rule 3.5: Parameterized query
        // Rule 3.2: Project only needed fields
        // Rule 4.10: Query using string value since we serialize enums as strings
        var query = new QueryDefinition(
            @"SELECT c.id, c.customerId, c.customerName, c.status, c.total, 
                     ARRAY_LENGTH(c.items) as itemCount, c.createdAt 
              FROM c 
              WHERE c.status = @status AND c.type = @type 
              ORDER BY c.createdAt DESC")
            .WithParameter("@status", status.ToString()) // Rule 4.10: String enum value
            .WithParameter("@type", "order");

        var options = new QueryRequestOptions
        {
            MaxItemCount = pageSize
        };

        var iterator = _container.GetItemQueryIterator<OrderSummary>(query, continuationToken, options);
        var results = new List<OrderSummary>();
        string? newContinuationToken = null;
        double totalRu = 0;

        if (iterator.HasMoreResults)
        {
            var response = await iterator.ReadNextAsync();
            results.AddRange(response);
            newContinuationToken = response.ContinuationToken;
            totalRu = response.RequestCharge;
        }

        _logger.LogDebug("GetOrdersByStatus RU charge: {RequestCharge} (cross-partition)", totalRu);

        return new PagedResult<OrderSummary>(results, newContinuationToken, newContinuationToken != null);
    }

    /// <summary>
    /// Query orders by date range - cross-partition
    /// Uses projection and composite index (Rules 3.2, 5.2)
    /// </summary>
    public async Task<PagedResult<OrderSummary>> GetOrdersByDateRangeAsync(
        DateTime startDate,
        DateTime endDate,
        int pageSize = 20,
        string? continuationToken = null)
    {
        // Rule 3.5: Parameterized query
        // Rule 3.2: Project only needed fields
        var query = new QueryDefinition(
            @"SELECT c.id, c.customerId, c.customerName, c.status, c.total, 
                     ARRAY_LENGTH(c.items) as itemCount, c.createdAt 
              FROM c 
              WHERE c.createdAt >= @startDate AND c.createdAt <= @endDate AND c.type = @type 
              ORDER BY c.createdAt DESC")
            .WithParameter("@startDate", startDate)
            .WithParameter("@endDate", endDate)
            .WithParameter("@type", "order");

        var options = new QueryRequestOptions
        {
            MaxItemCount = pageSize
        };

        var iterator = _container.GetItemQueryIterator<OrderSummary>(query, continuationToken, options);
        var results = new List<OrderSummary>();
        string? newContinuationToken = null;
        double totalRu = 0;

        if (iterator.HasMoreResults)
        {
            var response = await iterator.ReadNextAsync();
            results.AddRange(response);
            newContinuationToken = response.ContinuationToken;
            totalRu = response.RequestCharge;
        }

        _logger.LogDebug("GetOrdersByDateRange RU charge: {RequestCharge} (cross-partition)", totalRu);

        return new PagedResult<OrderSummary>(results, newContinuationToken, newContinuationToken != null);
    }

    /// <summary>
    /// Update order status - uses partition key for efficiency
    /// Patch operation for minimal RU (only updates specific fields)
    /// </summary>
    public async Task<Order?> UpdateOrderStatusAsync(string orderId, string customerId, OrderStatus newStatus)
    {
        try
        {
            // Use patch for efficient partial update
            var patchOperations = new[]
            {
                PatchOperation.Set("/status", newStatus.ToString()), // Rule 4.10: Store as string
                PatchOperation.Set("/statusLower", newStatus.ToString().ToLowerInvariant()),
                PatchOperation.Set("/updatedAt", DateTime.UtcNow)
            };

            var response = await _container.PatchItemAsync<Order>(
                orderId,
                new PartitionKey(customerId),
                patchOperations);

            _logger.LogDebug("UpdateOrderStatus RU charge: {RequestCharge}", response.RequestCharge);

            return response.Resource;
        }
        catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
        {
            return null;
        }
    }
}
