using System.Collections.ObjectModel;
using System.Net;
using System.Text.Json;
using System.Text.Json.Serialization;
using ECommerceOrderApi.Models;
using Microsoft.Azure.Cosmos;

namespace ECommerceOrderApi.Services;

/// <summary>
/// Cosmos DB configuration and client factory
/// Implements best practices:
/// - 4.1: Singleton CosmosClient
/// - 4.4: Direct connection mode
/// - 4.10: JsonStringEnumConverter for consistent enum serialization
/// - 4.3: Retry configuration for 429 errors
/// </summary>
public class CosmosDbService : IDisposable
{
    private readonly CosmosClient _client;
    private readonly Container _container;
    private bool _disposed;

    public CosmosDbService(IConfiguration configuration)
    {
        var connectionString = configuration["CosmosDb:ConnectionString"]
            ?? throw new InvalidOperationException("CosmosDb:ConnectionString not configured");
        var databaseName = configuration["CosmosDb:DatabaseName"] ?? "ECommerceDb";
        var containerName = configuration["CosmosDb:ContainerName"] ?? "Orders";

        // Rule 4.10: Configure JSON serialization with string enums
        var jsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            Converters = { new JsonStringEnumConverter() } // CRITICAL: Enums as strings!
        };

        // Rule 4.1: Create singleton client with proper configuration
        // Rule 4.4: Direct connection mode for production performance
        // Rule 4.3: Configure retries for 429 handling
        var clientOptions = new CosmosClientOptions
        {
            ConnectionMode = ConnectionMode.Direct, // Rule 4.4
            MaxRetryAttemptsOnRateLimitedRequests = 9, // Rule 4.3
            MaxRetryWaitTimeOnRateLimitedRequests = TimeSpan.FromSeconds(30),
            Serializer = new CosmosSystemTextJsonSerializer(jsonOptions), // Rule 4.10
            ConsistencyLevel = ConsistencyLevel.Session // Rule 7.2: Good balance
        };

        _client = new CosmosClient(connectionString, clientOptions);
        _container = _client.GetContainer(databaseName, containerName);
    }

    public Container Container => _container;
    public CosmosClient Client => _client;

    /// <summary>
    /// Initialize database and container with proper configuration
    /// - Rule 2.1: customerId as partition key (high cardinality)
    /// - Rule 5.2: Composite index for status + date queries
    /// </summary>
    public async Task InitializeAsync(string databaseName, string containerName)
    {
        var database = await _client.CreateDatabaseIfNotExistsAsync(databaseName);

        // Rule 5.2: Create composite indexes for ORDER BY queries
        var containerProperties = new ContainerProperties(containerName, "/customerId")
        {
            IndexingPolicy = new IndexingPolicy
            {
                Automatic = true,
                IndexingMode = IndexingMode.Consistent,
                IncludedPaths = { new IncludedPath { Path = "/*" } },
                ExcludedPaths =
                {
                    // Rule 5.1: Exclude paths not used in queries
                    new ExcludedPath { Path = "/\"_etag\"/?" }
                },
                CompositeIndexes =
                {
                    // Rule 5.2: Composite index for status + date queries
                    new Collection<CompositePath>
                    {
                        new() { Path = "/status", Order = CompositePathSortOrder.Ascending },
                        new() { Path = "/createdAt", Order = CompositePathSortOrder.Descending }
                    },
                    new Collection<CompositePath>
                    {
                        new() { Path = "/customerId", Order = CompositePathSortOrder.Ascending },
                        new() { Path = "/createdAt", Order = CompositePathSortOrder.Descending }
                    }
                }
            }
        };

        await database.Database.CreateContainerIfNotExistsAsync(containerProperties, ThroughputProperties.CreateAutoscaleThroughput(1000));
    }

    public void Dispose()
    {
        if (!_disposed)
        {
            _client.Dispose();
            _disposed = true;
        }
        GC.SuppressFinalize(this);
    }
}

/// <summary>
/// Custom serializer using System.Text.Json with string enum support (Rule 4.10)
/// </summary>
public class CosmosSystemTextJsonSerializer : CosmosSerializer
{
    private readonly JsonSerializerOptions _options;

    public CosmosSystemTextJsonSerializer(JsonSerializerOptions options)
    {
        _options = options;
    }

    public override T FromStream<T>(Stream stream)
    {
        if (stream.CanSeek && stream.Length == 0)
            return default!;

        using var sr = new StreamReader(stream);
        var json = sr.ReadToEnd();
        return JsonSerializer.Deserialize<T>(json, _options)!;
    }

    public override Stream ToStream<T>(T input)
    {
        var stream = new MemoryStream();
        JsonSerializer.Serialize(stream, input, _options);
        stream.Position = 0;
        return stream;
    }
}
