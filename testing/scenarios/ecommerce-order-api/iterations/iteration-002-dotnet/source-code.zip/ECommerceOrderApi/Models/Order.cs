using System.Text.Json.Serialization;

namespace ECommerceOrderApi.Models;

/// <summary>
/// Order entity - follows best practices:
/// - 1.1: Embeds OrderItems (retrieved together)
/// - 1.5: Includes SchemaVersion for evolution
/// - 1.6: Uses Type discriminator for polymorphic queries
/// - 2.1/2.4: Uses CustomerId as partition key (high cardinality, aligns with main query pattern)
/// </summary>
public class Order
{
    /// <summary>Unique identifier (GUID)</summary>
    [JsonPropertyName("id")]
    public string Id { get; set; } = Guid.NewGuid().ToString();

    /// <summary>Partition key - enables efficient customer queries (Rule 2.1, 2.4)</summary>
    [JsonPropertyName("customerId")]
    public string CustomerId { get; set; } = string.Empty;

    /// <summary>Type discriminator for polymorphic data (Rule 1.6)</summary>
    [JsonPropertyName("type")]
    public string Type { get; } = "order";

    /// <summary>Schema version for backward compatibility (Rule 1.5)</summary>
    [JsonPropertyName("schemaVersion")]
    public int SchemaVersion { get; set; } = 1;

    /// <summary>Customer info embedded for read efficiency (Rule 1.1, 1.4 - denormalized)</summary>
    [JsonPropertyName("customerName")]
    public string CustomerName { get; set; } = string.Empty;

    [JsonPropertyName("customerEmail")]
    public string CustomerEmail { get; set; } = string.Empty;

    /// <summary>
    /// Order status - stored as STRING via JsonStringEnumConverter (Rule 4.10)
    /// This ensures queries can filter by status string values
    /// </summary>
    [JsonPropertyName("status")]
    public OrderStatus Status { get; set; } = OrderStatus.Pending;

    /// <summary>Lowercase status for case-insensitive queries (Rule 3.4 - avoid function calls)</summary>
    [JsonPropertyName("statusLower")]
    public string StatusLower => Status.ToString().ToLowerInvariant();

    /// <summary>Order items embedded (Rule 1.1 - always retrieved together)</summary>
    [JsonPropertyName("items")]
    public List<OrderItem> Items { get; set; } = new();

    [JsonPropertyName("subtotal")]
    public decimal Subtotal { get; set; }

    [JsonPropertyName("taxRate")]
    public decimal TaxRate { get; set; } = 0.08m; // 8% default tax

    [JsonPropertyName("taxAmount")]
    public decimal TaxAmount { get; set; }

    [JsonPropertyName("total")]
    public decimal Total { get; set; }

    [JsonPropertyName("createdAt")]
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [JsonPropertyName("updatedAt")]
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>Calculate totals from items</summary>
    public void CalculateTotals()
    {
        Subtotal = Items.Sum(i => i.Quantity * i.UnitPrice);
        TaxAmount = Math.Round(Subtotal * TaxRate, 2);
        Total = Subtotal + TaxAmount;
    }
}

/// <summary>Embedded order item (Rule 1.1)</summary>
public class OrderItem
{
    [JsonPropertyName("productId")]
    public string ProductId { get; set; } = string.Empty;

    [JsonPropertyName("productName")]
    public string ProductName { get; set; } = string.Empty;

    [JsonPropertyName("quantity")]
    public int Quantity { get; set; }

    [JsonPropertyName("unitPrice")]
    public decimal UnitPrice { get; set; }

    [JsonPropertyName("lineTotal")]
    public decimal LineTotal => Quantity * UnitPrice;
}

/// <summary>
/// Order status enum - serialized as STRING (Rule 4.10)
/// The CosmosClient is configured with JsonStringEnumConverter
/// </summary>
public enum OrderStatus
{
    Pending,
    Confirmed,
    Shipped,
    Delivered,
    Cancelled
}
