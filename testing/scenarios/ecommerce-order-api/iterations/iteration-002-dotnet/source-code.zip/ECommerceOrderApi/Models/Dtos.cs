namespace ECommerceOrderApi.Models;

/// <summary>DTOs for API requests/responses</summary>

public record CreateOrderRequest(
    string CustomerId,
    string CustomerName,
    string CustomerEmail,
    List<OrderItemRequest> Items
);

public record OrderItemRequest(
    string ProductId,
    string ProductName,
    int Quantity,
    decimal UnitPrice
);

public record UpdateOrderStatusRequest(
    OrderStatus Status
);

public record OrderSummary(
    string Id,
    string CustomerId,
    string CustomerName,
    OrderStatus Status,
    decimal Total,
    int ItemCount,
    DateTime CreatedAt
);

public record PagedResult<T>(
    List<T> Items,
    string? ContinuationToken,
    bool HasMore
);
