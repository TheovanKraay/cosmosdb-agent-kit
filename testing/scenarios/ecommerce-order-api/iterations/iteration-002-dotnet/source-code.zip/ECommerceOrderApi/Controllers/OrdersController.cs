using ECommerceOrderApi.Models;
using ECommerceOrderApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace ECommerceOrderApi.Controllers;

[ApiController]
[Route("api/orders")]
public class OrdersController : ControllerBase
{
    private readonly OrderRepository _repository;
    private readonly ILogger<OrdersController> _logger;

    public OrdersController(OrderRepository repository, ILogger<OrdersController> logger)
    {
        _repository = repository;
        _logger = logger;
    }

    /// <summary>Create a new order</summary>
    [HttpPost]
    public async Task<ActionResult<Order>> CreateOrder([FromBody] CreateOrderRequest request)
    {
        if (string.IsNullOrEmpty(request.CustomerId))
            return BadRequest("CustomerId is required");

        if (request.Items == null || request.Items.Count == 0)
            return BadRequest("At least one item is required");

        var order = new Order
        {
            CustomerId = request.CustomerId,
            CustomerName = request.CustomerName,
            CustomerEmail = request.CustomerEmail,
            Items = request.Items.Select(i => new OrderItem
            {
                ProductId = i.ProductId,
                ProductName = i.ProductName,
                Quantity = i.Quantity,
                UnitPrice = i.UnitPrice
            }).ToList()
        };

        var created = await _repository.CreateOrderAsync(order);
        
        _logger.LogInformation("Order created: {OrderId} for customer {CustomerId}", 
            created.Id, created.CustomerId);

        return CreatedAtAction(nameof(GetOrder), 
            new { orderId = created.Id, customerId = created.CustomerId }, 
            created);
    }

    /// <summary>Get order by ID (requires customerId for partition key)</summary>
    [HttpGet("{orderId}")]
    public async Task<ActionResult<Order>> GetOrder(string orderId, [FromQuery] string customerId)
    {
        if (string.IsNullOrEmpty(customerId))
            return BadRequest("customerId query parameter is required");

        var order = await _repository.GetOrderAsync(orderId, customerId);
        
        if (order == null)
            return NotFound();

        return Ok(order);
    }

    /// <summary>Get orders for a customer (single partition query - efficient)</summary>
    [HttpGet("customer/{customerId}")]
    public async Task<ActionResult<PagedResult<Order>>> GetOrdersByCustomer(
        string customerId,
        [FromQuery] int pageSize = 10,
        [FromQuery] string? continuationToken = null)
    {
        var result = await _repository.GetOrdersByCustomerAsync(customerId, pageSize, continuationToken);
        return Ok(result);
    }

    /// <summary>Get orders by status (admin query - cross-partition)</summary>
    [HttpGet("status/{status}")]
    public async Task<ActionResult<PagedResult<OrderSummary>>> GetOrdersByStatus(
        OrderStatus status,
        [FromQuery] int pageSize = 20,
        [FromQuery] string? continuationToken = null)
    {
        var result = await _repository.GetOrdersByStatusAsync(status, pageSize, continuationToken);
        return Ok(result);
    }

    /// <summary>Get orders by date range (admin query - cross-partition)</summary>
    [HttpGet("daterange")]
    public async Task<ActionResult<PagedResult<OrderSummary>>> GetOrdersByDateRange(
        [FromQuery] DateTime startDate,
        [FromQuery] DateTime endDate,
        [FromQuery] int pageSize = 20,
        [FromQuery] string? continuationToken = null)
    {
        if (startDate > endDate)
            return BadRequest("startDate must be before endDate");

        var result = await _repository.GetOrdersByDateRangeAsync(startDate, endDate, pageSize, continuationToken);
        return Ok(result);
    }

    /// <summary>Update order status</summary>
    [HttpPatch("{orderId}/status")]
    public async Task<ActionResult<Order>> UpdateOrderStatus(
        string orderId,
        [FromQuery] string customerId,
        [FromBody] UpdateOrderStatusRequest request)
    {
        if (string.IsNullOrEmpty(customerId))
            return BadRequest("customerId query parameter is required");

        var updated = await _repository.UpdateOrderStatusAsync(orderId, customerId, request.Status);
        
        if (updated == null)
            return NotFound();

        _logger.LogInformation("Order {OrderId} status updated to {Status}", orderId, request.Status);

        return Ok(updated);
    }
}
