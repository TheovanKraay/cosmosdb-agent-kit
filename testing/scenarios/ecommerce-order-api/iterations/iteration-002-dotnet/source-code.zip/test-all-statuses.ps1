$baseUrl = "http://localhost:5200/api"

Write-Host "=== Creating Multiple Test Orders ===" -ForegroundColor Cyan

# Create orders with different statuses
$statuses = @("Pending", "Confirmed", "Shipped", "Delivered", "Cancelled")

foreach ($targetStatus in $statuses) {
    # Create order
    $body = @{
        customerId = "cust-$(Get-Random)"
        customerName = "Test Customer"
        customerEmail = "test@example.com"
        items = @(@{ productId = "p1"; productName = "Product"; quantity = 1; unitPrice = 10.00 })
    } | ConvertTo-Json -Depth 3
    
    $order = Invoke-RestMethod -Uri "$baseUrl/orders" -Method POST -Body $body -ContentType "application/json"
    
    if ($targetStatus -ne "Pending") {
        $updateBody = @{ status = $targetStatus } | ConvertTo-Json
        $order = Invoke-RestMethod -Uri "$baseUrl/orders/$($order.id)/status?customerId=$($order.customerId)" -Method PATCH -Body $updateBody -ContentType "application/json"
    }
    
    Write-Host "Created order $($order.id) with status: $($order.status)" -ForegroundColor Green
}

Write-Host ""
Write-Host "=== Verifying Status Queries ===" -ForegroundColor Cyan

foreach ($status in $statuses) {
    $result = Invoke-RestMethod -Uri "$baseUrl/orders/status/$status" -Method GET
    $count = $result.items.Count
    if ($count -gt 0) {
        Write-Host "[PASS] Status '$status': Found $count orders" -ForegroundColor Green
    } else {
        Write-Host "[FAIL] Status '$status': Found 0 orders (expected some!)" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "=== Done ===" -ForegroundColor Cyan
